<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="48"/>
        <source>Version Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="105"/>
        <source>Built with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="122"/>
        <source>Legal Notices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="353"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="53"/>
        <source>Registration Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="58"/>
        <source>License Agreement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="86"/>
        <source>Please, renew your license</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="111"/>
        <source>Not Registered version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="112"/>
        <source>Registered version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="158"/>
        <source>Purchased On:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="166"/>
        <source>Maintenance Plan Expires:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="232"/>
        <source>This software uses, with permission, the following copyrighted software.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="96"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="103"/>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdvancedPrintDialog</name>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="14"/>
        <source>Advanced Print Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="20"/>
        <source>Print as Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="63"/>
        <source>Queue In Subset Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="94"/>
        <source>Сompatible with Laser Engraving</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="14"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="20"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="242"/>
        <source>Borders and Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="252"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="257"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="262"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="267"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="272"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="277"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="282"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="287"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="292"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="297"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="302"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="310"/>
        <source>Border Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="317"/>
        <source>Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="325"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="330"/>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="338"/>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="345"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="142"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="161"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="175"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="183"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="26"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="40"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="279"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="285"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="364"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="370"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="396"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="495"/>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="47"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="67"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="83"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="116"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="193"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="199"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="237"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="293"/>
        <source>Scale relative to target page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="303"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="309"/>
        <source>Vertical distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="323"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="382"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="337"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="342"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="398"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="347"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="368"/>
        <source>Horizontal distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="393"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="403"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="411"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="419"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="424"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="461"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="103"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="103"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="113"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="148"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="148"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="209"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="225"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="243"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="263"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="263"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="289"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="83"/>
        <source>Set current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="93"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="112"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="126"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="131"/>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="136"/>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="141"/>
        <source>Italic &amp; Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="162"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="176"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="289"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="348"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="329"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="182"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="217"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="201"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="209"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="225"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="230"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="235"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="240"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="245"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="250"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="255"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="263"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="66"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="208"/>
        <source>Do you want to set the current position?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="210"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CertificateManagerDlg</name>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="14"/>
        <source>Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="24"/>
        <source>Your Certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="33"/>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="53"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="60"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="78"/>
        <source>Trusted System Certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="38"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="72"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="72"/>
        <source>All Supported Files (*.p12 *.pfx *.cer *.crt *.pem);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="88"/>
        <source>A password is required to open certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="100"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="124"/>
        <source>Are you sure you want to delete certificate?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="156"/>
        <source>pfx Files (*.pfx)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="158"/>
        <source>crt Files (*.crt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="160"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="169"/>
        <source>Please, specify private key password:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="14"/>
        <source>Create a new document from files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="154"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="221"/>
        <source>Append to Current Document </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="228"/>
        <source>Create New Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="163"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="169"/>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="179"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="186"/>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="196"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="23"/>
        <source>Add Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="40"/>
        <source>Add Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="98"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="109"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="120"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="144"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="91"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="257"/>
        <source>Import Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="91"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="244"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="31"/>
        <source>Insert Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="32"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="65"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="91"/>
        <source>Total pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="330"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="557"/>
        <source>Save As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="332"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="559"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="363"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="367"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="394"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="587"/>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="588"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="588"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="78"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="88"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="114"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="140"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="36"/>
        <source>Measurement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="71"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="98"/>
        <source>Distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="91"/>
        <source>Angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="121"/>
        <source>Cursor Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="140"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="160"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="183"/>
        <source>Units and Markup Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="276"/>
        <source>Scale Ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="190"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="251"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="195"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="256"/>
        <source>in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="200"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="261"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="269"/>
        <source>=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="283"/>
        <source>Annotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="61"/>
        <source>°</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="24"/>
        <source>Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="28"/>
        <source>Perimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="35"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="38"/>
        <source> sq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="201"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="204"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="208"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="14"/>
        <source>Icon Placement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="20"/>
        <source>Fit to bounds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="27"/>
        <source>When to scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="35"/>
        <source>Proportionally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="40"/>
        <source>Non-Proportionally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="103"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="204"/>
        <source>Scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="222"/>
        <source>Always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="227"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="232"/>
        <source>Icon is too big</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="237"/>
        <source>Icon is too small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="245"/>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="43"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="45"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="23"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="69"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="90"/>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="95"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="100"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="39"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="29"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="27"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="34"/>
        <source>Add Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="35"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="36"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="37"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="38"/>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="52"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="64"/>
        <source>Set Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="981"/>
        <location filename="../../src/docpage/docpage.cpp" line="984"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1567"/>
        <source>The selected area has been copied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2180"/>
        <location filename="../../src/docpage/docpage.cpp" line="2221"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2189"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2199"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2211"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="3276"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="117"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="118"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="120"/>
        <source>Edit Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="121"/>
        <source>Signature options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="122"/>
        <source>Clear Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="124"/>
        <location filename="../../src/docpage/docpage_base.cpp" line="1838"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="125"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="126"/>
        <source>Save Image to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="128"/>
        <source>Edit Path Nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="411"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="420"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1268"/>
        <source>Edit the image and press Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1270"/>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1271"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1394"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1404"/>
        <source>PNG Images (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1816"/>
        <source>Delete Node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2620"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2620"/>
        <source>Image Files (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="109"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="111"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="181"/>
        <source>Show/Hide Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="185"/>
        <source>Select Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="215"/>
        <source>Reset Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="90"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="91"/>
        <source>Enter a file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="122"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="129"/>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="115"/>
        <source>Zoom (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="98"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="136"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="150"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="155"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="160"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="165"/>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="170"/>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="223"/>
        <source> =  -1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="230"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a web site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Named Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="163"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="165"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="95"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="123"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="23"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="29"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="39"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="49"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="79"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="146"/>
        <source>Export bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="156"/>
        <source>Extract pages as a single file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="179"/>
        <source>Delete pages after extracting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="10"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="32"/>
        <location filename="../../src/ExportPageDialog.cpp" line="79"/>
        <source>Export Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="123"/>
        <source>Save As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="125"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="156"/>
        <location filename="../../src/ExportPageDialog.cpp" line="183"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="156"/>
        <location filename="../../src/ExportPageDialog.cpp" line="183"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="88"/>
        <source>Export to text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="93"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="10"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="90"/>
        <source>txt files (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="120"/>
        <location filename="../../src/ExportTextDialog.cpp" line="147"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="120"/>
        <location filename="../../src/ExportTextDialog.cpp" line="147"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="202"/>
        <source>Printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="189"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="254"/>
        <source>Modifying document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="215"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="267"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="141"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="161"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="176"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="228"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="241"/>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="313"/>
        <source>Initial View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="319"/>
        <source>User Interface Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="325"/>
        <source>Hide tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="332"/>
        <source>Hide menu bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="339"/>
        <source>Hide Window Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="349"/>
        <source>Windows Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="369"/>
        <source>Center window on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="355"/>
        <source>Display document title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="362"/>
        <source>Open in Full Screen mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="392"/>
        <source>Layout and Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="498"/>
        <source>Navigation Tab:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="541"/>
        <source>Page layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="415"/>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <location filename="../../src/FileSettings.cpp" line="238"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>Single Page Continuous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>Two-Up (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>Two-Up (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="579"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="534"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="133"/>
        <source>Certificate Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="420"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="425"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="430"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="435"/>
        <location filename="../../src/FileSettings.cpp" line="258"/>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="440"/>
        <location filename="../../src/FileSettings.cpp" line="263"/>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="445"/>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="485"/>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="490"/>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="506"/>
        <source>Page Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="511"/>
        <source>Bookmarks Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="516"/>
        <source>Pages Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="526"/>
        <source>Attachments Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="637"/>
        <location filename="../../src/FileSettings.ui" line="727"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="643"/>
        <source>Document Open Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="649"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="669"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="674"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="679"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="684"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="689"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="694"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="699"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="707"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="714"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="742"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="783"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="521"/>
        <source>Layers Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="587"/>
        <source>Open to Page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="594"/>
        <source>of :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="612"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="628"/>
        <source>Fonts used in this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="710"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="711"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="733"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="14"/>
        <source>Header &amp; Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="130"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="94"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="153"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="71"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="32"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="306"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="312"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="332"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="352"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="208"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="222"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="230"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="382"/>
        <source>Right Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Margins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="40"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="45"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="50"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="389"/>
        <source>Center Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="396"/>
        <source>Left Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="403"/>
        <source>Right Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="410"/>
        <source>Center Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="417"/>
        <source>Left Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="189"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="283"/>
        <source>Insert Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="276"/>
        <source>Insert Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="266"/>
        <source>Page number and date format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="248"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="276"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="276"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="286"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="321"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="321"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="434"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="454"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="474"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InitialsDlg</name>
    <message>
        <location filename="../../src/initials/InitialsDlg.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="37"/>
        <source>Install</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="57"/>
        <source>Stays On Top</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="30"/>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="55"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="62"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="69"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="118"/>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="197"/>
        <source>Press shortcut</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="20"/>
        <source>Keyboard shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="43"/>
        <source>Reset All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="129"/>
        <source>Key sequence has potential conflicts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="35"/>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="50"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="56"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="30"/>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="944"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1783"/>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1980"/>
        <source>Smooth text and images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="960"/>
        <source>Time before a move or resize starts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="973"/>
        <source>Select item by hovering the mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="196"/>
        <source>Saving Documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="236"/>
        <source>Create backup file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="222"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="209"/>
        <source>Last used folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="214"/>
        <source>Original documents folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="395"/>
        <source>Required field highlight color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="375"/>
        <source>Highlight color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="996"/>
        <source>Default font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2964"/>
        <source>Path for DB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="600"/>
        <source>Built-in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3062"/>
        <source>Please choose the interface language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1132"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1199"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1225"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1261"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="306"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2315"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3092"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2156"/>
        <source>Selected text color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2257"/>
        <source>Icon set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2237"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2242"/>
        <source>Office Pro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2189"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2169"/>
        <source>Application Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2335"/>
        <source>Use default program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2354"/>
        <source>evolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2359"/>
        <source>kmail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2364"/>
        <source>thunderbird</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2372"/>
        <source>Use SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2395"/>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2483"/>
        <source>Email address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2476"/>
        <source>Secure connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2451"/>
        <source>NONE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2456"/>
        <source>SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2461"/>
        <source>STARTTLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2443"/>
        <source>SMTP server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2433"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2469"/>
        <source>SMTP port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2416"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2816"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1160"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1165"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1170"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="877"/>
        <source>Always show Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1886"/>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2194"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2199"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2227"/>
        <source>Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2270"/>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2275"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2574"/>
        <source>Default path to tesseract ocr data files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2613"/>
        <source>Additional tesseract ocr config file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2675"/>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2698"/>
        <source>Direct internet connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2708"/>
        <source>Manual proxy configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2724"/>
        <source>HTTP Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2731"/>
        <source>SOCKS 5 Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2741"/>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2751"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2404"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2794"/>
        <source>Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2806"/>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2887"/>
        <source>Default paths for system certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2897"/>
        <source>Database for Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2957"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2913"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2930"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3010"/>
        <source>Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3158"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3163"/>
        <source>Weekly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3168"/>
        <source>Monthly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3144"/>
        <source>Check for Updates Automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="229"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2590"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2629"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="621"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1063"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1271"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1590"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1679"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="592"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1014"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1597"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2250"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="153"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="165"/>
        <source>Restore last session when application start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="172"/>
        <source>Restore last view settings when reopening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1334"/>
        <source>Enable JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="431"/>
        <source> Always hide document message bar </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1848"/>
        <source>Default Layout and Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1893"/>
        <source>Default page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1861"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1904"/>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1866"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1871"/>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1879"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="59"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="64"/>
        <source>JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="89"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="94"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="99"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="109"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="114"/>
        <source>Certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="139"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="259"/>
        <source>Enable scroll wheel zooming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="39"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="79"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="104"/>
        <source>Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="189"/>
        <source>Show Start page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="146"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="182"/>
        <source>Show Quick actions on text selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="276"/>
        <source>Alternative method for PDF render</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="283"/>
        <source>Load all objects separately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="326"/>
        <source>Memory/Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="333"/>
        <source>Minimize memory usage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="338"/>
        <source>Maximal render speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="439"/>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="444"/>
        <source>Edit Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="449"/>
        <source>Check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="454"/>
        <source>Radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="459"/>
        <source>Combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="464"/>
        <source>List box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="469"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="474"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="495"/>
        <source>Borders and Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="502"/>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="507"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="512"/>
        <source>Thick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="520"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="763"/>
        <source>Border Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="527"/>
        <source>Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="535"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="778"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="540"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="783"/>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="545"/>
        <source>Beveled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="550"/>
        <source>Inset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="555"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="788"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="563"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="770"/>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="570"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="749"/>
        <source>Line Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="605"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2265"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="634"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="650"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="661"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="676"/>
        <source>Diamond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="681"/>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="743"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="796"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="807"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="812"/>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="817"/>
        <source>OutLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="822"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="727"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="733"/>
        <source>Add full path to filename in export file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="907"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="922"/>
        <source>Exact match only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="897"/>
        <source>Save last editing Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1125"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1152"/>
        <source>Width between lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1185"/>
        <source>Height between lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1145"/>
        <source>Left offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="833"/>
        <source>Recreate pdf forms when opening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1108"/>
        <source>Edit Text Elements as Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1178"/>
        <source>Top offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1192"/>
        <source>Subdivision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1346"/>
        <source>Show errors and  messages in console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1356"/>
        <source>Enable safe reading mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1448"/>
        <source>Measurements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1453"/>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1458"/>
        <source>Typewriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1780"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1824"/>
        <source>Tooltip Display Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1909"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1914"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1919"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1924"/>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1929"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1934"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1939"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1944"/>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1949"/>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1954"/>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1959"/>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1964"/>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1969"/>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="580"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1989"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2106"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1996"/>
        <source>Bitmap Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2003"/>
        <source>Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2032"/>
        <source>System PPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2091"/>
        <source>Replace Document Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2113"/>
        <source>Page Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="69"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="84"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="489"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2163"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2026"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2042"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1404"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1837"/>
        <source>Pop-up Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1305"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1561"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1705"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1814"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1428"/>
        <source>Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1544"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1298"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1577"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1666"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1433"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1438"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1443"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1278"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1692"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2207"/>
        <source>Icons in menus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="44"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="119"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="124"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="484"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="49"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="54"/>
        <source>Editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="74"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="395"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="410"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="424"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="555"/>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="556"/>
        <source>Armenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="557"/>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="558"/>
        <source>Catalan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="559"/>
        <source>Chinese-Simplified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="560"/>
        <source>Chinese-Traditional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="561"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="562"/>
        <source>Danish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="563"/>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="564"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="565"/>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="566"/>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="567"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="568"/>
        <source>Galician</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="569"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="570"/>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="571"/>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="572"/>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="573"/>
        <source>Irish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="574"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="575"/>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="576"/>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="577"/>
        <source>Latvian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="578"/>
        <source>Lithuanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="579"/>
        <source>Norwegian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="580"/>
        <source>Norwegian-Nynorsk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="581"/>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="582"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="583"/>
        <source>Portuguese-Brazilian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="584"/>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="585"/>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="586"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="587"/>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="588"/>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="589"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="590"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="591"/>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="592"/>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="593"/>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="594"/>
        <source>Valencian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="595"/>
        <source>Vietnamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="596"/>
        <source>Farsi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="618"/>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="687"/>
        <source>In Windows, all certificates are located in system storage.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="692"/>
        <source>In macOS, all certificates are located in system storage.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="706"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1037"/>
        <source>System Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="707"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1041"/>
        <source>Light Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="708"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1045"/>
        <source>Dark Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1604"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1801"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1821"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1841"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="666"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="619"/>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="620"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="671"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="621"/>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="622"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="624"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="625"/>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="626"/>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="627"/>
        <source>Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="628"/>
        <source>Right Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="629"/>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="686"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="630"/>
        <source>Star</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="631"/>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="632"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="633"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="634"/>
        <source>Paper Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="635"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="636"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../src/mainwindow.ui" line="39"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="192"/>
        <location filename="../../src/mainwindow.ui" line="1220"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="196"/>
        <source>Align Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="85"/>
        <location filename="../../src/mainwindow.ui" line="1212"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="225"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="145"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="284"/>
        <location filename="../../src/mainwindow.ui" line="1236"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="155"/>
        <location filename="../../src/mainwindow.ui" line="1228"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="58"/>
        <location filename="../../src/mainwindow.ui" line="1667"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="730"/>
        <location filename="../../src/mainwindow.cpp" line="3619"/>
        <source>Create a new blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="733"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="346"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="15"/>
        <source>Comment View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="18"/>
        <source>Show All Comments with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="29"/>
        <source>Show by Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="81"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="86"/>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="91"/>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="96"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="101"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="130"/>
        <source>Minimum tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="133"/>
        <source>Maximum tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="136"/>
        <source>Reset toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="409"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="428"/>
        <source>Place Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="410"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="429"/>
        <source>Create New Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="412"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="431"/>
        <source>Open Containing Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="442"/>
        <source>Insert Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2809"/>
        <source>All Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2814"/>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2822"/>
        <source>Text Editing Markups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2826"/>
        <source>Stamps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2830"/>
        <source>Attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="33"/>
        <source>Show by Reviewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="43"/>
        <source>Show by Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2855"/>
        <source>All Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2860"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="355"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="394"/>
        <source>Select text for copying and pasting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1707"/>
        <source>Mark for Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1712"/>
        <source>Apply Redactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1717"/>
        <source>Redaction Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1725"/>
        <source>Show Redaction ToolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1730"/>
        <source>Search and Redact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1743"/>
        <source>Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1748"/>
        <source>Send Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1753"/>
        <source>Bring Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1761"/>
        <source>Edit Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1767"/>
        <source>Alt+5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="427"/>
        <source>PgUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="250"/>
        <location filename="../../src/mainwindow.ui" line="1738"/>
        <source>Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="380"/>
        <source>Alt+6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="397"/>
        <source>Alt+7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="438"/>
        <source>PgDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="474"/>
        <source>Ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="499"/>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="521"/>
        <source>Ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="535"/>
        <source>Ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="540"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="546"/>
        <source>Save the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="549"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="554"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="560"/>
        <source>Save the document with a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="563"/>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="746"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="574"/>
        <location filename="../../src/mainwindow.ui" line="752"/>
        <source>Print the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="755"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="582"/>
        <location filename="../../src/mainwindow.ui" line="585"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="588"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="593"/>
        <location filename="../../src/mainwindow.ui" line="596"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="613"/>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="643"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="660"/>
        <source>Select text for editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="663"/>
        <source>Alt+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="668"/>
        <location filename="../../src/mainwindow.ui" line="1387"/>
        <location filename="../../src/mainwindow.ui" line="1433"/>
        <location filename="../../src/mainwindow.ui" line="1446"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="674"/>
        <source>Delete the currently selected object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="724"/>
        <source>Blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="577"/>
        <source>Ctrl+Shift+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="49"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="738"/>
        <source>Pages to Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="766"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="777"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="780"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="791"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="794"/>
        <source>Paste from the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="827"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="835"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="838"/>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="852"/>
        <source>Redo the previously undone action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="866"/>
        <source>Send to Back selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="871"/>
        <source>Bring to Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="874"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="877"/>
        <source>Bring to Front selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="912"/>
        <source>Ctrl+Shift+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="931"/>
        <source>Ctrl+Shift+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="942"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="947"/>
        <location filename="../../src/mainwindow.ui" line="950"/>
        <source>Extract Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="953"/>
        <source>Ctrl+Shift+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="958"/>
        <location filename="../../src/mainwindow.ui" line="961"/>
        <source>Insert Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="964"/>
        <source>Ctrl+Shift+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="980"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="983"/>
        <source>Open window with document properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="997"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1000"/>
        <source>Click the page to add a note at that position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1003"/>
        <source>Ctrl+6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1032"/>
        <location filename="../../src/mainwindow.cpp" line="5077"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1035"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1038"/>
        <source>Insert new text to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1041"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1046"/>
        <location filename="../../src/mainwindow.cpp" line="5086"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1049"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1052"/>
        <source>Insert new image to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1055"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1095"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1098"/>
        <source>Insert new link to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1106"/>
        <source>Text Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1117"/>
        <source>Check Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1125"/>
        <source>Radio Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1133"/>
        <source>Combo Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1141"/>
        <source>List Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1185"/>
        <source>Check for Updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1252"/>
        <location filename="../../src/mainwindow.ui" line="1255"/>
        <source>Open Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1260"/>
        <location filename="../../src/mainwindow.ui" line="1263"/>
        <source>Crop Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1266"/>
        <source>Ctrl+K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1271"/>
        <location filename="../../src/mainwindow.ui" line="1274"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1279"/>
        <location filename="../../src/mainwindow.ui" line="1282"/>
        <location filename="../../src/mainwindow.ui" line="1285"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1290"/>
        <source>Export Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1295"/>
        <source>Import Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1300"/>
        <source>Export Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1305"/>
        <source>Import Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1310"/>
        <source>Save Optimized As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1313"/>
        <source>Ctrl+Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1324"/>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1337"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1342"/>
        <source>Document Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1350"/>
        <source>Replace Document Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1355"/>
        <source>Paste to Multiple Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1358"/>
        <source>Ctrl+Shift+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1363"/>
        <source>JavaScript Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1366"/>
        <source>Ctrl+J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1371"/>
        <source>Page Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1379"/>
        <location filename="../../src/mainwindow.ui" line="1425"/>
        <location filename="../../src/mainwindow.ui" line="1438"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1382"/>
        <source>Ctrl+Shift+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1398"/>
        <source>Menu Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1401"/>
        <source>F9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1409"/>
        <source>Show Cover Page During Facing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1417"/>
        <source>Full Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1420"/>
        <source>F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1428"/>
        <source>Ctrl+Shift+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1441"/>
        <source>Ctrl+Shift+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1451"/>
        <location filename="../../src/mainwindow.ui" line="1454"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1459"/>
        <location filename="../../src/mainwindow.ui" line="1462"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1467"/>
        <source>Find Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1470"/>
        <source>Shift+F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1475"/>
        <source>Pages to Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1494"/>
        <source>Send file via email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1681"/>
        <source>F12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1686"/>
        <source>Typewriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1691"/>
        <source>Callout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1696"/>
        <source>Formatted Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1699"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1764"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Vector Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select vector Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1788"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select bitmap Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1796"/>
        <location filename="../../src/mainwindow.cpp" line="2940"/>
        <source>Show Comments List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1812"/>
        <source>Extract all Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1817"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1825"/>
        <source>Take a Snapshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1830"/>
        <source>Toolbar Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1838"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1846"/>
        <source>Continuous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1480"/>
        <location filename="../../src/mainwindow.ui" line="1483"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="349"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="374"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="391"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="543"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="557"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="568"/>
        <source>System Print...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="571"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;System Print Dialog&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print using system dialog...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="640"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="657"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Objects&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="671"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="699"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Forms&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="727"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="749"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="763"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1488"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1491"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1502"/>
        <location filename="../../src/mainwindow.ui" line="1505"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1508"/>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1516"/>
        <location filename="../../src/mainwindow.ui" line="1519"/>
        <source>Snap to Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1522"/>
        <source>Ctrl+Shift+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1530"/>
        <location filename="../../src/mainwindow.ui" line="1533"/>
        <source>Distance Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1541"/>
        <location filename="../../src/mainwindow.ui" line="1544"/>
        <source>Perimeter Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1552"/>
        <location filename="../../src/mainwindow.ui" line="1555"/>
        <source>Area Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1574"/>
        <location filename="../../src/mainwindow.ui" line="1577"/>
        <source>Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1618"/>
        <location filename="../../src/mainwindow.ui" line="1621"/>
        <source>Attach a File as a Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1626"/>
        <source>From Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1629"/>
        <location filename="../../src/mainwindow.ui" line="1632"/>
        <source>Create a new document from scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1637"/>
        <source>From Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1640"/>
        <location filename="../../src/mainwindow.ui" line="1643"/>
        <source>Create a new document from files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1659"/>
        <location filename="../../src/mainwindow.ui" line="1662"/>
        <source>Brush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1678"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="860"/>
        <source>Send to Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="863"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="677"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1196"/>
        <source>Statusbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="410"/>
        <location filename="../../src/mainwindow.ui" line="413"/>
        <source>First Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="421"/>
        <location filename="../../src/mainwindow.ui" line="424"/>
        <source>Previous Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="432"/>
        <location filename="../../src/mainwindow.ui" line="435"/>
        <source>Next Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="443"/>
        <location filename="../../src/mainwindow.ui" line="446"/>
        <source>Last Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="688"/>
        <source>Alt+Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1120"/>
        <source>Check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1109"/>
        <source>Edit Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1128"/>
        <source>Radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1144"/>
        <source>List box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1136"/>
        <source>Combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1204"/>
        <source>Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1157"/>
        <location filename="../../src/mainwindow.ui" line="1160"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="813"/>
        <location filename="../../src/mainwindow.ui" line="816"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1060"/>
        <location filename="../../src/mainwindow.ui" line="1063"/>
        <location filename="../../src/mainwindow.ui" line="1563"/>
        <location filename="../../src/mainwindow.ui" line="1566"/>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1068"/>
        <location filename="../../src/mainwindow.ui" line="1071"/>
        <location filename="../../src/mainwindow.ui" line="1585"/>
        <location filename="../../src/mainwindow.ui" line="1588"/>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1076"/>
        <location filename="../../src/mainwindow.ui" line="1079"/>
        <location filename="../../src/mainwindow.ui" line="1596"/>
        <location filename="../../src/mainwindow.ui" line="1599"/>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="882"/>
        <location filename="../../src/mainwindow.ui" line="885"/>
        <source>Align Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="890"/>
        <location filename="../../src/mainwindow.ui" line="893"/>
        <source>Align Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="898"/>
        <location filename="../../src/mainwindow.ui" line="901"/>
        <source>Align Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="969"/>
        <location filename="../../src/mainwindow.ui" line="972"/>
        <source>Align Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="626"/>
        <location filename="../../src/mainwindow.ui" line="629"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="618"/>
        <location filename="../../src/mainwindow.ui" line="621"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="741"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="906"/>
        <location filename="../../src/mainwindow.ui" line="909"/>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="977"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="989"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1101"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1112"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1175"/>
        <source>Home page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1180"/>
        <source>Register...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="832"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="841"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1084"/>
        <location filename="../../src/mainwindow.ui" line="1087"/>
        <location filename="../../src/mainwindow.ui" line="1607"/>
        <location filename="../../src/mainwindow.ui" line="1610"/>
        <source>Pencil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1149"/>
        <location filename="../../src/mainwindow.ui" line="1152"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="454"/>
        <location filename="../../src/mainwindow.ui" line="457"/>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="460"/>
        <source>Ctrl++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="479"/>
        <location filename="../../src/mainwindow.ui" line="482"/>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="485"/>
        <source>Ctrl+-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="468"/>
        <location filename="../../src/mainwindow.ui" line="471"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="402"/>
        <location filename="../../src/mainwindow.ui" line="405"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1170"/>
        <source>Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="493"/>
        <location filename="../../src/mainwindow.ui" line="496"/>
        <source>Highlight Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="371"/>
        <location filename="../../src/mainwindow.ui" line="377"/>
        <source>Hand Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="654"/>
        <source>Edit Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="925"/>
        <location filename="../../src/mainwindow.ui" line="928"/>
        <source>Page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="846"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="855"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="760"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="97"/>
        <source>Page Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="106"/>
        <source>Go To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="118"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="172"/>
        <location filename="../../src/mainwindow.ui" line="1244"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="229"/>
        <source>Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="236"/>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="243"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="288"/>
        <source>Measurements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="296"/>
        <location filename="../../src/mainwindow.cpp" line="2818"/>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="360"/>
        <location filename="../../src/mainwindow.ui" line="363"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="416"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="449"/>
        <source>End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="504"/>
        <location filename="../../src/mainwindow.ui" line="507"/>
        <source>Reset Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="515"/>
        <location filename="../../src/mainwindow.ui" line="518"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="529"/>
        <location filename="../../src/mainwindow.ui" line="532"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="599"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="607"/>
        <location filename="../../src/mainwindow.ui" line="610"/>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="682"/>
        <location filename="../../src/mainwindow.ui" line="685"/>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="696"/>
        <location filename="../../src/mainwindow.ui" line="702"/>
        <location filename="../../src/mainwindow.ui" line="1651"/>
        <source>Edit Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="719"/>
        <source>Ctrl+F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="769"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="774"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="783"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="788"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="797"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="802"/>
        <location filename="../../src/mainwindow.ui" line="805"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="808"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="637"/>
        <source>Edit Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="646"/>
        <source>Alt+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1092"/>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1008"/>
        <location filename="../../src/mainwindow.ui" line="1011"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="994"/>
        <source>Add Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1016"/>
        <location filename="../../src/mainwindow.ui" line="1019"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1024"/>
        <location filename="../../src/mainwindow.ui" line="1027"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="388"/>
        <source>Select Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="705"/>
        <source>Alt+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1165"/>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="821"/>
        <location filename="../../src/mainwindow.ui" line="824"/>
        <location filename="../../src/mainwindow.ui" line="1332"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1321"/>
        <source>Find Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="936"/>
        <location filename="../../src/mainwindow.ui" line="939"/>
        <source>Rotate Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="917"/>
        <location filename="../../src/mainwindow.ui" line="920"/>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1772"/>
        <source>Next View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1777"/>
        <source>Previous View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1785"/>
        <source>Edit Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1791"/>
        <source>Alt+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2318"/>
        <source>Open failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2319"/>
        <source>Cannot open file :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="64"/>
        <source>Empty recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="352"/>
        <source>Open a PDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="945"/>
        <location filename="../../src/mainwindow.cpp" line="5987"/>
        <location filename="../../src/mainwindow.cpp" line="6049"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="986"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2150"/>
        <source>Recent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="362"/>
        <location filename="../../src/mainwindow.cpp" line="468"/>
        <location filename="../../src/mainwindow.cpp" line="536"/>
        <location filename="../../src/mainwindow.cpp" line="586"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="429"/>
        <source>The file you are attempting to open contains comments or form data that are supposed to be placed on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="431"/>
        <source>This document cannot be found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="431"/>
        <source>Would you like to browse and attempt to locate this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1194"/>
        <source>Export completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1217"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1406"/>
        <location filename="../../src/mainwindow.cpp" line="1433"/>
        <source>Can&apos;t find :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1455"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1497"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2550"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2557"/>
        <source>Close Without Saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2558"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2785"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="36"/>
        <source>All Reviewers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2918"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="16"/>
        <source>Hide All Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2923"/>
        <source>Show All Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2936"/>
        <source>Hide Comments List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3107"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3120"/>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3142"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3155"/>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3177"/>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3190"/>
        <source>Do you want to delete the Background from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4427"/>
        <location filename="../../src/mainwindow.cpp" line="4449"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4588"/>
        <source>Master PDF Editor can&apos;t find any Redaction in the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4701"/>
        <source>Your installed version of Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5071"/>
        <source>Characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5072"/>
        <source>Font type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5074"/>
        <source>Font Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5076"/>
        <source>Font Not Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5082"/>
        <location filename="../../src/mainwindow.cpp" line="5251"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5083"/>
        <location filename="../../src/mainwindow.cpp" line="5252"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5084"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5090"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5094"/>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="323"/>
        <location filename="../../src/mainwindow.ui" line="1807"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5119"/>
        <location filename="../../src/mainwindow.cpp" line="5262"/>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5251"/>
        <location filename="../../src/mainwindow.cpp" line="5252"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5271"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5996"/>
        <location filename="../../src/mainwindow.cpp" line="6017"/>
        <location filename="../../src/mainwindow.cpp" line="6020"/>
        <location filename="../../src/mainwindow.cpp" line="6058"/>
        <location filename="../../src/mainwindow.cpp" line="6078"/>
        <location filename="../../src/mainwindow.cpp" line="6081"/>
        <source>FDF Files (*.fdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2678"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="907"/>
        <location filename="../../src/mainwindow.cpp" line="1025"/>
        <location filename="../../src/mainwindow.cpp" line="3720"/>
        <location filename="../../src/mainwindow.cpp" line="3830"/>
        <location filename="../../src/mainwindow.cpp" line="3939"/>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="43"/>
        <source>Ctrl+F12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="353"/>
        <source>You do not have access right to this encrypted document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="355"/>
        <source>It is encrypted with certificate absent from your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5098"/>
        <source>Text Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5165"/>
        <source>All Supported Files (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF Files (*.pdf *.PDF);;FDF Files (*.fdf *.FDF);;XPS Files (*.xps *.XPS);;TIFF Files (*.tif *.tiff);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="908"/>
        <location filename="../../src/mainwindow.cpp" line="1026"/>
        <location filename="../../src/mainwindow.cpp" line="3721"/>
        <location filename="../../src/mainwindow.cpp" line="3831"/>
        <location filename="../../src/mainwindow.cpp" line="3940"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="908"/>
        <location filename="../../src/mainwindow.cpp" line="1026"/>
        <location filename="../../src/mainwindow.cpp" line="3721"/>
        <location filename="../../src/mainwindow.cpp" line="3831"/>
        <location filename="../../src/mainwindow.cpp" line="3940"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="15"/>
        <source>Cannot connect! Please verify that you are connected to the Internet and check for updates again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="31"/>
        <source>You already have the latest version!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="38"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="42"/>
        <source>What&apos;s new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5169"/>
        <location filename="../../src/mainwindow.cpp" line="5171"/>
        <location filename="../../src/mainwindow.cpp" line="6017"/>
        <location filename="../../src/mainwindow.cpp" line="6020"/>
        <location filename="../../src/mainwindow.cpp" line="6078"/>
        <location filename="../../src/mainwindow.cpp" line="6081"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="713"/>
        <location filename="../../src/mainwindow.ui" line="716"/>
        <location filename="../../src/mainwindow.ui" line="1249"/>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="125"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="89"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="17"/>
        <source>Not Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="78"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="88"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="140"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="152"/>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="162"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="211"/>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="218"/>
        <source>Last</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="194"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="231"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="33"/>
        <source>A0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="38"/>
        <source>A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="43"/>
        <source>A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="48"/>
        <source>A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="53"/>
        <source>A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="58"/>
        <source>A5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="63"/>
        <source>A6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="68"/>
        <source>A7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="73"/>
        <source>A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="78"/>
        <source>A9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="83"/>
        <source>A10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="88"/>
        <source>Letter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="93"/>
        <source>Tabloid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="98"/>
        <source>B0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="103"/>
        <source>B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="108"/>
        <source>B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="113"/>
        <source>B3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="118"/>
        <source>B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="123"/>
        <source>B5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="128"/>
        <source>Statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="133"/>
        <source>Executive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="138"/>
        <source>Folio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="143"/>
        <source>Quarto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="148"/>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="153"/>
        <source>ANSI C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="158"/>
        <source>ANSI D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="163"/>
        <source>ANSI E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="168"/>
        <source>ANSI F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="173"/>
        <source>Custom page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="218"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="223"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="267"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="296"/>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="308"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="348"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="328"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="275"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="280"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="285"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="368"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="391"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="397"/>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="414"/>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="421"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="407"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="431"/>
        <source>Number of pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="457"/>
        <source>Page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="437"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="183"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="210"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="232"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="147"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="153"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="160"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="190"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="200"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="20"/>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="50"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="190"/>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="213"/>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="88"/>
        <source>Searchable Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="98"/>
        <source>Editable Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="118"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="233"/>
        <source>Manually edit all recognized text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="60"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="287"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="59"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="57"/>
        <source>No Properties
There is no object selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="341"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3227"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3508"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2131"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="142"/>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="147"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="923"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="476"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="807"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="486"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2771"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="508"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1879"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1913"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1985"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2041"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2890"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="518"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="794"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="584"/>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="738"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1319"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1465"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1620"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="272"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="743"/>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="748"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="753"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1324"/>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="787"/>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="820"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1095"/>
        <source>Export Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="660"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="862"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="665"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="846"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="890"/>
        <source>Sort Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="869"/>
        <source>Commit selected value immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="883"/>
        <source>Multiple selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="876"/>
        <source>Allow user to enter custom text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1028"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1035"/>
        <source>Scrollable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1042"/>
        <source>Check spelling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="963"/>
        <source>Limit to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="977"/>
        <source>chars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="984"/>
        <source>Split into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="956"/>
        <source>Allow Rich Text formatting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1021"/>
        <source>Multi-line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="998"/>
        <source>cells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="938"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2519"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="943"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="948"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1008"/>
        <source>Default Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="930"/>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1108"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2657"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1119"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1124"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="248"/>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1129"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="250"/>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1134"/>
        <source>Diamond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1139"/>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1144"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="259"/>
        <source>Star</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1072"/>
        <source>Checked by Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="591"/>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="602"/>
        <source>Label only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="607"/>
        <source>Icon only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="612"/>
        <source>Icon top, label bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="617"/>
        <source>Label top, icon bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="622"/>
        <source>Icon left, label right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="627"/>
        <source>label left, icon right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="632"/>
        <source>Label over icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="647"/>
        <source>Icon and Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="670"/>
        <source>Rollover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="687"/>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="694"/>
        <source>Choose Icon...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="717"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="724"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1196"/>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1261"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3217"/>
        <source>Line Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1275"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3167"/>
        <source>Border Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1282"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3210"/>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1290"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3182"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1295"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3187"/>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1300"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3202"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1308"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1329"/>
        <source>OutLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1334"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1352"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1411"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2790"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2909"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1451"/>
        <source>Format category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1470"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1475"/>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1480"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1485"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1490"/>
        <source>Special</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1495"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1650"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="234"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="238"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1514"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1519"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1524"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1529"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1534"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1539"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1544"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1549"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1554"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1559"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1564"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1573"/>
        <source>1,234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1578"/>
        <source>1234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1583"/>
        <source>1.234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1588"/>
        <source>1234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1602"/>
        <source>Currency Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1625"/>
        <source>Dollar ($)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1630"/>
        <source>Euro (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1635"/>
        <source>Pound (£)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1640"/>
        <source>Yen (¥)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1671"/>
        <source>Show parentheses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1691"/>
        <source>Decimal Places</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1698"/>
        <source>Separation Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1705"/>
        <source>Use red text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1722"/>
        <source>Date Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1761"/>
        <source>Time Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1794"/>
        <source>Special Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1852"/>
        <source>Format Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1886"/>
        <source>KeyStroke Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1937"/>
        <source>Validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1958"/>
        <source>Validation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1993"/>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2014"/>
        <source>Calculation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2143"/>
        <source>Fill text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2148"/>
        <source>Stroke Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2153"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3007"/>
        <source>Fill and Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2158"/>
        <source>Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2172"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3174"/>
        <source>Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2198"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3075"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3465"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2227"/>
        <source>Character spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2234"/>
        <source>Word spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2241"/>
        <source>Line height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2284"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2303"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2366"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2392"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2402"/>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2412"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2422"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2432"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2499"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2547"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2928"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2950"/>
        <source>Always show Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3551"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2476"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="640"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1645"/>
        <source>Ruble (₽)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2575"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2695"/>
        <source>Clipping Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2828"/>
        <source>Selection change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2856"/>
        <source>Do nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2863"/>
        <source>Execute this script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2997"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3015"/>
        <source>Fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3192"/>
        <source>Beveled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3197"/>
        <source>Inset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3252"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3316"/>
        <source>ToolTip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3332"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3340"/>
        <source>0 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3345"/>
        <source>90 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3350"/>
        <source>180 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3355"/>
        <source>270 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3376"/>
        <source>Read Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3391"/>
        <source>Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3396"/>
        <source>Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3401"/>
        <source>Visible but doesn&apos;t print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3406"/>
        <source>Hidden but printable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3414"/>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3424"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3558"/>
        <source>Locked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3501"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3538"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2078"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2107"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3239"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2123"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2977"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3528"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2526"/>
        <source>Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2534"/>
        <source>Absolute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2539"/>
        <source>Relative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2583"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2588"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2593"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2616"/>
        <source>Geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2638"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3281"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2676"/>
        <source>Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2714"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2733"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2752"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2809"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3002"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3050"/>
        <source>Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3040"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3062"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3268"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3491"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3142"/>
        <source>Borders and Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3149"/>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3154"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3159"/>
        <source>Thick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2185"/>
        <source>Stroke Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2211"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3027"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3088"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3478"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Zip Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Zip Code+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Phone Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Social Security Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="247"/>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="249"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="251"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="253"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="254"/>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="255"/>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="256"/>
        <source>Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="257"/>
        <source>Right Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="258"/>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="260"/>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="261"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="262"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="263"/>
        <source>Paper Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="264"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="265"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1113"/>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1642"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1649"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1662"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1669"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1715"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1721"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1897"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4010"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1902"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4030"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1906"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4050"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2155"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2197"/>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2265"/>
        <source>Text Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2489"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2509"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2176"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3383"/>
        <source>Form Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3306"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1654"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1703"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3123"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="432"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="364"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="370"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="378"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="383"/>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="388"/>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="393"/>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="398"/>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="403"/>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="424"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="437"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="442"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="447"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="452"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="457"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="462"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="14"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="33"/>
        <source>Object TreeView</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="20"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="40"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="79"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="248"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="274"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="328"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="20"/>
        <source>Expand All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="21"/>
        <source>Collapse All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="77"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="120"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="88"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="93"/>
        <source>Paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="98"/>
        <source>Shadings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="103"/>
        <source>Containers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="126"/>
        <source>Text Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="131"/>
        <source>List Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="136"/>
        <source>Combo Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="141"/>
        <source>Check Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="146"/>
        <source>Radio Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="151"/>
        <source>Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="156"/>
        <source>Links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="161"/>
        <source>Signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="234"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="235"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="294"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionToolBarForm</name>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="20"/>
        <source>Tollbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="71"/>
        <source>All tools:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="85"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="159"/>
        <source>Current toolbar tools:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="248"/>
        <source>Toolbars:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="265"/>
        <source>Add Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="272"/>
        <source>Delete Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="288"/>
        <source>Reset All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="295"/>
        <source>Maximum tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="300"/>
        <source>Minimum tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="167"/>
        <source>Please, name new toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="189"/>
        <source>ToolBar with this name already exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="511"/>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="543"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PDFTextEdit</name>
    <message>
        <location filename="../../src/docpage/texteditor/PDFTextEdit.cpp" line="331"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="105"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="26"/>
        <location filename="../../src/PageLayoutDialog.ui" line="59"/>
        <location filename="../../src/PageLayoutDialog.ui" line="72"/>
        <location filename="../../src/PageLayoutDialog.ui" line="85"/>
        <location filename="../../src/PageLayoutDialog.ui" line="298"/>
        <location filename="../../src/PageLayoutDialog.ui" line="315"/>
        <location filename="../../src/PageLayoutDialog.ui" line="332"/>
        <location filename="../../src/PageLayoutDialog.ui" line="349"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="413"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="49"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="42"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="112"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="279"/>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="291"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="308"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="325"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="342"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="20"/>
        <location filename="../../src/PageLayoutDialog.ui" line="98"/>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="433"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="448"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="362"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="146"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="122"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="130"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="135"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="152"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="164"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="201"/>
        <source>of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="212"/>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="217"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="222"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="243"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="373"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="378"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="383"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="253"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="181"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="41"/>
        <source>Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="60"/>
        <source>Use Row Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="67"/>
        <source>Use Column Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="53"/>
        <source>Use Document Structure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="74"/>
        <source>Unspecified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="111"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="117"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="192"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="205"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="236"/>
        <source>Open Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="241"/>
        <source>Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="198"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="255"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="260"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="265"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="270"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="275"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="280"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="212"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="30"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="34"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="132"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="151"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="14"/>
        <source>Printer Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="20"/>
        <source>Paper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="26"/>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="58"/>
        <source>Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="77"/>
        <source>Page size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="87"/>
        <source>Margins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="95"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="98"/>
        <source>bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="111"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="114"/>
        <source>top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="174"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="177"/>
        <source>left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="206"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="209"/>
        <source>right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="264"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="271"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="285"/>
        <source>72</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="290"/>
        <source>96</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="295"/>
        <source>100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="300"/>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="305"/>
        <source>200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="310"/>
        <source>240</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="315"/>
        <source>300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="320"/>
        <source>400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="325"/>
        <source>600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="330"/>
        <source>760</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="335"/>
        <source>800</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="340"/>
        <source>1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="345"/>
        <source>2400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="399"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="404"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="409"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="455"/>
        <source>Paper Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="313"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="332"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="348"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="39"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="45"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="71"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="91"/>
        <source>All pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="101"/>
        <source>Except current one</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlaceInitialsDlg</name>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="14"/>
        <source>Place Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="26"/>
        <source>How would like to create your initials?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="33"/>
        <source>Type my initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="38"/>
        <source>Draw my initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="43"/>
        <source>Select signature image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="90"/>
        <source>Enter your initials:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="97"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="241"/>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="245"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="128"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="167"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="197"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="353"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="234"/>
        <source>Change Initials Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="261"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="275"/>
        <source>Review Initials:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="315"/>
        <source>Draw Initials:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="386"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="425"/>
        <source>Browse and select an image of your signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="445"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="67"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="95"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="179"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="179"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="245"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <location filename="../../src/docpage/texteditor/plaintextedit.cpp" line="225"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="277"/>
        <source>Print as Grayscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="590"/>
        <source>Multiple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="745"/>
        <source>Aspect Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="753"/>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="758"/>
        <source>Keep aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="763"/>
        <source>Keep aspect ratio by expanding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="792"/>
        <location filename="../../src/printdialog/printdialog.ui" line="986"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="799"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="806"/>
        <source>Shrink to printable area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="826"/>
        <location filename="../../src/printdialog/printdialog.ui" line="879"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="845"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="858"/>
        <location filename="../../src/printdialog/printdialog.ui" line="953"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="872"/>
        <source>Overlay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1007"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1178"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1012"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1183"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1017"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1188"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="973"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1109"/>
        <source>Pages per sheet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1116"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1124"/>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1129"/>
        <source>Horizontal Reversed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1134"/>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1139"/>
        <source>Vertical Reversed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1163"/>
        <source>Additional spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1170"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1042"/>
        <source>Center pages in cells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="340"/>
        <source>Duplex Printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="87"/>
        <location filename="../../src/printdialog/printdialog.ui" line="348"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="353"/>
        <location filename="../../src/printdialog/printdialog.ui" line="669"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="358"/>
        <source>Long side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="363"/>
        <source>Short side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="543"/>
        <source>Poster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="565"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="674"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="679"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="496"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="393"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="402"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="410"/>
        <source>All pages in range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="415"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="420"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="435"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="445"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="455"/>
        <source>Subset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="462"/>
        <source>Current view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="625"/>
        <source>Number of copies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="652"/>
        <source>Collate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="305"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="318"/>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="67"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="73"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="98"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="215"/>
        <source>Print:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="202"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="207"/>
        <source>Document and Annotations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="148"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="158"/>
        <source>of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1122"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1501"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1512"/>
        <source>of </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="244"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="246"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="286"/>
        <source>Page Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="290"/>
        <source>System Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1365"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1365"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1375"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1412"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1412"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintingMode</name>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="149"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="176"/>
        <source>There was an error printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="151"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="178"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="18"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="23"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="23"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="23"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="23"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="38"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="39"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="111"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="115"/>
        <source>Attachment Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="500"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="574"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="16"/>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="17"/>
        <source>Delete Bookmark(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="18"/>
        <source>Bookmark Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="19"/>
        <source>Set Destination</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="41"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="45"/>
        <source>Close All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="49"/>
        <source>Close All Other Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="53"/>
        <source>Close All Tabs to the Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="65"/>
        <source>Move to New Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="175"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="1181"/>
        <location filename="../../src/document/qdoctab.cpp" line="1204"/>
        <source>The clipboard doesn&apos;t contain any data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="9"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="104"/>
        <source>Zoom to Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="112"/>
        <source>Clear Selections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/app_config.cpp" line="8"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="12"/>
        <source>The unregistered version will insert a watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="17"/>
        <source>Open with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="24"/>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="32"/>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="40"/>
        <source>Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="24"/>
        <location filename="../../src/app_config.cpp" line="36"/>
        <source>32 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="32"/>
        <location filename="../../src/app_config.cpp" line="40"/>
        <source>64 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="67"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="72"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="77"/>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="82"/>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="87"/>
        <source>Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="92"/>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="97"/>
        <source>Confidential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="102"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="107"/>
        <source>Reviewed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="112"/>
        <source>Revised</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="117"/>
        <source>Completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="122"/>
        <source>Draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="127"/>
        <source>Emergency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="132"/>
        <source>Expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="137"/>
        <source>Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="142"/>
        <source>Verified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="147"/>
        <source>Void</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="152"/>
        <source>Accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="157"/>
        <source>Initial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="162"/>
        <source>Rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="167"/>
        <source>SignHere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="172"/>
        <source>Witness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="177"/>
        <source>Dynamic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="182"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="187"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="200"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="205"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="210"/>
        <source>Press Help button to get more info.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="215"/>
        <source>Error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="220"/>
        <source>Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="225"/>
        <location filename="../../src/app_config.cpp" line="705"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="230"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="235"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="240"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="245"/>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="250"/>
        <source>All Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="255"/>
        <location filename="../../src/app_config.cpp" line="660"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="260"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="265"/>
        <source>Container</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="270"/>
        <source>Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="275"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="280"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="285"/>
        <source>StrikeOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="290"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="405"/>
        <source>Typewriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="410"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="415"/>
        <source>Separator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="420"/>
        <source>Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="425"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="430"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="435"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="440"/>
        <source>Email delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="445"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="450"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="455"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="460"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="465"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="470"/>
        <source>Delete Object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="475"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="480"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="485"/>
        <source>Align Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="490"/>
        <source>Align Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="495"/>
        <source>Align Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="500"/>
        <source>Align Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="505"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="510"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="515"/>
        <source>Send To Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="520"/>
        <source>Send Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="525"/>
        <source>Bring Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="530"/>
        <source>Bring To Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="535"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="540"/>
        <source>Snap To Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="545"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="550"/>
        <source>Previous View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="555"/>
        <source>Next View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="560"/>
        <source>Previous Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="565"/>
        <source>Next Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="570"/>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="575"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="580"/>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="585"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="590"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="595"/>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="600"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="605"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="610"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="615"/>
        <source>Edit Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="620"/>
        <source>Edit Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="625"/>
        <source>Edit Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="630"/>
        <source>Edit Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="635"/>
        <source>Edit Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="640"/>
        <source>Edit Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="645"/>
        <source>Hand Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="650"/>
        <source>Select Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="655"/>
        <source>Take Snapshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="665"/>
        <source>Insert Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="670"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="675"/>
        <source>Check Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="680"/>
        <source>Combo Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="685"/>
        <source>Text Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="690"/>
        <source>List Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="695"/>
        <source>Radio Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="700"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="710"/>
        <source>Insert Formatted Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="715"/>
        <source>Insert Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="720"/>
        <source>Insert Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="725"/>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="730"/>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="735"/>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="740"/>
        <source>Pencil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="745"/>
        <source>Attach a File as a Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="750"/>
        <source>Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="755"/>
        <source>Mark for Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="760"/>
        <source>Search And Redact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="765"/>
        <source>Apply Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="770"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="775"/>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="780"/>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="785"/>
        <source>Crop Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="790"/>
        <source>Page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="795"/>
        <source>Rotate Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="800"/>
        <source>Extract Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="805"/>
        <source>Insert Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="810"/>
        <source>Document Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="815"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="820"/>
        <source>Page Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="825"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="830"/>
        <source>Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="835"/>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="840"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="850"/>
        <source>Page Counter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="855"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="860"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="875"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="880"/>
        <source>Draw Comment Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="885"/>
        <source>Measurement Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="905"/>
        <source>Continuous Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="910"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="845"/>
        <location filename="../../src/app_config.cpp" line="865"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="870"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="890"/>
        <source>Stamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="895"/>
        <source>Comment View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="900"/>
        <source>Place Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="295"/>
        <source>Text Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="300"/>
        <source>Formatted Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="305"/>
        <source>Issued by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="310"/>
        <source>Expires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="315"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="320"/>
        <source>Cancelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="325"/>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="330"/>
        <source>Not Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="335"/>
        <source>Open Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="340"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="345"/>
        <source>Review History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="350"/>
        <source>Make Current Properties Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="355"/>
        <source>Error Loading Image!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="360"/>
        <source>Incorrect date/time format. Please, insert date/time to match format: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="365"/>
        <source>You have exceeded the number of available activations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="370"/>
        <source>Please, deactivate your license on another PC.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="375"/>
        <source>Your license doesn&apos;t allow to use this version. Please, renew your license.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="380"/>
        <source>Your license is expired. Please, renew your license.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="385"/>
        <source>Impossible to verify your license! Check your internet connection and press Verify Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="390"/>
        <source>Print using Windows API</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="395"/>
        <source>Do not show this message again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="400"/>
        <source>If OpenSSL is not installed, encryption and signature functionality will be unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="53"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="56"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="53"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="56"/>
        <source>FDF Files (*.fdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="23"/>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>Page Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>Page Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Page Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Page Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Open Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>KeyStroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="55"/>
        <source>Close Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="57"/>
        <source>Save Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="59"/>
        <source>Document Saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="61"/>
        <source>Print Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="63"/>
        <source>Document Printed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="78"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="88"/>
        <source>Thread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Movie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="100"/>
        <source>Submit Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="102"/>
        <source>Reset Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Import Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="106"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="110"/>
        <source>Rendition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="114"/>
        <source>Goto 3D View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="28"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="3363"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="721"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="723"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="725"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="727"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="737"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="739"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="733"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="735"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="737"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="739"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2901"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3367"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3372"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3418"/>
        <source>PDF document action attempts to submit form data to another location. Proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3452"/>
        <source>There was a problem with your form submission.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3454"/>
        <source>Your form was successfully submitted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="37"/>
        <source>Open Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="42"/>
        <source>Blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="47"/>
        <source>From Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="53"/>
        <source>Empty recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="58"/>
        <source>From Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="65"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="71"/>
        <source>User Guide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="81"/>
        <source>Register...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="87"/>
        <source>Buy Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="369"/>
        <source>Create New Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="373"/>
        <source>Pinned Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="391"/>
        <source>Recent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="884"/>
        <source>You have reached the limit of 10 pinned files.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="146"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="151"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="154"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="189"/>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="201"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="211"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="215"/>
        <source>Object TreeView</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="232"/>
        <source>Signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="247"/>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="512"/>
        <source>Layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="631"/>
        <source>This document contains interactive form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="632"/>
        <source>Highlight Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="641"/>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="642"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="691"/>
        <source>Registration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1418"/>
        <source>Error loading font: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1448"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3159"/>
        <source>Do you want to open?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4069"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4072"/>
        <source>Set current zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4159"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage_print.cpp" line="642"/>
        <location filename="../../src/docpage/qtabpage_print.cpp" line="670"/>
        <source>There was an error printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage_print.cpp" line="644"/>
        <location filename="../../src/docpage/qtabpage_print.cpp" line="672"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="8"/>
        <source>Millimeters (mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="9"/>
        <source>Inches (in)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="10"/>
        <source>Points (pt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="11"/>
        <source>Pica (P̸)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="12"/>
        <source>Didot (DD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="13"/>
        <source>Cicero (CC)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="35"/>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="39"/>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="43"/>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="47"/>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="51"/>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="55"/>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="136"/>
        <source>More...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="325"/>
        <source>User Color 99</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="339"/>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="340"/>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="341"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="342"/>
        <source>Dark red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="343"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="344"/>
        <source>Dark green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="345"/>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="346"/>
        <source>Dark blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="347"/>
        <source>Cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="348"/>
        <source>Dark cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="349"/>
        <source>Magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="350"/>
        <source>Dark magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="351"/>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="352"/>
        <source>Dark yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="353"/>
        <source>Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="354"/>
        <source>Dark gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="355"/>
        <source>Light gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="357"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RedactionCodesDlg</name>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="14"/>
        <source>Redaction Code Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="30"/>
        <source>Code Sets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="49"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="150"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="56"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="157"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="76"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="180"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="101"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="108"/>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="134"/>
        <source>Code Entries</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RedactionDlg</name>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="169"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="41"/>
        <source>Redacted Area Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="48"/>
        <source>Use Overlay Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="73"/>
        <source>Code Sets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="80"/>
        <source>Code Entries:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="113"/>
        <source>Edit Codes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="64"/>
        <source>Redaction Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="123"/>
        <source>Auto-size text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="130"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="137"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="149"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="198"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="57"/>
        <source>Repeat Overlay Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="341"/>
        <source>Registration Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="361"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="199"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="212"/>
        <source>Registered version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="219"/>
        <source>If you want to register that license on another PC click the &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="256"/>
        <source>Purchased On:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="263"/>
        <source>Maintenance Plan Expires:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="351"/>
        <source>Activation Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="381"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="388"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="402"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="24"/>
        <source>Thanks for registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="25"/>
        <source>License is deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="27"/>
        <source>Too many activations!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="30"/>
        <source>License is expired!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="48"/>
        <source>Please, renew your license</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="324"/>
        <location filename="../../src/regdialog.cpp" line="474"/>
        <source>Incorrect registration code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="519"/>
        <source>Renew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="548"/>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact support@code-industry.net</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="353"/>
        <location filename="../../src/regdialog.cpp" line="576"/>
        <source>Activation failed! Check internet connection.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="20"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="52"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="62"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="72"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="83"/>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="88"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="93"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="101"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="111"/>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="118"/>
        <source>Clockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="123"/>
        <source>180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="128"/>
        <source>Counterclockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="318"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="327"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="250"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="262"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="278"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="295"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="61"/>
        <location filename="../../src/SaveImageDialog.ui" line="130"/>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="26"/>
        <source>BMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="33"/>
        <source>PNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="71"/>
        <source>TIFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="40"/>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="110"/>
        <source>LZW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="115"/>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>CCITT FAX 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="125"/>
        <source>CCITT FAX 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="47"/>
        <source>TIFF Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="54"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="138"/>
        <source>MultiPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="154"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="183"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="337"/>
        <source>Antialiasing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="379"/>
        <source>Export:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="387"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="392"/>
        <source>Document and Annotations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="13"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="14"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="77"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="77"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="444"/>
        <source>Save As TIFF Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="444"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="463"/>
        <source>Save As Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="463"/>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="323"/>
        <source>Remove unused elements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="313"/>
        <source>Flatten form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="166"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="57"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="178"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="211"/>
        <source>Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="110"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="231"/>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="236"/>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="244"/>
        <source>Lossless</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="264"/>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="333"/>
        <source>Merge all layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="45"/>
        <source>Black and White Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="115"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="120"/>
        <source>JBIG2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="12"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="12"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="10"/>
        <source>Scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="37"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="62"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="67"/>
        <source>All Pages From Feeder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="101"/>
        <source>Scan:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="143"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="84"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="74"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="152"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="93"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="83"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="158"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="99"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="89"/>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="168"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="109"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="99"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="175"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="116"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="106"/>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="185"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="126"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="116"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="220"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="161"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="141"/>
        <source>Append to Current Document </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="210"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="151"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="148"/>
        <source>Create New Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="49"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="20"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="36"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="132"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="42"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="64"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="81"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="35"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="48"/>
        <source>Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="121"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="233"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="174"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="164"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="263"/>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="302"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="322"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="219"/>
        <source>Looking for devices. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="55"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="41"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="33"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="123"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="344"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="293"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="324"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="164"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="201"/>
        <source>Save As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="125"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="346"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="295"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="326"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="166"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="203"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="48"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="58"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="68"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="265"/>
        <source>Flatbed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="267"/>
        <source>Positive Transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="269"/>
        <source>Negative Transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="271"/>
        <source>Document Feeder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="14"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="30"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="33"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="36"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="39"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="59"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="62"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="65"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="68"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="115"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="196"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="62"/>
        <source>0 result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="69"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="126"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="175"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="225"/>
        <source>Check All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="105"/>
        <source>Mark Checked Results for Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="11"/>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="15"/>
        <source>Include Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Whole Words Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="84"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="94"/>
        <source> result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="96"/>
        <source> result(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="98"/>
        <source> results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="221"/>
        <source>Uncheck All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="118"/>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="119"/>
        <source>Include Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="120"/>
        <source>Whole Words Only</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityCertificateDialog</name>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="14"/>
        <source>Certificate Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="51"/>
        <source>Recipient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="64"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="82"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="98"/>
        <source>Modifying document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="114"/>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="130"/>
        <source>Printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="146"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="162"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="178"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="194"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="210"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="216"/>
        <source>128 bit AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="226"/>
        <source>256 bit AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="272"/>
        <source>Recipients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="278"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="24"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="26"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="33"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="33"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="14"/>
        <source>Password Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="71"/>
        <location filename="../../src/security/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="233"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="275"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="288"/>
        <source>40 bit RC4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="293"/>
        <source>128 bit RC4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="298"/>
        <source>128 bit AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="303"/>
        <source>256 bit AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="96"/>
        <source>Document Open password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="108"/>
        <source>Document Permission password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetLinkDlg</name>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="14"/>
        <source>Set Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="20"/>
        <source>Use the scrollbars, mouse and zoom tools to select the target view, then press Set Link to create the Link destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="46"/>
        <source>Set Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="53"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="60"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="80"/>
        <source>Set current zoom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="46"/>
        <source>Signature is VALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="366"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="403"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="449"/>
        <source>Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="373"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="456"/>
        <source>Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="35"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="237"/>
        <source>Sign As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="247"/>
        <source>Text For Signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="260"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="267"/>
        <source>Reason</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="292"/>
        <source>Show Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="301"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="328"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="344"/>
        <source>Show Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="366"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="373"/>
        <source>Stretch Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="392"/>
        <source>Signature Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="436"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="455"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="469"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="477"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="487"/>
        <source>Lock document after signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="43"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="44"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="45"/>
        <source>Signature is INVALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="47"/>
        <source>Signature validity is UNKNOWN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="48"/>
        <source>This certificate is not trusted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="49"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="50"/>
        <source>Error during signature verification.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="51"/>
        <source>Details: The signature byte range is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="52"/>
        <source>I am the author of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="64"/>
        <source>I have reviewed this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="65"/>
        <source>I am approving this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="66"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="67"/>
        <source>I agree to specified parts of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="124"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="124"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="217"/>
        <source>Sign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="247"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="248"/>
        <source>Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="350"/>
        <source>Digitally signed by </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="358"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="441"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="386"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="435"/>
        <source>Digitally signed by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="552"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="552"/>
        <source>All Supported Files (*.p12 *.pfx);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="559"/>
        <source>A password is required to open certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="728"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="728"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="738"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="800"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="800"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureFormTab</name>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.ui" line="88"/>
        <source>Signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="221"/>
        <source>Unsigned Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="224"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="259"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="224"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="259"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="234"/>
        <source>Signed Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="237"/>
        <source>Signed by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="238"/>
        <source>Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="271"/>
        <source>Click to view this version</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>SHA-256</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="285"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="298"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <location filename="../../src/stamps/StampDlg.ui" line="72"/>
        <source>Manage Stamps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="90"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="74"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="35"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <location filename="../../src/widgets/TextEditDlg.ui" line="14"/>
        <source>Text Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="29"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="35"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolBarCommentsForm</name>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="81"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="84"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="119"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="122"/>
        <source>StrikeOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="154"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="157"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="189"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="192"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolBarSettings</name>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="502"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="480"/>
        <source>Open a PDF file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="503"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="522"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="536"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="544"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="311"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="317"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="347"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="354"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="364"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="350"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="356"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="451"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="578"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="584"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="615"/>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="371"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="388"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="394"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="414"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="421"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="437"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="473"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="26"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="44"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="64"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="120"/>
        <source>Scale relative to target page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="161"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="167"/>
        <source>Vertical distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="181"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="240"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="195"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="200"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="256"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="205"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="226"/>
        <source>Horizontal distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="251"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="261"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="269"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="277"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="282"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="287"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="138"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="150"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="150"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="160"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="196"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="196"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="278"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="294"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="312"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="334"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="334"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="360"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>layerForm</name>
    <message>
        <location filename="../../src/leftTab/layer/layerform.ui" line="27"/>
        <source>Layers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

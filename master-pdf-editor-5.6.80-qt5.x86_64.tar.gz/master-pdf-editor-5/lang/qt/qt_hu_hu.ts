<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu_HU">
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Mentés</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Összes mentése</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Megnyitás</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Igen</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Igen, &amp;mindet</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nem</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>E&amp;gyiket sem</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Megszakít</translation>
    </message>
    <message>
        <source>Retry</source>
        <translatorcomment>Újra</translatorcomment>
        <translation>Próbálja újra</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Figyelmen kívül hagy</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Bezárás</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Eldob</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Súgó</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Alkalmaz</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Visszaállítás</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Alapértelmezések visszaállítása</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Visszavon</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>Ism&amp;ét</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Kivá&amp;gás</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Máso&amp;lás</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>Beillesz&amp;tés</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Törlés</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Összes kiválasztása</translation>
    </message>
</context>
<context>
    <name>QWidgetTextControl</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Visszavon</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>Ism&amp;ét</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Kivá&amp;gás</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Máso&amp;lás</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Hivatkozás címének máso&amp;lása</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>Beillesz&amp;tés</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Törlés</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Összes kiválasztása</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>&amp;Select All</source>
        <translation>&amp;Összes kiválasztása</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>Lépé&amp;s felfelé</translation>
    </message>
    <message>
        <source>Step &amp;down</source>
        <translation>Lépés le&amp;felé</translation>
    </message>
</context>
</TS>

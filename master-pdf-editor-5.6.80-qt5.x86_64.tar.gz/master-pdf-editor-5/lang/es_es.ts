<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_419" sourcelanguage="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>Acerca De</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="48"/>
        <source>Version Info</source>
        <translation>Versión Info</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="105"/>
        <source>Built with</source>
        <translation>Construido con</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="122"/>
        <source>Legal Notices</source>
        <translation>Avisos Legales</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="353"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="53"/>
        <source>Registration Info</source>
        <translation>Información de Registro</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="58"/>
        <source>License Agreement</source>
        <translation>Acuerdo de licencia</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="86"/>
        <source>Please, renew your license</source>
        <translation>Por favor, renueve su licencia</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="111"/>
        <source>Not Registered version.</source>
        <translation>Versión no registrada.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="112"/>
        <source>Registered version.</source>
        <translation>Versión Registrada.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="158"/>
        <source>Purchased On:</source>
        <translation>Comprado en:</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="166"/>
        <source>Maintenance Plan Expires:</source>
        <translation>Plan de Mantenimiento Expira:</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="232"/>
        <source>This software uses, with permission, the following copyrighted software.</source>
        <translation>Este software usa, con permiso, el siguiente software con derechos de autor.</translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation>Acciones de Documento</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="96"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="103"/>
        <source>Java Script</source>
        <translation>Java Script</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation>Acciones</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translation>El documento se cerrará</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translation>Documento fue guardado</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translation>El documento se guardó</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translation>El documento se imprimirá&quot;</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation>El documento se imprimiò</translation>
    </message>
</context>
<context>
    <name>AdvancedPrintDialog</name>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="14"/>
        <source>Advanced Print Setup</source>
        <translation>Configuración Impresión Avanzada</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="20"/>
        <source>Print as Image</source>
        <translation>Imprimir como imagen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="63"/>
        <source>Queue In Subset Pages</source>
        <translation>Cola en Subconjuntos de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="94"/>
        <source>Сompatible with Laser Engraving</source>
        <translation>Сompatible con Grabado Láser</translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="14"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="20"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="242"/>
        <source>Borders and Colors</source>
        <translation>Bordes y Colores</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="252"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="257"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="262"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="267"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="272"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="277"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="282"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="287"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="292"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="297"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="302"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="310"/>
        <source>Border Color</source>
        <translation>Color de Borde</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="317"/>
        <source>Fill Color</source>
        <translation>Color Completo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="325"/>
        <source>Solid</source>
        <translation>Sólido</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="330"/>
        <source>Dashed</source>
        <translation>Discontínua</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="338"/>
        <source>Line Style</source>
        <translation>Estilo de Línea</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="obsolete">Grosor de la línea</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="345"/>
        <source>Line Width</source>
        <translation>Ancho de Línea</translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation>Mostrar al imprimir</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation>Mostrar al desplegar en pantalla</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation>Mantener fija posición y tamaño de marca de agua al imrimir en diferentes tamaños de páginas</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation>Agregar fondo</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Config. guardadas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="142"/>
        <source>Saved Settings</source>
        <translation>Configuración guardada</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="161"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="175"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="183"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Source</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="26"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="40"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="279"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="285"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="364"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="370"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="396"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="495"/>
        <source>Total pages :</source>
        <translation>Total de Páginas. :</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="47"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="67"/>
        <source>Page Number</source>
        <translation>Número Página</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="83"/>
        <source>Browse</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="116"/>
        <source>Scale</source>
        <translation>Escala</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="193"/>
        <source>Appearance</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="199"/>
        <source>Rotation</source>
        <translation>Rotación</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="237"/>
        <source>Opacity</source>
        <translation>Opacidad</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="293"/>
        <source>Scale relative to target page</source>
        <translation>Escala relativa a la página de destino</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="303"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="309"/>
        <source>Vertical distance</source>
        <translation>Distancia Vertical</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="323"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="382"/>
        <source>from</source>
        <translation>desde</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="337"/>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="342"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="398"/>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="347"/>
        <source>Bottom</source>
        <translation>Desde abajo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="368"/>
        <source>Horizontal distance</source>
        <translation>Distancia horizontal</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="393"/>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="403"/>
        <source>Right</source>
        <translation>Derecho</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="411"/>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="419"/>
        <source>Points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="424"/>
        <source>Inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <source>Millimeters</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">puntos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pulgadas</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">milímetros</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="461"/>
        <source>Page Range Options...</source>
        <translation>Opciones de rango de páginas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="103"/>
        <source>Save Settings</source>
        <translation>Guardar ajustes</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="103"/>
        <source>Save current settings as:</source>
        <translation>Guarde la configuración actual como:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="113"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Este nombre de configuración ya existe. ¿Desea sustituir la configuración anterior?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="148"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>¿Está seguro de que desea eliminar la configuración </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="148"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="209"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="225"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="243"/>
        <source> mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="263"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="263"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Todos los Archivos Compatibles (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="vanished">Archivos PDF (*.pdf *.PDF)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="289"/>
        <source>There was an error opening the document !</source>
        <translation>Hubo un error abriendo el documento !</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>Propiedades de Marcador</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="83"/>
        <source>Set current position</source>
        <translation>Fijar posición actual</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="93"/>
        <source>Appearance</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="112"/>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="126"/>
        <source>Plain</source>
        <translation>Plano</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="131"/>
        <source>Italic</source>
        <translation>Cursiva</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="136"/>
        <source>Bold</source>
        <translation>Negrilla</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="141"/>
        <source>Italic &amp; Bold</source>
        <translation>Cursiva &amp; Negrilla</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="162"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation>Número Página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="176"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="289"/>
        <source>Actions</source>
        <translation>Acciones</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="348"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="329"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="182"/>
        <source>Add an Action</source>
        <translation>Agregar en Acción</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="217"/>
        <source>Trigger</source>
        <translation>Disparador</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="201"/>
        <source>Action</source>
        <translation>Acción</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="209"/>
        <source>Mouse Up</source>
        <translation>Ratón Arriba</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="225"/>
        <source>Goto a Page View</source>
        <translation>Ir a Vista Página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="230"/>
        <source>Open/execute a File</source>
        <translation>Abrir/ejecutar Archivo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="235"/>
        <source>Open a web link</source>
        <translation>Abrir vínculo web</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="240"/>
        <source>Reset form</source>
        <translation>Restaurar formulario</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="245"/>
        <source>Show/Hide fields</source>
        <translation>Muestra/Oculta campos</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="250"/>
        <source>Submit a form</source>
        <translation>Remitir una forma</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="255"/>
        <source>Run a JavaScript</source>
        <translation>Ejecutar un JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="263"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="66"/>
        <source>untitled</source>
        <translation>intitulado</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="208"/>
        <source>Do you want to set the current position?</source>
        <translation>¿Quiére fijar la posición actual?</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="210"/>
        <source>Custom</source>
        <translation>Person</translation>
    </message>
</context>
<context>
    <name>CertificateManagerDlg</name>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="14"/>
        <source>Certificate Manager</source>
        <translation>Administrador de Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="24"/>
        <source>Your Certificates</source>
        <translation>Sus Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="33"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="53"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="60"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="78"/>
        <source>Trusted System Certificates</source>
        <translation>Certificados de Confianza del Sistema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="38"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="72"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="72"/>
        <source>All Supported Files (*.p12 *.pfx *.cer *.crt *.pem);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Todos los Archivos Compatibles (*.p12 *.pfx *.cer *.crt *.pem);; Archivos p12 (*.p12);;Archivos pfx (*.pfx);; Todos los Archivos (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="88"/>
        <source>A password is required to open certificate:</source>
        <translation>Se requiere una contraeña para abrir certificado:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="100"/>
        <source>Error!</source>
        <translation>Error!</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="124"/>
        <source>Are you sure you want to delete certificate?</source>
        <translation>¿Está seguro que quiere eliminar el certificado?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete ceritficate?</source>
        <translation type="vanished">¿Estás seguro que deseas eliminar el certificado?</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="156"/>
        <source>pfx Files (*.pfx)</source>
        <translation>Archivos pfx (*.pfx)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="158"/>
        <source>crt Files (*.crt)</source>
        <translation>Archivos crt (*.crt)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="160"/>
        <source>Save File</source>
        <translation>Guardar Como...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="169"/>
        <source>Please, specify private key password:</source>
        <translation>Se requiere una contraeña para abrir certificado:</translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="14"/>
        <source>Create a new document from files</source>
        <translation>Crear nuevo PDF a partir de formatos de archivos</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="154"/>
        <source>Output</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="221"/>
        <source>Append to Current Document </source>
        <translation>Insertar en el documento actual</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="228"/>
        <source>Create New Document</source>
        <translation>Crear nuevo documento</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="163"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="169"/>
        <source>Before current page</source>
        <translation>Antes de página actual</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="179"/>
        <source>After last page</source>
        <translation>Despúes de última página</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="186"/>
        <source>After current page</source>
        <translation>Después de página actual</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="196"/>
        <source>Before first page</source>
        <translation>Antes de primera página</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="23"/>
        <source>Add Files</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="40"/>
        <source>Add Folder</source>
        <translation>Agregar carpeta</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="98"/>
        <source>Up</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="109"/>
        <source>Down</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="120"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="144"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="91"/>
        <source>Page Range</source>
        <translation>Rango de Página</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="257"/>
        <source>Import Bookmarks</source>
        <translation>Importar Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="91"/>
        <source>File Name</source>
        <translation>Nombre Archivo</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="244"/>
        <source>Browse</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Guardar</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="31"/>
        <source>Insert Pages</source>
        <translation>Insertar Páginas</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">Ok</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="32"/>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="65"/>
        <source>untitled</source>
        <translation>intitulado</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="91"/>
        <source>Total pages</source>
        <translation>Total de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="330"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="557"/>
        <source>Save As PDF</source>
        <translation>Guarde Como PDF</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="332"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="559"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Archivos PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Abrir</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="363"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Todos los Archivos Compatibles (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="367"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Todos los Archivos Compatibles (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Todos los Archivos (*)</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Todos los Archivos (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="394"/>
        <source>Select directory</source>
        <translation>Selección directorio</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="587"/>
        <source>Save failed</source>
        <translation>Falló Guardado</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="588"/>
        <source>Can&apos;t save to the file:</source>
        <translation>No puede guardar archivo:</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="588"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
El archivo debe ser sólo lectura o usado por otra aplicación.</translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation>Eliminar Página(s)</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="26"/>
        <source>Page Range</source>
        <translation>Rango de Página</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="32"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Muestra: : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="78"/>
        <source>Current Page</source>
        <translation>Página Actual</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="88"/>
        <source>Pages from</source>
        <translation>Desde página</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="114"/>
        <source>to:</source>
        <translation>hasta:</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="140"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>Las página(s) eliminada(s) no se pueden recuperar con deshacer.</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation>Herramientas Distancia</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="36"/>
        <source>Measurement</source>
        <translation>Dimensión</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="71"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="98"/>
        <source>Distance:</source>
        <translation>Distancia:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="91"/>
        <source>Angle:</source>
        <translation>Ángulo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="121"/>
        <source>Cursor Location</source>
        <translation>Ubicación del cursor:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="140"/>
        <source>X:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="160"/>
        <source>Y:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="183"/>
        <source>Units and Markup Settings</source>
        <translation>Configuración de Unidades y Marcado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="276"/>
        <source>Scale Ratio:</source>
        <translation>Proporción de escala:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="190"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="251"/>
        <source>pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="195"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="256"/>
        <source>in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="200"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="261"/>
        <source>mm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="269"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="283"/>
        <source>Annotation:</source>
        <translation>Anotación:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="61"/>
        <source>°</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="24"/>
        <source>Distance</source>
        <translation>Distancia</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="28"/>
        <source>Perimeter</source>
        <translation>Perímetro</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="35"/>
        <source>Area</source>
        <translation>Área</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="38"/>
        <source> sq</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="201"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="204"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="208"/>
        <source> mm</source>
        <translation>mm</translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="14"/>
        <source>Icon Placement</source>
        <translation>Colocación de Íconos</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="20"/>
        <source>Fit to bounds</source>
        <translation>Ajustar a límites</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="27"/>
        <source>When to scale:</source>
        <translation>Cuándo escalar:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="35"/>
        <source>Proportionally</source>
        <translation>Proporcionalmente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="40"/>
        <source>Non-Proportionally</source>
        <translation>No proporcional</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="103"/>
        <source>Button</source>
        <translation>Botón</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="204"/>
        <source>Scale:</source>
        <translation>Escala:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="222"/>
        <source>Always</source>
        <translation>Siempre</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="227"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="232"/>
        <source>Icon is too big</source>
        <translation>Ícono muy grande</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="237"/>
        <source>Icon is too small</source>
        <translation>Ícono muy pequeño</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="245"/>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation>Use este diálogo para cambiar la forma en que el ícono se ajusta a escala dentro del botón</translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation>Número de página y formato de fecha</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation>Formato de fecha</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation>Formato de números páginas</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation>Número de página inicial</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="43"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>of</source>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="45"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translation>Opciones de rango de páginas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="23"/>
        <source>Page Range</source>
        <translation>Rango de Página</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="69"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Muestra: : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="90"/>
        <source>Even and Odd pages</source>
        <translation>Páginas Impares y Pares</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="95"/>
        <source>Even pages</source>
        <translation>Págs. Pares</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="100"/>
        <source>Odd pages</source>
        <translation>Págs. Impares</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="39"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="29"/>
        <source>All Pages</source>
        <translation>Todas las Páginas</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Cut</source>
        <translation type="vanished">Cortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Pegar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="27"/>
        <source>Select All</source>
        <translation>Selecciona Todo</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="34"/>
        <source>Add Sticky Note</source>
        <translation>Añade Nota Adhesiva</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="35"/>
        <source>Highlight Text</source>
        <translation>Resaltar Texto</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="36"/>
        <source>Strikeout Text</source>
        <translation>Tachar Texto</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="37"/>
        <source>Underline Text</source>
        <translation>Subrayar Texto</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="38"/>
        <source>Add Bookmark</source>
        <translation>Añade Marcador</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="52"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="64"/>
        <source>Set Status</source>
        <translation>Fijar Estado</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="981"/>
        <location filename="../../src/docpage/docpage.cpp" line="984"/>
        <source>pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1567"/>
        <source>The selected area has been copied</source>
        <translation>El área seleccionada ha sido copiada</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2180"/>
        <location filename="../../src/docpage/docpage.cpp" line="2221"/>
        <source>Goto a Page View</source>
        <translation>Ir a Vista Página</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2189"/>
        <source>Open a web link</source>
        <translation>Abrir un vínculo web</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2199"/>
        <source>Open/execute a File</source>
        <translation>Abrir/ejecutar un Archivo</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2211"/>
        <source>Run a JavaScript</source>
        <translation>Ejecutar un JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="3276"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation type="vanished">Copiar</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">Cortar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Pegar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="117"/>
        <source>Select All</source>
        <translation>Selecciona Todo</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="118"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Edita texto</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="120"/>
        <source>Edit Image</source>
        <translation>Editar Imagen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="121"/>
        <source>Signature options</source>
        <translation>Opciones de Firma</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">Deshacer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="122"/>
        <source>Clear Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="124"/>
        <location filename="../../src/docpage/docpage_base.cpp" line="1838"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="125"/>
        <source>Set Fit to Page</source>
        <translation>Fijar Ajuste de Pág</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="126"/>
        <source>Save Image to file</source>
        <translation>Guardar Imagen a archivo</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="128"/>
        <source>Edit Path Nodes</source>
        <translation>Editar Nodos de Ruta</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="411"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="420"/>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1268"/>
        <source>Edit the image and press Replace</source>
        <translation>Edite la imagen y presione Reemplazar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1270"/>
        <source>Replace</source>
        <translation>Reemplazar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1271"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Guardar Como...</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1394"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>Imágenes PNG (*.png);;Imágenes BMP (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1404"/>
        <source>PNG Images (*.png)</source>
        <translation>ImágenesPNG  (*.png)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1816"/>
        <source>Delete Node</source>
        <translation>Elimina Nodo</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2620"/>
        <source>Open Image</source>
        <translation>Abrir Imagen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2620"/>
        <source>Image Files (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Todos los Archivos Compatibles (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Todos los Archivos (*)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Archivos de Imágenes (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>ERROR Loading Image !</source>
        <translation type="vanished">ERROR Cargar Imagen !</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="vanished">Archivos de Imágenes (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>ERORR Load Image !</source>
        <translation type="vanished">ERORR Cargar Imagen !</translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>Acción</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation>Editor Java script</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation type="vanished">Ir a página</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">auto</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="vanished">Superior</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">Izquierda</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="vanished">Número Página</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation type="vanished">Acercamiento (%)</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="vanished">Abrir/ejecutar un Archivo</translation>
    </message>
    <message>
        <source>Edit a file</source>
        <translation type="vanished">Editar un archivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation>Selecciona Campos</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation>Deselecciona Todo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation>Selecciona Todo</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Opciones</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished">px</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation type="vanished">Modo Acercamiento</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="vanished">Person</translation>
    </message>
    <message>
        <source>Inherit Zoom</source>
        <translation type="vanished">Acercamiento Heredado</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Ajustar a Página</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="vanished">Ajustar al Ancho</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation>Método</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation>Archivo local</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translation>Use anónimo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation>Necesita nombre usuario y contraseña</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation>Nombre usuario</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="109"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="111"/>
        <source>All Files (*.*)</source>
        <translation>Todos los Archivos (*.*)</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation type="vanished">Ingrese un archivo:</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="vanished">Abrir vínculo web</translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation type="vanished">Ingrese un sitio web:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="181"/>
        <source>Show/Hide Fields</source>
        <translation>Muestra/Oculta Campos</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="185"/>
        <source>Select Field</source>
        <translation>Selecciona Campo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="215"/>
        <source>Reset Form</source>
        <translation>Restaurar Formulario</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Action</source>
        <translation>Acción</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="90"/>
        <source>Open/execute a File</source>
        <translation>Abrir/ejecutar un Archivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="91"/>
        <source>Enter a file:</source>
        <translation>Ingrese un archivo:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation>Ir a página</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="122"/>
        <source>Page Number</source>
        <translation>Número Página</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="129"/>
        <source>Zoom Mode</source>
        <translation>Modo Acercamiento</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="115"/>
        <source>Zoom (%)</source>
        <translation>Acercamiento (%)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="98"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="136"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="150"/>
        <source>Custom</source>
        <translation>Personal</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="155"/>
        <source>Fit Page</source>
        <translation>Ajustar a Página</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="160"/>
        <source>Fit Width</source>
        <translation>Ajustar al Ancho</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="165"/>
        <source>Fit Height</source>
        <translation>Ajustar la altura</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="170"/>
        <source>Fit Visible</source>
        <translation>Ajustar visible</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="223"/>
        <source> =  -1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="230"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open a web link</source>
        <translation>Abrir un vínculo web</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a web site:</source>
        <translation>Ingrese un sitio web:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Named Action</source>
        <translation>Acción Nombrada</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="163"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="165"/>
        <source>All Files (*.*)</source>
        <translation>Todos los Archivos (*.*)</translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>Extraer Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="95"/>
        <source>File Name</source>
        <translation>Nombre Archivo</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="123"/>
        <source>Browse</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="23"/>
        <source>Page Range</source>
        <translation>Rango Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="29"/>
        <source>Current Page</source>
        <translation>Página Actual</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="39"/>
        <source>All Pages</source>
        <translation>Todas las Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="49"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="79"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Muestra: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="146"/>
        <source>Export bookmarks</source>
        <translation>Exportar Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="156"/>
        <source>Extract pages as a single file</source>
        <translation>Extraer páginas como un archivo simple</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="179"/>
        <source>Delete pages after extracting</source>
        <translation>Elimina páginas después de extraer</translation>
    </message>
    <message>
        <source>Export Bookmarks</source>
        <translation type="vanished">Exportar Marcadores</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">Ok</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="32"/>
        <location filename="../../src/ExportPageDialog.cpp" line="79"/>
        <source>Export Pages</source>
        <translation>Exportar Páginas</translation>
    </message>
    <message>
        <source>Export Pages </source>
        <translation type="vanished">Exportar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="10"/>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="123"/>
        <source>Save As PDF</source>
        <translation>Guarde Como PDF</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="125"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Archivos PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="156"/>
        <location filename="../../src/ExportPageDialog.cpp" line="183"/>
        <source>Can&apos;t save to the file:</source>
        <translation>No puede guardar archivo:</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="156"/>
        <location filename="../../src/ExportPageDialog.cpp" line="183"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>El archivo debe ser sólo lectura o usado por otra aplicación.</translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="88"/>
        <source>Export to text</source>
        <translation>Exportar al texto</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Nombre del Archivo</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation>Rango de Página</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation>Página Actual</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation>Todas las Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="93"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Muestra: : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation>Extraer páginas como un archivo simple</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="10"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="90"/>
        <source>txt files (*.txt)</source>
        <translation>Archivos txt (*.txt)</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="120"/>
        <location filename="../../src/ExportTextDialog.cpp" line="147"/>
        <source>Can&apos;t save to the file:</source>
        <translation>No puede guardar archivo:</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="120"/>
        <location filename="../../src/ExportTextDialog.cpp" line="147"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
El archivo debe ser sólo lectura o usado por otra aplicación.</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>Propiedades de Documento</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>Información de Documento</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>Información PDF</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>Tema</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>Palabra clave</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>Creador</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>Productor</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>Seguridad</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="202"/>
        <source>Printing the document</source>
        <translation>Imprimiendo el documento</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="189"/>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimir una alta resolución de versión del documento</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="254"/>
        <source>Modifying document</source>
        <translation>Modificando documento</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="215"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Complete campos de forma o de firmas existentes</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="267"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Administrar Páginas y marcadores</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation>Sin Encriptar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation>Contraseña de Encriptado</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="141"/>
        <source>Change</source>
        <translation>Cambiar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="161"/>
        <source>Permissions</source>
        <translation>Permisos</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="176"/>
        <source>Extract the content of the document</source>
        <translation>Extraer el contenido del documento</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="228"/>
        <source>Content copying for accessibility</source>
        <translation>Copiar contenido para accesibilidad</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="241"/>
        <source>Commenting</source>
        <translation>Comentando</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="313"/>
        <source>Initial View</source>
        <translation>Vista Inicial</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="319"/>
        <source>User Interface Options</source>
        <translation>Opciones de interfaz de usuario</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="325"/>
        <source>Hide tool bar</source>
        <translation>Ocultar barra de herramientas</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="332"/>
        <source>Hide menu bar</source>
        <translation>Ocultar barra de menús</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="339"/>
        <source>Hide Window Controls</source>
        <translation>Ocultar controles de ventana</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="349"/>
        <source>Windows Options</source>
        <translation>Opciones de Windows</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="369"/>
        <source>Center window on screen</source>
        <translation>Centrar la ventana en la pantalla</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="355"/>
        <source>Display document title</source>
        <translation>Mostrar título del documento</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="362"/>
        <source>Open in Full Screen mode</source>
        <translation>Abrir en modo de pantalla completa</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="392"/>
        <source>Layout and Destination</source>
        <translation>Diseño y Acercamiento por Defecto</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="498"/>
        <source>Navigation Tab:</source>
        <translation>Ficha Navegación:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="541"/>
        <source>Page layout:</source>
        <translation>Diseño de Páginas:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="415"/>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <location filename="../../src/FileSettings.cpp" line="238"/>
        <source>Default</source>
        <translation>Defecto</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>Single Page</source>
        <translation>Página Sencilla</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>Single Page Continuous</source>
        <translation>Página única continua</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>Two-Up (Facing)</source>
        <translation>Páginas Enfrentadas</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation>Páginas Enfrentadas continua</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>Two-Up (Cover Page)</source>
        <translation>Dos arriba (portada)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="579"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation>Dos arriba continuas (portada)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="534"/>
        <source>Zoom</source>
        <translation>Acercamiento</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="133"/>
        <source>Certificate Encryption</source>
        <translation>Cifrado de Certificado</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="420"/>
        <source>Actual Size</source>
        <translation>Tamaño Actual</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="425"/>
        <source>Fit Page</source>
        <translation>Ajustar a Página</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="430"/>
        <source>Fit Width</source>
        <translation>Ajustar al Ancho</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="435"/>
        <location filename="../../src/FileSettings.cpp" line="258"/>
        <source>Fit Height</source>
        <translation>Ajustar la altura</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="440"/>
        <location filename="../../src/FileSettings.cpp" line="263"/>
        <source>Fit Visible</source>
        <translation>Ajustar visible</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="445"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="485"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="490"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="637"/>
        <location filename="../../src/FileSettings.ui" line="727"/>
        <source>Actions</source>
        <translation>Acciones</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="643"/>
        <source>Document Open Actions</source>
        <translation>Acciones de Documento Abierto</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="649"/>
        <source>Add an Action</source>
        <translation>Agregar en Acción</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="669"/>
        <source>Goto a Page View</source>
        <translation>Ir a Vista Página</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="674"/>
        <source>Open/execute a File</source>
        <translation>Abrir/ejecutar Archivo</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="679"/>
        <source>Open a web link</source>
        <translation>Abrir vínculo web</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="684"/>
        <source>Reset form</source>
        <translation>Restaurar formulario</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="689"/>
        <source>Show/Hide fields</source>
        <translation>Muestra/Oculta campos</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="694"/>
        <source>Submit a form</source>
        <translation>Remitir una forma</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="699"/>
        <source>Run a JavaScript</source>
        <translation>Ejecutar un JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="707"/>
        <source>Action</source>
        <translation>Acción</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation type="vanished">Modo Página:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="506"/>
        <source>Page Only</source>
        <translation>Página Solamente</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="511"/>
        <source>Bookmarks Panel</source>
        <translation>Panel de Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="516"/>
        <source>Pages Panel</source>
        <translation>Panel de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="526"/>
        <source>Attachments Panel</source>
        <translation>Panel Adjunto</translation>
    </message>
    <message>
        <source>Run JavaScript on Document Open</source>
        <translation type="obsolete">Correr JavaScript en Documento Abrierto</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="714"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="783"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="742"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="521"/>
        <source>Layers Panel</source>
        <translation>Panel de Capas</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation type="vanished">Pantalla Completa</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="587"/>
        <source>Open to Page:</source>
        <translation>Abrir en Página:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="594"/>
        <source>of :</source>
        <translation>de:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="612"/>
        <source>Fonts</source>
        <translation>Fuentes</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="628"/>
        <source>Fonts used in this document</source>
        <translation>Fuentes usadas en este documento</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="710"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="711"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>El documento es protegido. Por favor, entre contraseña de permiso:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="733"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Contraseña incorrecta. Por favor, entre la contraseña de propietario.</translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="14"/>
        <source>Header &amp; Footer</source>
        <translation>Encabezado y pie de página</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="130"/>
        <source>Top margin</source>
        <translation>Margen superior</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="94"/>
        <source>Right margin</source>
        <translation>Margen derecho</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="153"/>
        <source>Bottom margin</source>
        <translation>Margen Inferior</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="71"/>
        <source>Left margin</source>
        <translation>Margen izquierdo</translation>
    </message>
    <message>
        <source>Margin</source>
        <translation type="vanished">Margen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="32"/>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">puntos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pulgadas</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">milímetros</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="306"/>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="312"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="332"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="352"/>
        <source>Font Family</source>
        <translation>Familia Fuente</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Config. guardadas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="208"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="222"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="230"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="382"/>
        <source>Right Footer Text</source>
        <translation>Texto de pie de página derecho</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Margins</source>
        <translation>Margen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="40"/>
        <source>Points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="45"/>
        <source>Inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="50"/>
        <source>Millimeters</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="389"/>
        <source>Center Header Text</source>
        <translation>Texto de encabezado central</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="396"/>
        <source>Left Footer Text</source>
        <translation>Texto de pie de página izquierdo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="403"/>
        <source>Right Header Text</source>
        <translation>Texto de encabezado derecho</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="410"/>
        <source>Center Footer Text</source>
        <translation>Texto de pie de página central</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="417"/>
        <source>Left Header Text</source>
        <translation>Texto de encabezado izquierdo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="189"/>
        <source>Saved Settings</source>
        <translation>Configuración guardada</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="283"/>
        <source>Insert Date</source>
        <translation>Insertar fecha</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="276"/>
        <source>Insert Page Number</source>
        <translation>Insertar número de página</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="266"/>
        <source>Page number and date format</source>
        <translation>Número de página y formato de fecha</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="248"/>
        <source>Page Range Options...</source>
        <translation>Opciones de rango de páginas...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="276"/>
        <source>Save Settings</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="276"/>
        <source>Save current settings as:</source>
        <translation>Guarde la configuración actual como:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="286"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Este nombre de configuración ya existe. ¿Desea sustituir la configuración anterior?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="321"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>¿Está seguro de que desea eliminar la configuración </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="321"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="434"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="454"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="474"/>
        <source> mm</source>
        <translation>mm</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Insert Pages</source>
        <translation type="vanished">Insertar Páginas</translation>
    </message>
    <message>
        <source>Before page</source>
        <translation type="vanished">Antes de Página</translation>
    </message>
    <message>
        <source>After page</source>
        <translation type="vanished">Después de Pág</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Rango de Páginas</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas las Páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Muestra: 1,6-8,12</translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation type="vanished">Importar Marcadores</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="vanished">Nombre del Archivo</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="vanished">Buscar</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Total de Páginas. :</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="vanished">Posición</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation type="vanished">Después de Última Página</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation type="vanished">Antes de Primera Página</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">Ok</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="vanished">Abrir Archivo</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation type="vanished">Archivos PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="vanished">Contraseña</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="vanished">El archivo está protegido. Por favor entre Contraseña de Abrir Documento:</translation>
    </message>
    <message>
        <source>Read Error: This PDF is protected.</source>
        <translation type="vanished">Error leyendo: Este PDF está protegido.</translation>
    </message>
    <message>
        <source>Error read: This PDF is protected.</source>
        <translation type="vanished">Error leyendo: Este PDF está protegido.</translation>
    </message>
</context>
<context>
    <name>InitialsDlg</name>
    <message>
        <location filename="../../src/initials/InitialsDlg.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation>Instalar idiomas</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="37"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation>Consola de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation>Correr</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation>Claro</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="57"/>
        <source>Stays On Top</source>
        <translation>Mantener Visible</translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation>JavaScript Documento</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="30"/>
        <source>Function Name</source>
        <translation>Nombre Función</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="55"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="62"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="69"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation>Editor Java Script</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation>Nombre Función</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation>Java Script</translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="118"/>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="197"/>
        <source>Press shortcut</source>
        <translation>Presione Atajo</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="20"/>
        <source>Keyboard shortcuts</source>
        <translation>Atajos de teclado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="43"/>
        <source>Reset All</source>
        <translation>Resetear todo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="129"/>
        <source>Key sequence has potential conflicts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="35"/>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="50"/>
        <source>Shortcut</source>
        <translation>Atajo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="56"/>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="30"/>
        <source>Command</source>
        <translation>Comando</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="944"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1783"/>
        <source> ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1980"/>
        <source>Smooth text and images</source>
        <translation>Texto e imágenes suaves</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="960"/>
        <source>Time before a move or resize starts:</source>
        <translation>Tiempo antes de iniciar mover o redimensionar:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="973"/>
        <source>Select item by hovering the mouse</source>
        <translation>Seleccione elemento pasando el ratón</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="196"/>
        <source>Saving Documents</source>
        <translation>Guardando Documentos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="236"/>
        <source>Create backup file</source>
        <translation>Crear archivo respaldo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="222"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Escoja destino para documentos &quot;Guardar Como&quot;</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="209"/>
        <source>Last used folder</source>
        <translation>Última carpeta usada</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="214"/>
        <source>Original documents folder</source>
        <translation>Carpeta original documentos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="395"/>
        <source>Required field highlight color</source>
        <translation>Requerido campo color resaltado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="375"/>
        <source>Highlight color</source>
        <translation>Color de resaltado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="996"/>
        <source>Default font</source>
        <translation>Fuente por defecto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2964"/>
        <source>Path for DB:</source>
        <translation>Ruta para DB:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="600"/>
        <source>Built-in</source>
        <translation>Incorporado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3062"/>
        <source>Please choose the interface language</source>
        <translation>Por favor, escoja el lenguaje de interfaz</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1132"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1199"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1225"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1261"/>
        <source>pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="306"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2315"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3092"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Se requiere que reinicie el programa para que los cambios surtan efectos.</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2156"/>
        <source>Selected text color</source>
        <translation>Color de texto seleccionado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2257"/>
        <source>Icon set</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2189"/>
        <source>Default</source>
        <translation>Defecto</translation>
    </message>
    <message>
        <source>Dark Style</source>
        <translation type="vanished">Fusión Estilo Oscuro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2169"/>
        <source>Application Style</source>
        <translation>Estilo de aplicación</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2335"/>
        <source>Use default program</source>
        <translation>Usar el programa predeterminado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2354"/>
        <source>evolution</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2359"/>
        <source>kmail</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2364"/>
        <source>thunderbird</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2372"/>
        <source>Use SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2395"/>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2483"/>
        <source>Email address</source>
        <translation>Correo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2476"/>
        <source>Secure connections</source>
        <translation>Conexiones seguras</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2451"/>
        <source>NONE</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2456"/>
        <source>SSL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2461"/>
        <source>STARTTLS</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2443"/>
        <source>SMTP server</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2433"/>
        <source>User</source>
        <translation>Nombre usuario</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2469"/>
        <source>SMTP port</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2416"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2816"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1160"/>
        <source>Points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1165"/>
        <source>Inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1170"/>
        <source>Millimeters</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="877"/>
        <source>Always show Object Inspector</source>
        <translation>Siempre muestra Inspector de Objetos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1886"/>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation>Prohibir archivos para habilitar modo Pantalla Completa al abrir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2237"/>
        <source>Standard</source>
        <translation>Estándar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2242"/>
        <source>Office Pro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2194"/>
        <source>Light</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2199"/>
        <source>Dark</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2227"/>
        <source>Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2270"/>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2275"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2574"/>
        <source>Default path to tesseract ocr data files</source>
        <translation>Ruta acceso por defecto a archivos de datos ocr tesseract</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2613"/>
        <source>Additional tesseract ocr config file</source>
        <translation>Additional tesseract ocr config file</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2675"/>
        <source>Install languages</source>
        <translation>Instalar idiomas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2698"/>
        <source>Direct internet connection</source>
        <translation>Conexión directa a Internet</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2708"/>
        <source>Manual proxy configuration</source>
        <translation>Configuración manual del proxy</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2724"/>
        <source>HTTP Proxy</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2731"/>
        <source>SOCKS 5 Proxy</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2741"/>
        <source>Host</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2751"/>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2404"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2794"/>
        <source>Authentication</source>
        <translation>Autenticación requerida</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2806"/>
        <source>User name</source>
        <translation>Nombre usuario</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2887"/>
        <source>Default paths for system certificates</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2897"/>
        <source>Database for Certificate Manager</source>
        <translation>Base de Datos para Administrador de certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2957"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2913"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2930"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3010"/>
        <source>Certificate Manager</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3158"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3163"/>
        <source>Weekly</source>
        <translation>Semanalmente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3168"/>
        <source>Monthly</source>
        <translation>Mensualmente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3144"/>
        <source>Check for Updates Automatically</source>
        <translation>Verifique las Actualizaciones Automáticamente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="229"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2590"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2629"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="621"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1063"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1271"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1590"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1679"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="592"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1014"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1597"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2250"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Ajuste</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="153"/>
        <source>History</source>
        <translation>Historial</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="165"/>
        <source>Restore last session when application start</source>
        <translation>Restaure última sesión acuando arranque aplicación</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="172"/>
        <source>Restore last view settings when reopening</source>
        <translation>Restaure ajustes última vista cuando reabra</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1334"/>
        <source>Enable JavaScript</source>
        <translation>Habilite JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="431"/>
        <source> Always hide document message bar </source>
        <translation>Siempre oculte barra de mensajes de documento</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1848"/>
        <source>Default Layout and Zoom</source>
        <translation>Diseño y Acercamiento por Defecto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1893"/>
        <source>Default page layout</source>
        <translation>Diseño de Página por Defecto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1861"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1904"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1866"/>
        <source>Single Page</source>
        <translation>Página Sencilla</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1871"/>
        <source>Facing Pages</source>
        <translation>Páginas Enfrentadas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1879"/>
        <source>Zoom</source>
        <translation>Acercamiento</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="59"/>
        <source>Grid</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="64"/>
        <source>JavaScript</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="89"/>
        <source>Keyboard</source>
        <translation>Teclado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="94"/>
        <source>Email</source>
        <translation>Correo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="99"/>
        <source>OCR</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="109"/>
        <source>Network</source>
        <translation>Red</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="114"/>
        <source>Certificates</source>
        <translation>Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="139"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation>Abrir documentos como nuevas pestañas en la misma ventana (requiere reiniciar)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="259"/>
        <source>Enable scroll wheel zooming</source>
        <translation>Ampliación con rueda de desplazamiento</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="39"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="79"/>
        <source>Toolbars</source>
        <translation>Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="104"/>
        <source>Redaction</source>
        <translation>Redacción</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="189"/>
        <source>Show Start page</source>
        <translation>Mostrar página de inicio</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="146"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation>Permitir abrir el mismo documento en múltiples pestañas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="182"/>
        <source>Show Quick actions on text selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="276"/>
        <source>Alternative method for PDF render</source>
        <translation>Método alternativo para generar PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="283"/>
        <source>Load all objects separately</source>
        <translation>Carga total objetos por separado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="326"/>
        <source>Memory/Speed</source>
        <translation>Memoria/Velocidad</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="333"/>
        <source>Minimize memory usage</source>
        <translation>Minimizar uso de memoria</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="338"/>
        <source>Maximal render speed</source>
        <translation>Velocidad máxima de generación</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="439"/>
        <source>Link</source>
        <translation>Vínculo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="444"/>
        <source>Edit Box</source>
        <translation>Caja de Edición</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="449"/>
        <source>Check box</source>
        <translation>Caja de Verificación</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="454"/>
        <source>Radio button</source>
        <translation>Botón Circular</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="459"/>
        <source>Combo box</source>
        <translation>Combo box</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="464"/>
        <source>List box</source>
        <translation>Caja de Lista</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="469"/>
        <source>Button</source>
        <translation>Botón</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="474"/>
        <source>Signature</source>
        <translation>Firma</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="495"/>
        <source>Borders and Colors</source>
        <translation>Bordes y Colores</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="502"/>
        <source>Thin</source>
        <translation>Fino</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="507"/>
        <source>Medium</source>
        <translation>Medio</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="512"/>
        <source>Thick</source>
        <translation>Espesor</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="520"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="763"/>
        <source>Border Color</source>
        <translation>Color de Borde</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="527"/>
        <source>Fill Color</source>
        <translation>Color Completo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="535"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="778"/>
        <source>Solid</source>
        <translation>Sólido</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="540"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="783"/>
        <source>Dashed</source>
        <translation>Discontínua</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="545"/>
        <source>Beveled</source>
        <translation>Biselado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="550"/>
        <source>Inset</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="555"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="788"/>
        <source>Underline</source>
        <translation>Subrayado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="563"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="770"/>
        <source>Line Style</source>
        <translation>Estilo de Línea</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="570"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="749"/>
        <source>Line Thickness</source>
        <translation>Grosor de la línea</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="605"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2265"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="634"/>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="650"/>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="661"/>
        <source>Check</source>
        <translation>Verifica</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="676"/>
        <source>Diamond</source>
        <translation>Diamante</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="681"/>
        <source>Square</source>
        <translation>Cuadrado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="743"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="796"/>
        <source>Highlight</source>
        <translation>Resaltado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="807"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="812"/>
        <source>Invert</source>
        <translation>Invertir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="817"/>
        <source>OutLine</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="822"/>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="727"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="733"/>
        <source>Add full path to filename in export file</source>
        <translation>Añadir la ruta completa al nombre del archivo en archivo de exportación</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="907"/>
        <source>Automatically change font when editing text</source>
        <translation>Automáticamente cambie la fuente cuando edite el documento</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="922"/>
        <source>Exact match only</source>
        <translation>Sólo coincidencia exacta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="897"/>
        <source>Save last editing Tool</source>
        <translation>Guardar última Herramienta de edición</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1125"/>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">puntos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pulgadas</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">milímetros</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1152"/>
        <source>Width between lines</source>
        <translation>Ancho entre líneas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1185"/>
        <source>Height between lines</source>
        <translation>Altura entre líneas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1145"/>
        <source>Left offset</source>
        <translation>Margen izquierdo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="833"/>
        <source>Recreate pdf forms when opening</source>
        <translation>Recrear formulario pdf al abrir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1108"/>
        <source>Edit Text Elements as Blocks</source>
        <translation>Editar Elementos de Texto como Bloques</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1178"/>
        <source>Top offset</source>
        <translation>Margen superior</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1192"/>
        <source>Subdivision</source>
        <translation>Subdivisión</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1346"/>
        <source>Show errors and  messages in console</source>
        <translation>Ver errores y mensajes en la consola</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1356"/>
        <source>Enable safe reading mode</source>
        <translation>Activar el modo de lectura segura</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1448"/>
        <source>Measurements</source>
        <translation>Mediciones</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1453"/>
        <source>Drawing</source>
        <translation>Dibujo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1458"/>
        <source>Typewriter</source>
        <translation>Maquina de escribir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1780"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1824"/>
        <source>Tooltip Display Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1909"/>
        <source>Actual Size</source>
        <translation>Tamaño Actual</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1914"/>
        <source>Fit Page</source>
        <translation>Ajustar a Página</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1919"/>
        <source>Fit Width</source>
        <translation>Ajustar al Ancho</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1924"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1929"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1934"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1939"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1944"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1949"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1954"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1959"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1964"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1969"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="580"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1989"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2106"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1996"/>
        <source>Bitmap Images</source>
        <translation>Imágenes Bitmap</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2003"/>
        <source>Vector Images</source>
        <translation>Imágenes Vector</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2032"/>
        <source>System PPI</source>
        <translation>Sistema PPI</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2091"/>
        <source>Replace Document Colors</source>
        <translation>Reemplace Colores Del Documento</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2113"/>
        <source>Page Background</source>
        <translation>Fondo Página</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="69"/>
        <source>Comments</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="84"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="489"/>
        <source>Appearance</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <source> Always show Object Inspector</source>
        <translation type="vanished">Siempre muestra Inspector de Objetos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2163"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Fusion Dark Style</source>
        <translation type="vanished">Fusión Estilo Oscuro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2026"/>
        <source>Resolution</source>
        <translation>Resolución</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2042"/>
        <source>Custom</source>
        <translation>Personal</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1404"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1837"/>
        <source>Pop-up Opacity</source>
        <translation>Opacidad de Pop-up</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1305"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1561"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1705"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1814"/>
        <source>%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1428"/>
        <source>Sticky Note</source>
        <translation>Nota Adhesiva</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1544"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1298"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1577"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1666"/>
        <source>Opacity</source>
        <translation>Opacidad</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1433"/>
        <source>Highlight Text</source>
        <translation>Resaltar Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1438"/>
        <source>Strikeout Text</source>
        <translation>Tachar Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1443"/>
        <source>Underline Text</source>
        <translation>Subrayar Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1278"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1692"/>
        <source>Line Width</source>
        <translation>Ancho de Línea</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2207"/>
        <source>Icons in menus</source>
        <translation>Íconos en menús</translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation type="vanished">Barra Herramienta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="44"/>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="119"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="124"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="484"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="49"/>
        <source>Forms</source>
        <translation>Formas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="54"/>
        <source>Editing</source>
        <translation>Editando</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="74"/>
        <source>Display</source>
        <translation>Pantalla</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="395"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="410"/>
        <source>Select directory</source>
        <translation>Selección directorio</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="424"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="555"/>
        <source>Arabic</source>
        <translation>Arábigo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="556"/>
        <source>Armenian</source>
        <translation>Armenio</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="557"/>
        <source>Bulgarian</source>
        <translation>Búlgaro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="558"/>
        <source>Catalan</source>
        <translation>Catalán</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="559"/>
        <source>Chinese-Simplified</source>
        <translation>Chino-Simplificado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="560"/>
        <source>Chinese-Traditional</source>
        <translation>Chino-Tradicional</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="561"/>
        <source>Czech</source>
        <translation>Checo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="562"/>
        <source>Danish</source>
        <translation>Danés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="563"/>
        <source>Dutch</source>
        <translation>Holandés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="564"/>
        <source>English</source>
        <translation>Inglés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="565"/>
        <source>Estonian</source>
        <translation>Estoniano</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="566"/>
        <source>Finnish</source>
        <translation>Finlandés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="567"/>
        <source>French</source>
        <translation>Francés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="568"/>
        <source>Galician</source>
        <translation>Galicio</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="569"/>
        <source>German</source>
        <translation>Aleman</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="570"/>
        <source>Greek</source>
        <translation>Griego</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="571"/>
        <source>Hebrew</source>
        <translation>Hebreo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="572"/>
        <source>Hungarian</source>
        <translation>Húngaro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="573"/>
        <source>Irish</source>
        <translation>Irlandés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="574"/>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="575"/>
        <source>Japanese</source>
        <translation>Japonés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="576"/>
        <source>Korean</source>
        <translation>Koreano</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="577"/>
        <source>Latvian</source>
        <translation>Letón</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="578"/>
        <source>Lithuanian</source>
        <translation>Lituano</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="579"/>
        <source>Norwegian</source>
        <translation>Noriego</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="580"/>
        <source>Norwegian-Nynorsk</source>
        <translation>Noruego-Nynorsk</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="581"/>
        <source>Polish</source>
        <translation>Polaco</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="582"/>
        <source>Portuguese</source>
        <translation>Portugués</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="583"/>
        <source>Portuguese-Brazilian</source>
        <translation>Portugués-Brasil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="584"/>
        <source>Romanian</source>
        <translation>Rumano</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="585"/>
        <source>Russian</source>
        <translation>Ruso</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="586"/>
        <source>Serbian</source>
        <translation>Serbio</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="587"/>
        <source>Slovak</source>
        <translation>Eslovaco</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="588"/>
        <source>Slovenian</source>
        <translation>Esloveno</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="589"/>
        <source>Spanish</source>
        <translation>Español</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="590"/>
        <source>Swedish</source>
        <translation>Suizo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="591"/>
        <source>Thai</source>
        <translation>Tailandés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="592"/>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="593"/>
        <source>Ukrainian</source>
        <translation>Ukraniano</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="594"/>
        <source>Valencian</source>
        <translation>Valenciano</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="595"/>
        <source>Vietnamese</source>
        <translation>Vietnamés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="596"/>
        <source>Farsi</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="618"/>
        <source>Check Mark</source>
        <translation>Marca de Verificación</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="687"/>
        <source>In Windows, all certificates are located in system storage.</source>
        <translation>En Windows, todos los certificados se encuentran en el</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="692"/>
        <source>In macOS, all certificates are located in system storage.</source>
        <translation>En macOS, todos los certificados se encuentran en el</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="706"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1037"/>
        <source>System Theme</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="707"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1041"/>
        <source>Light Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="708"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1045"/>
        <source>Dark Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1604"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1801"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1821"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1841"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="666"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="619"/>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="620"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="671"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="621"/>
        <source>Cross</source>
        <translation>Cruz</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="622"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">Insertar Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="624"/>
        <source>Key</source>
        <translation>Tecla</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="625"/>
        <source>New Paragraph</source>
        <translation>Nuevo Parágrafo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="626"/>
        <source>Text Note</source>
        <translation>Texto Nota</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="627"/>
        <source>Paragraph</source>
        <translation>Parágrafo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="628"/>
        <source>Right Arrow</source>
        <translation>Flecha Derecha</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="629"/>
        <source>Right Pointer</source>
        <translation>Apuntador Derecho</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="686"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="630"/>
        <source>Star</source>
        <translation>Estrella</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="631"/>
        <source>Up Arrow</source>
        <translation>Flecha Arriba</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="632"/>
        <source>Up Left Arrow</source>
        <translation>Hasta Flecha izquierda</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="633"/>
        <source>Graph</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="634"/>
        <source>Paper Clip</source>
        <translation>Clip de Papel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="635"/>
        <source>Attachment</source>
        <translation>Adjunto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="636"/>
        <source>Tag</source>
        <translation>Etiqueta</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../src/mainwindow.ui" line="39"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation type="vanished">Exportar a</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="192"/>
        <location filename="../../src/mainwindow.ui" line="1220"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="196"/>
        <source>Align Objects</source>
        <translation>Alinear Objetos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="85"/>
        <location filename="../../src/mainwindow.ui" line="1212"/>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="225"/>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="145"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="vanished">Insertar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="284"/>
        <location filename="../../src/mainwindow.ui" line="1236"/>
        <source>Comments</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="155"/>
        <location filename="../../src/mainwindow.ui" line="1228"/>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="58"/>
        <location filename="../../src/mainwindow.ui" line="1667"/>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="730"/>
        <location filename="../../src/mainwindow.cpp" line="3619"/>
        <source>Create a new blank PDF</source>
        <translation>Crear un nuevo PDF en blanco</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="733"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="346"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="15"/>
        <source>Comment View</source>
        <translation>Vista de Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="18"/>
        <source>Show All Comments with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="29"/>
        <source>Show by Type</source>
        <translation>Mostrar por Tipo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="81"/>
        <source>Red</source>
        <translation>Rojo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="86"/>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="91"/>
        <source>Yellow</source>
        <translation>Amarillo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="96"/>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="130"/>
        <source>Minimum tools</source>
        <translation type="unfinished">Herramientas mínimas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="133"/>
        <source>Maximum tools</source>
        <translation type="unfinished">Herramientas máximas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="136"/>
        <source>Reset toolbars</source>
        <translation>Restaurar barras de herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="442"/>
        <source>Insert Initials</source>
        <translation>Insertar Iniciales</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">Entregar mensajes</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Insertar Texto</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Nota Adhesiva</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="409"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="428"/>
        <source>Place Initials</source>
        <translation>Colocar Iniciales</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="410"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="429"/>
        <source>Create New Initials</source>
        <translation>Crear Nuevas Iniciales</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="412"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="431"/>
        <source>Open Containing Folder</source>
        <translation>Abrir Carpeta Contenedora</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2809"/>
        <source>All Types</source>
        <translation>Todos los Tipos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2814"/>
        <source>Notes</source>
        <translation>Notas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2822"/>
        <source>Text Editing Markups</source>
        <translation>Marcas de Edición de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2826"/>
        <source>Stamps</source>
        <translation>Clonar sello</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2830"/>
        <source>Attachments</source>
        <translation>Adjunto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="33"/>
        <source>Show by Reviewer</source>
        <translation>Mostrar por Revisor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="43"/>
        <source>Show by Status</source>
        <translation>Mostrar por Estado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2855"/>
        <source>All Status</source>
        <translation>Todos los Estados</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2860"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="vanished">Clonar sello</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="vanished">Mostrar</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Abrir Archivo (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Abrir Archivo PDF o XPS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="355"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="374"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Herramienta mano&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use la herramienta mano para mover páginas, abrir vínculos y seleccionar texto.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="391"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleccionar Texto&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar texto para copiar y pegar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="394"/>
        <source>Select text for copying and pasting</source>
        <translation>Seleccione texto para copiado y pegado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1707"/>
        <source>Mark for Redaction</source>
        <translation>Marca para Redacción</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1712"/>
        <source>Apply Redactions</source>
        <translation>Aplicar Redacciones</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1717"/>
        <source>Redaction Properties</source>
        <translation>Propiedades de Redacción</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1725"/>
        <source>Show Redaction ToolBar</source>
        <translation>Mostrar Barra Herramientas Redacción</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1730"/>
        <source>Search and Redact</source>
        <translation>Busca y Redacta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1743"/>
        <source>Certificate Manager</source>
        <translation>Administrador de Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1748"/>
        <source>Send Backward</source>
        <translation>Enviar Atrás</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1753"/>
        <source>Bring Forward</source>
        <translation>Adelantar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1761"/>
        <source>Edit Vector Images</source>
        <translation>Editar Imágenes de Vector</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1767"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="427"/>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="349"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Abrir Archivo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Abrir Archivo PDF o XPS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="438"/>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="474"/>
        <source>Ctrl+0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="499"/>
        <source>Ctrl+H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="521"/>
        <source>Ctrl+1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="535"/>
        <source>Ctrl+2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="540"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Guardar (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Guardar el documento&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="546"/>
        <source>Save the document</source>
        <translation>Guardar el documento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="549"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="554"/>
        <source>Save As...</source>
        <translation>Guardar Como...</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Guardar Como PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Guardar el documento con un nombre nuevo&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="560"/>
        <source>Save the document with a new name</source>
        <translation>Guarde el documento con nombre nuevo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="563"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="746"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Imprimir (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprimir el documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="574"/>
        <location filename="../../src/mainwindow.ui" line="752"/>
        <source>Print the document</source>
        <translation>Imprimir el documento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="755"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="582"/>
        <location filename="../../src/mainwindow.ui" line="585"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="588"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="593"/>
        <location filename="../../src/mainwindow.ui" line="596"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="613"/>
        <source>Ctrl+3</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Documento (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Selecciona y edita texto, imágenes, anotaciones, campos de formularios...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="643"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>Seleccione y edite texto, imágenes, anotaciones, campos de formas ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="660"/>
        <source>Select text for editing</source>
        <translation>Seleccione texto para edición</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="663"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="668"/>
        <location filename="../../src/mainwindow.ui" line="1387"/>
        <location filename="../../src/mainwindow.ui" line="1433"/>
        <location filename="../../src/mainwindow.ui" line="1446"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Elimina Objeto(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Elimina Objeto(s) actualmente seleccionado(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="674"/>
        <source>Delete the currently selected object(s)</source>
        <translation>Borre objeto(s) actualmente seleccionado(s)</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Formulario (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar formulario y anotaciones para edición&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="724"/>
        <source>Blank PDF</source>
        <translation>Crear un nuevo PDF en blanco</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Nuevo (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Crear nuevo PDF en blanco&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print Preview (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Preview the document before printing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">Vista Previa Impresión</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="577"/>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="766"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>Corte Objeto(s) seleccionado(s) y póngalo(s) en el Portapapeles</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="780"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>Copie Objeto(s) seleccionado(s) y póngalo(s) en el Portapapeles</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="794"/>
        <source>Paste from the Clipboard</source>
        <translation>Pegue desde el Portapapeles</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="827"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="838"/>
        <source>Undo the last action</source>
        <translation>Deshacer la última acción</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="852"/>
        <source>Redo the previously undone action.</source>
        <translation>Rehacer la acción previamente deshecha.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="866"/>
        <source>Send to Back selected object.</source>
        <translation>Enviar al fondo objeto seleccionado.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="871"/>
        <source>Bring to Front</source>
        <translation>Traer al Frente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="874"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Traer al Frente&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Traer al Frente el objeto seleccionado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="877"/>
        <source>Bring to Front selected object.</source>
        <translation>Traer al fondo objeto seleccionado.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="912"/>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Shift+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="931"/>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Shift+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="942"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="947"/>
        <location filename="../../src/mainwindow.ui" line="950"/>
        <source>Extract Pages...</source>
        <translation>Extraer Páginas...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="953"/>
        <source>Ctrl+Shift+E</source>
        <translation>Ctrl+Shift+E</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="958"/>
        <location filename="../../src/mainwindow.ui" line="961"/>
        <source>Insert Pages...</source>
        <translation>Insertar Páginas...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="964"/>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Shift+I</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="983"/>
        <source>Open window with document properties</source>
        <translation>Abrir ventana con propiedades del documento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="997"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nota Adhesiva&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Haga Clic en la página para agregar una nota en esa posición&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1000"/>
        <source>Click the page to add a note at that position</source>
        <translation>Clic en la página para agregar nota en esa posición</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1003"/>
        <source>Ctrl+6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1032"/>
        <location filename="../../src/mainwindow.cpp" line="5077"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insertar Texto (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insertar nuevo texto a la página actual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1038"/>
        <source>Insert new text to current page</source>
        <translation>Inserte nuevo texto en actual página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1041"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1046"/>
        <location filename="../../src/mainwindow.cpp" line="5086"/>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insertar Imagen (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insertar nueva imagen a la página actual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1052"/>
        <source>Insert new image to current page</source>
        <translation>Inserte nueva imagen en actual página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1055"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insertar Vínculo (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insertar nuevo vínculo a la página actual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1098"/>
        <source>Insert new link to current page</source>
        <translation>Inserte nuevo vínculo en actual página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1106"/>
        <source>Text Field</source>
        <translation>Caja de Edición</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1117"/>
        <source>Check Box</source>
        <translation>Caja de Verificación</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1125"/>
        <source>Radio Button</source>
        <translation>Botón Circular</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1133"/>
        <source>Combo Box</source>
        <translation>Cuadro combinado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1141"/>
        <source>List Box</source>
        <translation>Caja de Lista</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1185"/>
        <source>Check for Updates</source>
        <translation>Verifica por Actualizaciones</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1252"/>
        <location filename="../../src/mainwindow.ui" line="1255"/>
        <source>Open Object Inspector</source>
        <translation>Abrir Inspector de Objetos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1260"/>
        <location filename="../../src/mainwindow.ui" line="1263"/>
        <source>Crop Pages</source>
        <translation>Recortar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1266"/>
        <source>Ctrl+K</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1271"/>
        <location filename="../../src/mainwindow.ui" line="1274"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Rotar 90 grados a la Derecha</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1279"/>
        <location filename="../../src/mainwindow.ui" line="1282"/>
        <location filename="../../src/mainwindow.ui" line="1285"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Rotar 90 grados a la Izquierda</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1290"/>
        <source>Export Form Data...</source>
        <translation>Exportar Datos Forma...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1295"/>
        <source>Import Form Data...</source>
        <translation>Importar Datos Forma...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1300"/>
        <source>Export Comments Data...</source>
        <translation>Exportar Datos Comentarios...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1305"/>
        <source>Import Comments Data...</source>
        <translation>Importar Datos Comentarios...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1310"/>
        <source>Save Optimized As...</source>
        <translation>Guarda Optimizado Como...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1313"/>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1324"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1337"/>
        <source>Document JavaScript</source>
        <translation>JavaScript Documento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1342"/>
        <source>Document Actions</source>
        <translation>Acciones de Documento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1350"/>
        <source>Replace Document Colors</source>
        <translation>Reemplace Colores Del Documento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1355"/>
        <source>Paste to Multiple Pages</source>
        <translation>Pegar en varias páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1358"/>
        <source>Ctrl+Shift+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1363"/>
        <source>JavaScript Console</source>
        <translation>Consola de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1366"/>
        <source>Ctrl+J</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1371"/>
        <source>Page Properties</source>
        <translation>Propiedades de la página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1379"/>
        <location filename="../../src/mainwindow.ui" line="1425"/>
        <location filename="../../src/mainwindow.ui" line="1438"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1382"/>
        <source>Ctrl+Shift+H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1398"/>
        <source>Menu Bar</source>
        <translation>Barra de menús</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1401"/>
        <source>F9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1409"/>
        <source>Show Cover Page During Facing</source>
        <translation>Mostrar la portada en su línea propia cuando se usa la vista de dos paginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1417"/>
        <source>Full Screen</source>
        <translation>Pantalla Completa</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1420"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1428"/>
        <source>Ctrl+Shift+W</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1441"/>
        <source>Ctrl+Shift+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1451"/>
        <location filename="../../src/mainwindow.ui" line="1454"/>
        <source>Align Center Horizontal</source>
        <translation>Alinear al centro horizontal</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1459"/>
        <location filename="../../src/mainwindow.ui" line="1462"/>
        <source>Align Center Vertical</source>
        <translation>Alinear al centro vertical</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1467"/>
        <source>Find Previous</source>
        <translation>Buscar Anterior</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1470"/>
        <source>Shift+F3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1475"/>
        <source>Pages to Text</source>
        <translation>Páginas a Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1494"/>
        <source>Send file via email</source>
        <translation>Enviar archivo vía correo electrónico</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1681"/>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1686"/>
        <source>Typewriter</source>
        <translation>Maquina de escribir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1764"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Vector Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select vector Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Imágenes de Vector&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar Imágenes de Vector para editar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1788"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select bitmap Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Imágenes&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar Imágenes Mapa de bits para editar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1796"/>
        <location filename="../../src/mainwindow.cpp" line="2940"/>
        <source>Show Comments List</source>
        <translation>Mostrar Lista de Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1812"/>
        <source>Extract all Images</source>
        <translation>Extraer todas las Imágenes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1817"/>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1825"/>
        <source>Take a Snapshot</source>
        <translation>Tomar una Instantánea</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1830"/>
        <source>Toolbar Settings</source>
        <translation>Ajustes Barra de Herramienta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1838"/>
        <source>Single Page</source>
        <translation>Página Individual</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1846"/>
        <source>Continuous</source>
        <translation>Contínuo</translation>
    </message>
    <message>
        <source>Text Box</source>
        <translation type="vanished">Cuadro de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1691"/>
        <source>Callout</source>
        <translation>Llamada</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1696"/>
        <source>Formatted Text</source>
        <translation>Texto Formateado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1699"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insertar Texto Formateado (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insertar nuevo Texto Formateado a la página actual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1480"/>
        <location filename="../../src/mainwindow.ui" line="1483"/>
        <source>OCR</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="250"/>
        <location filename="../../src/mainwindow.ui" line="1738"/>
        <source>Redaction</source>
        <translation>Redacción</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+6)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Herramienta mano (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use la herramienta mano para mover páginas, abrir vínculos y seleccionar texto.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt; {600;?} {6)?}</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="380"/>
        <source>Alt+6</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+7)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleccionar Texto (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar texto para copiar y pegar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt; {600;?} {7)?}</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="397"/>
        <source>Alt+7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="543"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Guardar&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Guardar el documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="557"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Guardar Como PDF&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Guardar el documento con un nombre nuevo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="568"/>
        <source>System Print...</source>
        <translation>Sistema de Impresión...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="571"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;System Print Dialog&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print using system dialog...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cuadro Diálogo Impresión del Sistema&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprimir usando el diálogo del sistema...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="640"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Documento&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Selecciona y edita texto, imágenes, anotaciones, campos de formularios...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="657"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Objects&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Objeto Texto&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar texto para edición&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="671"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Elimina Objeto(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Elimina Objeto(s) actualmente seleccionado(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="699"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Forms&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Formulario&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar formulario  para edición&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="727"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nuevo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Crear nuevo PDF en blanco&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="738"/>
        <source>Pages to Images</source>
        <translation>Páginas a Imágenes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="749"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Imprimir&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprimir el documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="763"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cortar&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Corte Objeto(s) seleccionado(s) y póngalo(s) en el Portapapeles&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="777"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copiar&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copie Objeto(s) seleccionado(s) y póngalo(s) en el Portapapeles&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="791"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Pegar&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Pegue desde el Portapapeles&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="835"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Deshacer&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Deshacer la última acción&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Rehacer&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Rehacer la acción previamente deshecha.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="980"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Propiedades&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Abrir ventana con propiedades de documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1035"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insertar Texto&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insertar nuevo texto a la página actual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1049"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insertar Imagen&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insertar nueva imagen a la página actual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1095"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insertar Vínculo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insertar nuevo vínculo a la página actual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1488"/>
        <source>Email</source>
        <translation>Correo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1491"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Entregar mensajes&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Enviar archivo vía correo electrónico&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1502"/>
        <location filename="../../src/mainwindow.ui" line="1505"/>
        <source>Grid</source>
        <translation>Cuadrícula</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1508"/>
        <source>Ctrl+U</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1516"/>
        <location filename="../../src/mainwindow.ui" line="1519"/>
        <source>Snap to Grid</source>
        <translation>Encajar a la cuadricula</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1522"/>
        <source>Ctrl+Shift+U</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1530"/>
        <location filename="../../src/mainwindow.ui" line="1533"/>
        <source>Distance Tool</source>
        <translation>Herramientas Distancia</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1541"/>
        <location filename="../../src/mainwindow.ui" line="1544"/>
        <source>Perimeter Tool</source>
        <translation>Perímetro</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1552"/>
        <location filename="../../src/mainwindow.ui" line="1555"/>
        <source>Area Tool</source>
        <translation>Área</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1574"/>
        <location filename="../../src/mainwindow.ui" line="1577"/>
        <source>Arrow</source>
        <translation>Flecha</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1618"/>
        <location filename="../../src/mainwindow.ui" line="1621"/>
        <source>Attach a File as a Comment</source>
        <translation>Adjuntar un archivo como comentario</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1626"/>
        <source>From Scanner</source>
        <translation>Desde escáner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1629"/>
        <location filename="../../src/mainwindow.ui" line="1632"/>
        <source>Create a new document from scanner</source>
        <translation>Crear desde el escáner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1637"/>
        <source>From Files</source>
        <translation>Desde archivo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1640"/>
        <location filename="../../src/mainwindow.ui" line="1643"/>
        <source>Create a new document from files</source>
        <translation>Crear nuevo PDF a partir de formatos de archivos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1659"/>
        <location filename="../../src/mainwindow.ui" line="1662"/>
        <source>Brush</source>
        <translation>Pincel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1678"/>
        <source>Menu</source>
        <translation>Barra de menús</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="860"/>
        <source>Send to Back</source>
        <translation>Enviar al Fondo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="863"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Enviar al Fondo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Enviar al Fondo el objeto seleccionado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="677"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1196"/>
        <source>Statusbar</source>
        <translation>Barra de Estado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="410"/>
        <location filename="../../src/mainwindow.ui" line="413"/>
        <source>First Page</source>
        <translation>Primera Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="421"/>
        <location filename="../../src/mainwindow.ui" line="424"/>
        <source>Previous Page</source>
        <translation>Página Anterior</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="432"/>
        <location filename="../../src/mainwindow.ui" line="435"/>
        <source>Next Page</source>
        <translation>Página Siguiente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="443"/>
        <location filename="../../src/mainwindow.ui" line="446"/>
        <source>Last Page</source>
        <translation>ültima Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="688"/>
        <source>Alt+Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1120"/>
        <source>Check box</source>
        <translation>Caja de Verificación</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1109"/>
        <source>Edit Box</source>
        <translation>Caja de Edición</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1128"/>
        <source>Radio button</source>
        <translation>Botón Circular</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1144"/>
        <source>List box</source>
        <translation>Caja de Lista</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1136"/>
        <source>Combo box</source>
        <translation>Combo box</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1204"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1157"/>
        <location filename="../../src/mainwindow.ui" line="1160"/>
        <source>Signature</source>
        <translation>Firma</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Pegar (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Pegue desde el Portapapeles&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="813"/>
        <location filename="../../src/mainwindow.ui" line="816"/>
        <source>Set Fit to Page</source>
        <translation>Fijar Ajustar a Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1060"/>
        <location filename="../../src/mainwindow.ui" line="1063"/>
        <location filename="../../src/mainwindow.ui" line="1563"/>
        <location filename="../../src/mainwindow.ui" line="1566"/>
        <source>Line</source>
        <translation>Línea</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1068"/>
        <location filename="../../src/mainwindow.ui" line="1071"/>
        <location filename="../../src/mainwindow.ui" line="1585"/>
        <location filename="../../src/mainwindow.ui" line="1588"/>
        <source>Rectangle</source>
        <translation>Rectángulo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1076"/>
        <location filename="../../src/mainwindow.ui" line="1079"/>
        <location filename="../../src/mainwindow.ui" line="1596"/>
        <location filename="../../src/mainwindow.ui" line="1599"/>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="vanished">Vista Previa Impresión</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="882"/>
        <location filename="../../src/mainwindow.ui" line="885"/>
        <source>Align Left</source>
        <translation>Alinear a Izquierda</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="890"/>
        <location filename="../../src/mainwindow.ui" line="893"/>
        <source>Align Right</source>
        <translation>Alinear a Derecha</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="898"/>
        <location filename="../../src/mainwindow.ui" line="901"/>
        <source>Align Top</source>
        <translation>Alinear Arriba</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="969"/>
        <location filename="../../src/mainwindow.ui" line="972"/>
        <source>Align Bottom</source>
        <translation>Alinear Abajo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="626"/>
        <location filename="../../src/mainwindow.ui" line="629"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Reduce Página Miniaturas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="618"/>
        <location filename="../../src/mainwindow.ui" line="621"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Agranda Página Miniaturas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="741"/>
        <source>Images</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="906"/>
        <location filename="../../src/mainwindow.ui" line="909"/>
        <source>Insert Blank Pages</source>
        <translation>Inserta Página en Blanco</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="977"/>
        <source>Properties</source>
        <translation>Propiedades</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="989"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insertar Texto (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insertar nuevo texto a la página actual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insertar Imagen (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insertar nueva imagen a la página actual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insertar Vínculo (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insertar nuevo vínculo a la página actual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1101"/>
        <source>Ctrl+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1112"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1175"/>
        <source>Home page</source>
        <translation>Página Principal</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1180"/>
        <source>Register...</source>
        <translation>Registro...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="vanished">Verifica por Actualizaciones</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="832"/>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Deshacer (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Deshacer la última acción&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="841"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1084"/>
        <location filename="../../src/mainwindow.ui" line="1087"/>
        <location filename="../../src/mainwindow.ui" line="1607"/>
        <location filename="../../src/mainwindow.ui" line="1610"/>
        <source>Pencil</source>
        <translation>Lápiz</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1149"/>
        <location filename="../../src/mainwindow.ui" line="1152"/>
        <source>Button</source>
        <translation>Botón</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="454"/>
        <location filename="../../src/mainwindow.ui" line="457"/>
        <source>Zoom In</source>
        <translation>Acercamiento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="460"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="479"/>
        <location filename="../../src/mainwindow.ui" line="482"/>
        <source>Zoom Out</source>
        <translation>Alejamiento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="485"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="468"/>
        <location filename="../../src/mainwindow.ui" line="471"/>
        <source>Actual Size</source>
        <translation>Tamaño Actual</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="402"/>
        <location filename="../../src/mainwindow.ui" line="405"/>
        <source>Settings</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1170"/>
        <source>Contents</source>
        <translation>Contenidos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="493"/>
        <location filename="../../src/mainwindow.ui" line="496"/>
        <source>Highlight Fields</source>
        <translation>Campos Resaltados</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="371"/>
        <location filename="../../src/mainwindow.ui" line="377"/>
        <source>Hand Tool</source>
        <translation>Herramienta Mano</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="654"/>
        <source>Edit Text</source>
        <translation>Editar Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="925"/>
        <location filename="../../src/mainwindow.ui" line="928"/>
        <source>Page layout</source>
        <translation>Diseño de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="846"/>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Rehacer (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Rehacer la acción previamente deshecha.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="855"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="760"/>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="49"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="97"/>
        <source>Page Display</source>
        <translation>Presentación de página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="106"/>
        <source>Go To</source>
        <translation>Navegación de página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="118"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="172"/>
        <location filename="../../src/mainwindow.ui" line="1244"/>
        <source>Forms</source>
        <translation>Formas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="229"/>
        <source>Header and Footer</source>
        <translation>Encabezados/Pies de página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="236"/>
        <source>Watermark</source>
        <translation>Marcas de agua</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="243"/>
        <source>Background</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="288"/>
        <source>Measurements</source>
        <translation>Mediciones</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="296"/>
        <location filename="../../src/mainwindow.cpp" line="2818"/>
        <source>Drawing</source>
        <translation>Dibujo</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Abrir Archivo (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Abrir Archivo PDF o XPS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="360"/>
        <location filename="../../src/mainwindow.ui" line="363"/>
        <source>About</source>
        <translation>Acerca De</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Herramienta mano (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use la herramienta mano para mover páginas, abrir vínculos y seleccionar texto.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleccionar Texto (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar texto para copiar y pegar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="416"/>
        <source>Home</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="449"/>
        <source>End</source>
        <translation>Fin</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="504"/>
        <location filename="../../src/mainwindow.ui" line="507"/>
        <source>Reset Forms</source>
        <translation>Restaurar Formas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="515"/>
        <location filename="../../src/mainwindow.ui" line="518"/>
        <source>Fit Page</source>
        <translation>Ajustar a Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="529"/>
        <location filename="../../src/mainwindow.ui" line="532"/>
        <source>Fit Width</source>
        <translation>Ajustar al Ancho</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Guardar (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Guardar el documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Guardar Como PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Guardar el documento con un nombre nuevo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="599"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="607"/>
        <location filename="../../src/mainwindow.ui" line="610"/>
        <source>Facing Pages</source>
        <translation>Páginas Enfrentadas</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Objeto Texto(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar texto para edición&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Elimina Objeto(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Elimina Objeto(s) actualmente seleccionado(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="682"/>
        <location filename="../../src/mainwindow.ui" line="685"/>
        <source>Delete Pages</source>
        <translation>Eliminar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="696"/>
        <location filename="../../src/mainwindow.ui" line="702"/>
        <location filename="../../src/mainwindow.ui" line="1651"/>
        <source>Edit Forms</source>
        <translation>Editar Formularios</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Formulario (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleccionar formulario  para edición&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="719"/>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nuevo (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Crear nuevo PDF en blanco&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cortar (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Corte Objeto(s) seleccionado(s) y póngalo(s) en el Portapapeles&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="769"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="774"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copiar (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copie Objeto(s) seleccionado(s) y póngalo(s) en el Portapapeles&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="783"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="788"/>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="797"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="802"/>
        <location filename="../../src/mainwindow.ui" line="805"/>
        <source>Select All</source>
        <translation>Seleccionar Todo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="808"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="637"/>
        <source>Edit Document</source>
        <translation>Editar Documento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="646"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1092"/>
        <source>Link</source>
        <translation>Vínculo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1008"/>
        <location filename="../../src/mainwindow.ui" line="1011"/>
        <source>Highlight Text</source>
        <translation>Texto Resaltado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="994"/>
        <source>Add Sticky Note</source>
        <translation>Agregar Nota Adhesiva</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1016"/>
        <location filename="../../src/mainwindow.ui" line="1019"/>
        <source>Strikeout Text</source>
        <translation>Tachar Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1024"/>
        <location filename="../../src/mainwindow.ui" line="1027"/>
        <source>Underline Text</source>
        <translation>Subrayar Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="388"/>
        <source>Select Text</source>
        <translation>Seleccionar Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="705"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1165"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="821"/>
        <location filename="../../src/mainwindow.ui" line="824"/>
        <location filename="../../src/mainwindow.ui" line="1332"/>
        <source>Find</source>
        <translation>Encontrar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1321"/>
        <source>Find Next</source>
        <translation>Encontrar Siguiente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="936"/>
        <location filename="../../src/mainwindow.ui" line="939"/>
        <source>Rotate Pages</source>
        <translation>Rotar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="917"/>
        <location filename="../../src/mainwindow.ui" line="920"/>
        <source>Move Pages</source>
        <translation>Mover Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1772"/>
        <source>Next View</source>
        <translation>Siguiente Vista</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1777"/>
        <source>Previous View</source>
        <translation>Vista Anterior</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1785"/>
        <source>Edit Images</source>
        <translation>Editar Imágenes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1791"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2318"/>
        <source>Open failed</source>
        <translation>Falló Abrir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2319"/>
        <source>Cannot open file :
</source>
        <translation>No puede abrir archivo:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="64"/>
        <source>Empty recent files list</source>
        <translation>Vaciar lista archivos recientes</translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation type="vanished">Previo/Sig</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation type="vanished">Herramientas Edición</translation>
    </message>
    <message>
        <source>Page :</source>
        <translation type="vanished">Pág.:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="352"/>
        <source>Open a PDF file</source>
        <translation>Abrir un archivo PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="945"/>
        <location filename="../../src/mainwindow.cpp" line="5987"/>
        <location filename="../../src/mainwindow.cpp" line="6049"/>
        <source>untitled</source>
        <translation>intitulado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="986"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Archivos PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2150"/>
        <source>Recent Files</source>
        <translation>Archivos Recientes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="362"/>
        <location filename="../../src/mainwindow.cpp" line="468"/>
        <location filename="../../src/mainwindow.cpp" line="536"/>
        <location filename="../../src/mainwindow.cpp" line="586"/>
        <source>There was an error opening the document !</source>
        <translation>Hubo un error abriendo el documento !</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps);;All Files (*)</source>
        <translation type="vanished">Todos los Archivos Compatibles (*.pdf *.xps);;Archivos PDF (*.pdf);;Archivos XPS (*.xps);;Todos los Archivos (*)</translation>
    </message>
    <message>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation type="vanished">Guardar en XPS no está temporalmente soportado.
Elija el nombre del archivo PDF para guardar.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1194"/>
        <source>Export completed</source>
        <translation>Exportación completada</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1406"/>
        <location filename="../../src/mainwindow.cpp" line="1433"/>
        <source>Can&apos;t find :</source>
        <translation>No puede encontrar:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1497"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Se requiere que reinicie el programa para que los cambios surtan efectos.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="101"/>
        <source>Default</source>
        <translation>Por Defecto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5165"/>
        <source>All Supported Files (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF Files (*.pdf *.PDF);;FDF Files (*.fdf *.FDF);;XPS Files (*.xps *.XPS);;TIFF Files (*.tif *.tiff);;All Files (*)</source>
        <translation>Todos los Archivos Compatibles (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF Files (*.pdf *.PDF);;FDF Files (*.fdf *.FDF);;XPS Files (*.xps *.XPS);;TIFF Files (*.tif *.tiff);;All Files (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1217"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>Imágenes PNG (*.png);;Imágenes BMP (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="429"/>
        <source>The file you are attempting to open contains comments or form data that are supposed to be placed on</source>
        <translation>El archivo que está intentando abrir contiene comentarios o datos de formulario que deben ser colocados</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="431"/>
        <source>This document cannot be found.</source>
        <translation>Este documento no se puede encontrar.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="431"/>
        <source>Would you like to browse and attempt to locate this document?</source>
        <translation>¿Le gustaría navegar e intentar localizar este documento?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1455"/>
        <source>Saved Settings</source>
        <translation>Configuración guardada</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2550"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>El documento %s ha sido modificado. 
¿Quiére guardar los cambios?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2557"/>
        <source>Close Without Saving</source>
        <translation>Cerrar Sin Guardar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2558"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2785"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="36"/>
        <source>All Reviewers</source>
        <translation>Todos los Revisores</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2918"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="16"/>
        <source>Hide All Comments</source>
        <translation>Ocultar Todos los Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2923"/>
        <source>Show All Comments</source>
        <translation>Mostrar Todos los Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2936"/>
        <source>Hide Comments List</source>
        <translation>Ocultar Lista de Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3107"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation>Master PDF Editor no puede encontrar ningún encabezado y pie de página en el documento.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3120"/>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation>¿Desea eliminar los encabezados y pies de página del documento?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3142"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation>Master PDF Editor no puede encontrar marcas de agua en el documento.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3155"/>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation>¿Desea eliminar las marcas de agua del documento?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3177"/>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation>Master PDF Editor no puede encontrar ningún fondo en el documento.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3190"/>
        <source>Do you want to delete the Background from the document?</source>
        <translation>¿Desea eliminar el fondo del documento?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4427"/>
        <location filename="../../src/mainwindow.cpp" line="4449"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>¿Está seguro de reiniciar todas las barras de herramientas para dejarlas predeterminadas?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4588"/>
        <source>Master PDF Editor can&apos;t find any Redaction in the document!</source>
        <translation>¡Master PDF Editor no puede encontrar ninguna Redacción en el documento!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5098"/>
        <source>Text Block</source>
        <translation>Bloque de Texto</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Todos los Archivos (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="obsolete">Archivos de Imágenes (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4701"/>
        <source>Your installed version of Qt</source>
        <translation>Su versión instalada de Qt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5071"/>
        <source>Characters</source>
        <translation>Caracteres</translation>
    </message>
    <message>
        <source>Chacters</source>
        <translation type="vanished">Caracteres</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5072"/>
        <source>Font type</source>
        <translation>Tipo Fuente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5074"/>
        <source>Font Embedded</source>
        <translation>Fuente Incrustada</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5076"/>
        <source>Font Not Embedded</source>
        <translation>Fuente No Incrustada</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5082"/>
        <location filename="../../src/mainwindow.cpp" line="5251"/>
        <source>Width</source>
        <translation>Ancho</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5083"/>
        <location filename="../../src/mainwindow.cpp" line="5252"/>
        <source>Height</source>
        <translation>Alto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5084"/>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5090"/>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5094"/>
        <source>Shading</source>
        <translation>Sombreado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="323"/>
        <location filename="../../src/mainwindow.ui" line="1807"/>
        <source>Objects</source>
        <translation>Objetos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5119"/>
        <location filename="../../src/mainwindow.cpp" line="5262"/>
        <source>Selected</source>
        <translation>Seleccionado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5251"/>
        <location filename="../../src/mainwindow.cpp" line="5252"/>
        <source>pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5271"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5996"/>
        <location filename="../../src/mainwindow.cpp" line="6017"/>
        <location filename="../../src/mainwindow.cpp" line="6020"/>
        <location filename="../../src/mainwindow.cpp" line="6058"/>
        <location filename="../../src/mainwindow.cpp" line="6078"/>
        <location filename="../../src/mainwindow.cpp" line="6081"/>
        <source>FDF Files (*.fdf)</source>
        <translation>Archivos FDF (*.fdf)</translation>
    </message>
    <message>
        <source>The unregistered version will insert a watermark</source>
        <translation type="obsolete">La versión no registrada insertará una marca de agua</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2678"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Ocurrió un error durante la verificación de firma!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="907"/>
        <location filename="../../src/mainwindow.cpp" line="1025"/>
        <location filename="../../src/mainwindow.cpp" line="3720"/>
        <location filename="../../src/mainwindow.cpp" line="3830"/>
        <location filename="../../src/mainwindow.cpp" line="3939"/>
        <source>Save failed</source>
        <translation>Falló Guardado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="43"/>
        <source>Ctrl+F12</source>
        <translation>Ctrl+F12</translation>
    </message>
    <message>
        <source>Ctrl+Shift++</source>
        <translation type="vanished">Ctrl+Shift++</translation>
    </message>
    <message>
        <source>Ctrl+Shift+-</source>
        <translation type="vanished">Ctrl+Shift+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="353"/>
        <source>You do not have access right to this encrypted document.</source>
        <translation>No tiene derecho de acceso a este documento encriptado.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="355"/>
        <source>It is encrypted with certificate absent from your system.</source>
        <translation>Está encriptado con un certificado ausente de su sistema.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="908"/>
        <location filename="../../src/mainwindow.cpp" line="1026"/>
        <location filename="../../src/mainwindow.cpp" line="3721"/>
        <location filename="../../src/mainwindow.cpp" line="3831"/>
        <location filename="../../src/mainwindow.cpp" line="3940"/>
        <source>Can&apos;t save to the file:</source>
        <translation>No puede guardar el archivo:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="908"/>
        <location filename="../../src/mainwindow.cpp" line="1026"/>
        <location filename="../../src/mainwindow.cpp" line="3721"/>
        <location filename="../../src/mainwindow.cpp" line="3831"/>
        <location filename="../../src/mainwindow.cpp" line="3940"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Puede que el archivo sea de sólo lectura o esté siendo usado por otra aplicación.</translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation type="vanished">Su versión ya tiene la última actualización!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="15"/>
        <source>Cannot connect! Please verify that you are connected to the Internet and check for updates again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="31"/>
        <source>You already have the latest version!</source>
        <translation>Su versión ya tiene la última actualización!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="38"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Una Nueva Versión Disponible !
¿Quiére Descargarla Ya?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="42"/>
        <source>What&apos;s new</source>
        <translation>Qué hay de nuevo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5169"/>
        <location filename="../../src/mainwindow.cpp" line="5171"/>
        <location filename="../../src/mainwindow.cpp" line="6017"/>
        <location filename="../../src/mainwindow.cpp" line="6020"/>
        <location filename="../../src/mainwindow.cpp" line="6078"/>
        <location filename="../../src/mainwindow.cpp" line="6081"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation type="vanished">Todos los Archivos (*.pdf *.xps);;Archivos PDF (*.pdf);;Archivos XPS (*.xps)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="713"/>
        <location filename="../../src/mainwindow.ui" line="716"/>
        <location filename="../../src/mainwindow.ui" line="1249"/>
        <source>Object Inspector</source>
        <translation>Inspector de Objetos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="125"/>
        <source>Toolbars</source>
        <translation>Barras de Herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="89"/>
        <source>Zoom</source>
        <translation>Acercamiento</translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation>Texto reconocido</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="17"/>
        <source>Not Text</source>
        <translation>No texto</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation>Mover Págs</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="26"/>
        <source>Page Range</source>
        <translation>Rango de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="32"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Muestra: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="78"/>
        <source>Current Page</source>
        <translation>Actual Página</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="88"/>
        <source>Pages from</source>
        <translation>Páginas desde</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>to:</source>
        <translation>hasta:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="140"/>
        <source>Destination</source>
        <translation>Destino</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="152"/>
        <source>To:</source>
        <translation>A:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="162"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="211"/>
        <source>First</source>
        <translation>Primera</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="218"/>
        <source>Last</source>
        <translation>Última</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>Tamaño de Página</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="194"/>
        <source>Width</source>
        <translation>Ancho</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="231"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="33"/>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="38"/>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="43"/>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="48"/>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="53"/>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="58"/>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="63"/>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="68"/>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="73"/>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="78"/>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="83"/>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="88"/>
        <source>Letter</source>
        <translation>Carta</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="93"/>
        <source>Tabloid</source>
        <translation>Tabloide</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="98"/>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="103"/>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="108"/>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="113"/>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="118"/>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="123"/>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="128"/>
        <source>Statement</source>
        <translation>Declaración</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="133"/>
        <source>Executive</source>
        <translation>Ejecutivo</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="138"/>
        <source>Folio</source>
        <translation>Folio</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="143"/>
        <source>Quarto</source>
        <translation>Cuarto</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="148"/>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="153"/>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="158"/>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="163"/>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="168"/>
        <source>ANSI F</source>
        <translation>ANSI F</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="173"/>
        <source>Custom page size</source>
        <translation>Tamaño de página personalizada</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="218"/>
        <source>Portrait</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="223"/>
        <source>Landscape</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="267"/>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">puntos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pulgadas</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">milímetros</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="296"/>
        <source>Contents Size</source>
        <translation>Tamaño del Contenido</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="308"/>
        <source>Left margin</source>
        <translation>Margen Izquierdo</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="348"/>
        <source>Top margin</source>
        <translation>Margen Superior</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="328"/>
        <source>Right margin</source>
        <translation>Margen Derecho</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="275"/>
        <source>Points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="280"/>
        <source>Inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="285"/>
        <source>Millimeters</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="368"/>
        <source>Bottom margin</source>
        <translation>Margen Inferior</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="391"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="397"/>
        <source>Before current page</source>
        <translation>Antes de página actual</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="414"/>
        <source>After current page</source>
        <translation>Después de página actual</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="421"/>
        <source>After last page</source>
        <translation>Despúes de última página</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="407"/>
        <source>Before first page</source>
        <translation>Antes de primera página</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="431"/>
        <source>Number of pages</source>
        <translation>Número de páginas</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="457"/>
        <source>Page(s)</source>
        <translation>Páginas(s)</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="437"/>
        <source>Create</source>
        <translation>Crear</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="obsolete">px</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="183"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="210"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="232"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="147"/>
        <source>Page Range</source>
        <translation>Rango de Página</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="153"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Muestra: : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="160"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="190"/>
        <source>Current Page</source>
        <translation>Página Actual</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="200"/>
        <source>All Pages</source>
        <translation>Todas las Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="20"/>
        <source>Languages</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="50"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="190"/>
        <source>Selected</source>
        <translation>Seleccionado</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="213"/>
        <source>Install languages</source>
        <translation>Instalar idiomas</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="88"/>
        <source>Searchable Text</source>
        <translation>Texto de búsqueda</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="98"/>
        <source>Editable Text</source>
        <translation>Texto editable</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="118"/>
        <source>Font Family</source>
        <translation>Familia Fuente</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="233"/>
        <source>Manually edit all recognized text</source>
        <translation>Editar el texto reconocido</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="60"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="287"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="59"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation>¿Está seguro de que desea detener el reconocimiento de documentos?</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="57"/>
        <source>No Properties
There is no object selections.</source>
        <translation>Sin Propiedades
No hay selecciones de objetos.</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="341"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3227"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3508"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2131"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="142"/>
        <source>Property</source>
        <translation>Propiedad</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="147"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="923"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="476"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="807"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="486"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2771"/>
        <source>Actions</source>
        <translation>Acciones</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="508"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1879"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1913"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1985"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2041"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2890"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="518"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="794"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Up Label</source>
        <translation type="vanished">Etiqueta Arriba</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="584"/>
        <source>Behavior</source>
        <translation>Comportamiento</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="738"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1319"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1465"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1620"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="272"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="743"/>
        <source>Push</source>
        <translation>Empujar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="748"/>
        <source>Outline</source>
        <translation>Esquema</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="753"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1324"/>
        <source>Invert</source>
        <translation>Invertir</translation>
    </message>
    <message>
        <source>Down Label</source>
        <translation type="vanished">Etiqueta Abajo</translation>
    </message>
    <message>
        <source>RollOver Label</source>
        <translation type="vanished">Enrollar Etiqueta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="787"/>
        <source>Item</source>
        <translation>Elemento</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="820"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1095"/>
        <source>Export Value</source>
        <translation>Exportar Valor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="660"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="862"/>
        <source>Up</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="665"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="846"/>
        <source>Down</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="890"/>
        <source>Sort Items</source>
        <translation>Clasificar Elementos</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="869"/>
        <source>Commit selected value immediately</source>
        <translation>Comprometer valor seleccionado inmediatamente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="883"/>
        <source>Multiple selection</source>
        <translation>Selección Múltiple</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="876"/>
        <source>Allow user to enter custom text</source>
        <translation>Permitir al usuario introducir texto personalizado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1028"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1035"/>
        <source>Scrollable</source>
        <translation>Desplazable</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1042"/>
        <source>Check spelling</source>
        <translation>Revisar ortografía</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="963"/>
        <source>Limit to</source>
        <translation>Limitar a</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="977"/>
        <source>chars</source>
        <translation>caracteres</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="984"/>
        <source>Split into</source>
        <translation>Dividir en</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="956"/>
        <source>Allow Rich Text formatting</source>
        <translation>Permitir el formato de Texto Enriquecido</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1021"/>
        <source>Multi-line</source>
        <translation>Multi-líneas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="998"/>
        <source>cells</source>
        <translation>celdas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="938"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2519"/>
        <source>Left</source>
        <translation>Izquierdo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="943"/>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="948"/>
        <source>Right</source>
        <translation>Derecho</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1008"/>
        <source>Default Value</source>
        <translation>Valor por Defecto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="930"/>
        <source>Alignment</source>
        <translation>Alineación</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1108"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2657"/>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1119"/>
        <source>Check</source>
        <translation>Verifica</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1124"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="248"/>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1129"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="250"/>
        <source>Cross</source>
        <translation>Cruz</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1134"/>
        <source>Diamond</source>
        <translation>Diamante</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1139"/>
        <source>Square</source>
        <translation>Cuadrado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1144"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="259"/>
        <source>Star</source>
        <translation>Estrella</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1072"/>
        <source>Checked by Default</source>
        <translation>Marcada por defecto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="591"/>
        <source>Layout</source>
        <translation>Diseño</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="602"/>
        <source>Label only</source>
        <translation>Sólo etiqueta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="607"/>
        <source>Icon only</source>
        <translation>Sólo ícono</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="612"/>
        <source>Icon top, label bottom</source>
        <translation>Icono superior, etiqueta inferior</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="617"/>
        <source>Label top, icon bottom</source>
        <translation>Etiqueta superior, ícono inferior</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="622"/>
        <source>Icon left, label right</source>
        <translation>Ícono izquierdo, etiqueta derecha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="627"/>
        <source>label left, icon right</source>
        <translation>Etiqueta izquierda, ícono derecho</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="632"/>
        <source>Label over icon</source>
        <translation>Etiqueta sobre ícono</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="647"/>
        <source>Icon and Label</source>
        <translation>Ícono y Etiqueta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="670"/>
        <source>Rollover</source>
        <translation>De la vuelta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="687"/>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="694"/>
        <source>Choose Icon...</source>
        <translation>Elegir Ícono...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="717"/>
        <source>Clear</source>
        <translation>Claro</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="724"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1196"/>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation>Botones con igual nombre y valor se seleccionan al unísono</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1261"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3217"/>
        <source>Line Thickness</source>
        <translation>Grosor de la línea</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1275"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3167"/>
        <source>Border Color</source>
        <translation>Color de Borde</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1282"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3210"/>
        <source>Line Style</source>
        <translation>Estilo de Línea</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1290"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3182"/>
        <source>Solid</source>
        <translation>Sólido</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1295"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3187"/>
        <source>Dashed</source>
        <translation>Discontínua</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1300"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3202"/>
        <source>Underline</source>
        <translation>Subrayado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1308"/>
        <source>Highlight</source>
        <translation>Resaltado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1329"/>
        <source>OutLine</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1334"/>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1352"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1411"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2790"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2909"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1451"/>
        <source>Format category</source>
        <translation>Categoría de formato</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1470"/>
        <source>Number</source>
        <translation>Número</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1475"/>
        <source>Percentage</source>
        <translation>Porcentaje</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1480"/>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1485"/>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1490"/>
        <source>Special</source>
        <translation>Especial</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1495"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1650"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="234"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="238"/>
        <source>Custom</source>
        <translation>Personal</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1514"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1519"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1524"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1529"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1534"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1539"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1544"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1549"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1554"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1559"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1564"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1573"/>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1578"/>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1583"/>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1588"/>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1602"/>
        <source>Currency Symbol</source>
        <translation>Símbolo de Moneda</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1625"/>
        <source>Dollar ($)</source>
        <translation>Dólar ($)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1630"/>
        <source>Euro (€)</source>
        <translation>Euro (€)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1635"/>
        <source>Pound (£)</source>
        <translation>Libra (£)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1640"/>
        <source>Yen (¥)</source>
        <translation>Yen (¥)</translation>
    </message>
    <message>
        <source>Ruble (Руб)</source>
        <translation type="vanished">Rublo (Руб)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1671"/>
        <source>Show parentheses</source>
        <translation>Muestra paréntesis</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1691"/>
        <source>Decimal Places</source>
        <translation>Lugares Decimales</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1698"/>
        <source>Separation Style</source>
        <translation>Estilo Separación</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1705"/>
        <source>Use red text</source>
        <translation>Use texto rojo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1722"/>
        <source>Date Options</source>
        <translation>Opciones de Fecha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1761"/>
        <source>Time Options</source>
        <translation>Opciones de Hora</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1794"/>
        <source>Special Options</source>
        <translation>Opciones Especiales</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1852"/>
        <source>Format Script</source>
        <translation>Formato Escritura</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1886"/>
        <source>KeyStroke Script</source>
        <translation>Estilo de Guión</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1937"/>
        <source>Validate</source>
        <translation>Validar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1958"/>
        <source>Validation Script</source>
        <translation>Secuencias ComandosValidación</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1993"/>
        <source>Calculate</source>
        <translation>Calcular</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2014"/>
        <source>Calculation Script</source>
        <translation>Comandos Cálculo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2143"/>
        <source>Fill text</source>
        <translation>Texto completo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2148"/>
        <source>Stroke Text</source>
        <translation>Trazo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2153"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3007"/>
        <source>Fill and Stroke</source>
        <translation>Completo y Trazo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2158"/>
        <source>Invisible</source>
        <translation>Invisible</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2172"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3174"/>
        <source>Fill Color</source>
        <translation>Color Completo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2198"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3075"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3465"/>
        <source>Line Width</source>
        <translation>Ancho de Línea</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2227"/>
        <source>Character spacing</source>
        <translation>Espaciado caracter</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2234"/>
        <source>Word spacing</source>
        <translation>Espaciado palabra</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2241"/>
        <source>Line height</source>
        <translation>Altura de la línea</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2284"/>
        <source>+</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2303"/>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2366"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2392"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2402"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2412"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2422"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2432"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2499"/>
        <source>Top</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2547"/>
        <source>Maintain aspect ratio</source>
        <translation>Mantener relación aspecto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2928"/>
        <source>Settings</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2950"/>
        <source>Always show Object Inspector</source>
        <translation>Siempre muestra Inspector de Objetos</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3551"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2476"/>
        <source>Rotate</source>
        <translation>Rotar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2575"/>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">puntos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pulgadas</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">milímetros</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2695"/>
        <source>Clipping Path</source>
        <translation>Ruta de Recorte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2828"/>
        <source>Selection change</source>
        <translation>Cambio de selección</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2856"/>
        <source>Do nothing</source>
        <translation>Hacer nada</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2863"/>
        <source>Execute this script</source>
        <translation>Ejecutar este script</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3192"/>
        <source>Beveled</source>
        <translation>Biselado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3197"/>
        <source>Inset</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3252"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3316"/>
        <source>ToolTip</source>
        <translation>Sugerencia</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3332"/>
        <source>Orientation</source>
        <translation>Orientación</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3340"/>
        <source>0 Degrees</source>
        <translation>0 Grados</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3345"/>
        <source>90 Degrees</source>
        <translation>90 Grados</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3350"/>
        <source>180 Degrees</source>
        <translation>180 Grados</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3355"/>
        <source>270 Degrees</source>
        <translation>270 Grados</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3376"/>
        <source>Read Only</source>
        <translation>Sólo Lectura</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3391"/>
        <source>Visible</source>
        <translation>Visible</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3396"/>
        <source>Hidden</source>
        <translation>Oculto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3401"/>
        <source>Visible but doesn&apos;t print</source>
        <translation>Visible pero no imprime</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3406"/>
        <source>Hidden but printable</source>
        <translation>Oculto pero imprime</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3414"/>
        <source>Required</source>
        <translation>Requerido</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3424"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3558"/>
        <source>Locked</source>
        <translation>Bloqueado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3501"/>
        <source>Subject</source>
        <translation>Sujeto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3538"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2078"/>
        <source>Font Family</source>
        <translation>Familia Fuente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="640"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1645"/>
        <source>Ruble (₽)</source>
        <translation>Rublo (₽)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2107"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3239"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2123"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2977"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3528"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2526"/>
        <source>Coordinates</source>
        <translation>Coordenadas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2534"/>
        <source>Absolute</source>
        <translation>Absoluto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2539"/>
        <source>Relative</source>
        <translation>Relativo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2583"/>
        <source>Points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2588"/>
        <source>Inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2593"/>
        <source>Millimeters</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2616"/>
        <source>Geometry</source>
        <translation>Geometría</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2638"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3281"/>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2676"/>
        <source>Matrix</source>
        <translation>Matriz</translation>
    </message>
    <message>
        <source>Cliping Path</source>
        <translation type="obsolete">Ruta de Recorte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2714"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2733"/>
        <source>Appearance</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2752"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2809"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2997"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3015"/>
        <source>Fill</source>
        <translation>Completo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3002"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3050"/>
        <source>Stroke</source>
        <translation>Trazo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3040"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3062"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3268"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3491"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3142"/>
        <source>Borders and Colors</source>
        <translation>Bordes y Colores</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3149"/>
        <source>Thin</source>
        <translation>Fino</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3154"/>
        <source>Medium</source>
        <translation>Medio</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3159"/>
        <source>Thick</source>
        <translation>Espesor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2185"/>
        <source>Stroke Color</source>
        <translation>Trazo Color</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2211"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3027"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3088"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3478"/>
        <source>Opacity</source>
        <translation>Opacidad</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Zip Code</source>
        <translation>Código ZIP</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Zip Code+4</source>
        <translation>Código+4 ZIP</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Phone Number</source>
        <translation>Número Teléfono</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Social Security Number</source>
        <translation>Número Seguro Social</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="247"/>
        <source>Check Mark</source>
        <translation>Marca de Verificación</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="249"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="251"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">Insertar Texto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="253"/>
        <source>Key</source>
        <translation>Tecla</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="254"/>
        <source>New Paragraph</source>
        <translation>Nuevo Parágrafo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="255"/>
        <source>Text Note</source>
        <translation>Texto Nota</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="256"/>
        <source>Paragraph</source>
        <translation>Parágrafo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="257"/>
        <source>Right Arrow</source>
        <translation>Flecha Derecha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="258"/>
        <source>Right Pointer</source>
        <translation>Apuntador Derecho</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="260"/>
        <source>Up Arrow</source>
        <translation>Flecha Arriba</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="261"/>
        <source>Up Left Arrow</source>
        <translation>Hasta Flecha izquierda</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="262"/>
        <source>Graph</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="263"/>
        <source>Paper Clip</source>
        <translation>Clip de Papel</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="264"/>
        <source>Attachment</source>
        <translation>Adjunto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="265"/>
        <source>Tag</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2265"/>
        <source>Text Block</source>
        <translation>Bloque de Texto</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Abrir</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1113"/>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Todos los Archivos (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1642"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1649"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1662"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1669"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1715"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Color de fuente&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambiar color de relleno&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1721"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Color de Fuente Trazada&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambiar Color de Fuente Trazada&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1897"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4010"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1902"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4030"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1906"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4050"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2155"/>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2197"/>
        <source>Shading</source>
        <translation>Sombreado</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="vanished">Encabezados/Pies de página</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="vanished">Marcas de agua</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="vanished">Fondo</translation>
    </message>
    <message>
        <source>Image Form</source>
        <translation type="vanished">Formulario de Imagen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2489"/>
        <source>Width</source>
        <translation>Ancho</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2509"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2176"/>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3383"/>
        <source>Form Field</source>
        <translation>Campo Formulario</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3306"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1654"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1703"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Familia de Fuentes&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambiar Familia de Fuentes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3123"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="432"/>
        <source>Goto a Page View</source>
        <translation>Ir a Vista Página</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="364"/>
        <source>Add an Action</source>
        <translation>Agregar una Acción</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="370"/>
        <source>Trigger</source>
        <translation>Disparador</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="378"/>
        <source>Mouse Up</source>
        <translation>Ratón Arriba</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="383"/>
        <source>Mouse Down</source>
        <translation>Ratón Abajo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="388"/>
        <source>Mouse Enter</source>
        <translation>Enter Ratón</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="393"/>
        <source>Mouse Exit</source>
        <translation>Salir Ratón</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="398"/>
        <source>On Receive Focus</source>
        <translation>Al Recibir Foco</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="403"/>
        <source>On Lose Focus</source>
        <translation>Al Perder Foco</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="424"/>
        <source>Action</source>
        <translation>Acción</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="437"/>
        <source>Open/execute a File</source>
        <translation>Abrir/ejecutar un Srchivo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="442"/>
        <source>Open a web link</source>
        <translation>Abrir un vínculo web</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="447"/>
        <source>Reset form</source>
        <translation>Restaurar Formulario</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="452"/>
        <source>Show/Hide fields</source>
        <translation>Muestra/Oculta campos</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="457"/>
        <source>Submit a form</source>
        <translation>Enviar un formulario</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="462"/>
        <source>Run a JavaScript</source>
        <translation>Ejecutar un JavaScript</translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="14"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="33"/>
        <source>Object TreeView</source>
        <translation>Objeto VistaÁrbol</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="20"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="40"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="79"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="248"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="274"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="328"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="vanished">Ver</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="20"/>
        <source>Expand All</source>
        <translation>Expandir Todo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="21"/>
        <source>Collapse All</source>
        <translation>Contraer Todo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="77"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="120"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="88"/>
        <source>Images</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="93"/>
        <source>Paths</source>
        <translation>Rutas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="98"/>
        <source>Shadings</source>
        <translation>Sombras</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="103"/>
        <source>Containers</source>
        <translation>Contenedores</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="126"/>
        <source>Text Fields</source>
        <translation>Campos de Texto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="131"/>
        <source>List Boxes</source>
        <translation>Cuadros de Lista</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="136"/>
        <source>Combo Boxes</source>
        <translation>Cuadros Combinados</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="141"/>
        <source>Check Boxes</source>
        <translation>Casillas de Verificaciуn</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="146"/>
        <source>Radio Buttons</source>
        <translation>Botones de Opciones</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="151"/>
        <source>Buttons</source>
        <translation>Botones</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="156"/>
        <source>Links</source>
        <translation>Vínculos</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="161"/>
        <source>Signatures</source>
        <translation>Firmas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="234"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Object</source>
        <translation type="obsolete">Objeto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="235"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="294"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas las Páginas</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="obsolete">Geometría</translation>
    </message>
</context>
<context>
    <name>OptionToolBarForm</name>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="20"/>
        <source>Tollbars</source>
        <translation>Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="71"/>
        <source>All tools:</source>
        <translation>Todas las herramientas:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="85"/>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="159"/>
        <source>Current toolbar tools:</source>
        <translation>Las herramientas de la actual barra de herramientas:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="248"/>
        <source>Toolbars:</source>
        <translation>Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="265"/>
        <source>Add Toolbar</source>
        <translation>Agregar Barra de Herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="272"/>
        <source>Delete Toolbar</source>
        <translation>Eliminar Barra de Herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="288"/>
        <source>Reset All</source>
        <translation>Resetear todo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="295"/>
        <source>Maximum tools</source>
        <translation>Herramientas máximas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="300"/>
        <source>Minimum tools</source>
        <translation>Herramientas mínimas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="167"/>
        <source>Please, name new toolbar</source>
        <translation>Por favor, nombre nueva barra de herramientas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="189"/>
        <source>ToolBar with this name already exist.</source>
        <translation>Ya existe una barra de herramientas con ese nombre.</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">Comentarios</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation type="obsolete">Maquina de escribir</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Nota Adhesiva</translation>
    </message>
    <message>
        <source>Attach a File as a Comment</source>
        <translation type="obsolete">Adjuntar un archivo como comentario</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Editar</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Deshacer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Rehacer</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Cortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Pegar</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Archivo</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Guardar</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">Imprimir</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">Encontrar</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formas</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">Firma</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">Botón Circular</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">Caja de Lista</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">Caja de Edición</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">Cuadro combinado</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">Caja de Verificación</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="obsolete">Botón</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="obsolete">Objetos</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">Lápiz</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">Elipse</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rectángulo</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Línea</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Insertar Texto</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation type="obsolete">Redacción</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation type="obsolete">Marca para Redacción</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">Editar Texto</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">Herramienta Mano</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Ver</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation type="obsolete">Vista Anterior</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation type="obsolete">Siguiente Vista</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="obsolete">Acercamiento</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Alejamiento</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Acercamiento</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">Ajustar a Página</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="obsolete">Ajustar al Ancho</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">Principal</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">Guardar Como...</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">Entregar mensajes</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation type="obsolete">Alinear a Izquierda</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation type="obsolete">Alinear a Derecha</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation type="obsolete">Alinear Arriba</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation type="obsolete">Alinear Abajo</translation>
    </message>
    <message>
        <source>Align Center Horizontal</source>
        <translation type="obsolete">Alinear al centro horizontal</translation>
    </message>
    <message>
        <source>Align Center Vertical</source>
        <translation type="obsolete">Alinear al centro vertical</translation>
    </message>
    <message>
        <source>Send Backward</source>
        <translation type="obsolete">Enviar Atrás</translation>
    </message>
    <message>
        <source>Bring Forward</source>
        <translation type="obsolete">Traer al Frente</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">Cuadrícula</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">Página Anterior</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">Página Siguiente</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation type="obsolete">Tamaño Actual</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation type="obsolete">Páginas Enfrentadas</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="obsolete">Rotar 90 grados a la Izquierda</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="obsolete">Rotar 90 grados a la Derecha</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation type="obsolete">Editar Documento</translation>
    </message>
    <message>
        <source>Edit Images</source>
        <translation type="obsolete">Editar Imágenes</translation>
    </message>
    <message>
        <source>Edit Vector Images</source>
        <translation type="obsolete">Editar Imágenes de Vector</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation type="obsolete">Editar Formularios</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation type="obsolete">Seleccionar Texto</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="obsolete">Eliminar Páginas</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation type="obsolete">Recortar Páginas</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation type="obsolete">Diseño de Páginas</translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation type="obsolete">Rotar Páginas</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation type="obsolete">Extraer Páginas...</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation type="obsolete">Insertar Páginas...</translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation type="obsolete">Acciones de Documento</translation>
    </message>
    <message>
        <source>Document JavaScript</source>
        <translation type="obsolete">JavaScript Documento</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="obsolete">Propiedades de la página</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="obsolete">Encabezados/Pies de página</translation>
    </message>
    <message>
        <source>Document</source>
        <translation type="obsolete">Documento</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="511"/>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="543"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>¿Está seguro de reiniciar todas las barras de herramientas para dejarlas predeterminadas?</translation>
    </message>
</context>
<context>
    <name>PDFTextEdit</name>
    <message>
        <location filename="../../src/docpage/texteditor/PDFTextEdit.cpp" line="331"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>Esta fuente no contiene estos caracteres.
Trate de elegir otra fuente.</translation>
    </message>
</context>
<context>
    <name>PageCounterWidget</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulario</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>Diseño Página</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="105"/>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="26"/>
        <location filename="../../src/PageLayoutDialog.ui" line="59"/>
        <location filename="../../src/PageLayoutDialog.ui" line="72"/>
        <location filename="../../src/PageLayoutDialog.ui" line="85"/>
        <location filename="../../src/PageLayoutDialog.ui" line="298"/>
        <location filename="../../src/PageLayoutDialog.ui" line="315"/>
        <location filename="../../src/PageLayoutDialog.ui" line="332"/>
        <location filename="../../src/PageLayoutDialog.ui" line="349"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="413"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="49"/>
        <source>Bottom</source>
        <translation>Desde abajo</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="42"/>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="112"/>
        <source>Right</source>
        <translation>Derecho</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="122"/>
        <source>Orientation</source>
        <translation>Orientación</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="130"/>
        <source>Portrait</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="135"/>
        <source>Landscape</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="279"/>
        <source>Contents Size</source>
        <translation>Tamaño del Contenido</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="291"/>
        <source>Left margin</source>
        <translation>Margen izquierdo</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="308"/>
        <source>Top margin</source>
        <translation>Margen superior</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="325"/>
        <source>Right margin</source>
        <translation>Margen derecho</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="342"/>
        <source>Bottom margin</source>
        <translation>Margen inferior</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="20"/>
        <location filename="../../src/PageLayoutDialog.ui" line="98"/>
        <source>Page Size</source>
        <translation>Tamaño de Página</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="vanished">Ancho</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished">px</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="433"/>
        <source> in</source>
        <translation>pulg</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="448"/>
        <source> mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="vanished">Altura</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="362"/>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">puntos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pulgadas</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">milímetros</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="146"/>
        <source>Page Range</source>
        <translation>Rango de Página</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="152"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="164"/>
        <source>From</source>
        <translation>desde</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="201"/>
        <source>of:</source>
        <translation>de:</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="212"/>
        <source>Even and Odd pages</source>
        <translation>Páginas Impares y Pares</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="217"/>
        <source>Even pages</source>
        <translation>Págs. Pares</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="222"/>
        <source>Odd pages</source>
        <translation>Págs. Impares</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Páginas desde</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="243"/>
        <source>Current Page</source>
        <translation>Página Actual</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="373"/>
        <source>Points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="378"/>
        <source>Inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="383"/>
        <source>Millimeters</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="253"/>
        <source>All Pages</source>
        <translation>Todas las Págs.</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="181"/>
        <source>to:</source>
        <translation>hasta:</translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation>Propiedades de la página</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="41"/>
        <source>Tab Order</source>
        <translation>Orden de tabulación</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="60"/>
        <source>Use Row Order</source>
        <translation>Usar orden de fila</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="67"/>
        <source>Use Column Order</source>
        <translation>Usar orden de columna</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="53"/>
        <source>Use Document Structure</source>
        <translation>Usar estructura de documento</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="74"/>
        <source>Unspecified</source>
        <translation>Sin especificar</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="111"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="117"/>
        <source>Actions</source>
        <translation>Acciones</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="192"/>
        <source>Add an Action</source>
        <translation>Agregar en Acción</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="205"/>
        <source>Trigger</source>
        <translation>Disparador</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation type="obsolete">Ratón Arriba</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="236"/>
        <source>Open Page</source>
        <translation>Abrir Página</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="241"/>
        <source>Close Page</source>
        <translation>Cerrar página</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="198"/>
        <source>Action</source>
        <translation>Acción</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Goto a Page View</source>
        <translation>Ir a Vista Página</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="255"/>
        <source>Open/execute a File</source>
        <translation>Abrir/ejecutar Archivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="260"/>
        <source>Open a web link</source>
        <translation>Abrir vínculo web</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="265"/>
        <source>Reset form</source>
        <translation>Restaurar formulario</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="270"/>
        <source>Show/Hide fields</source>
        <translation>Muestra/Oculta campos</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="275"/>
        <source>Submit a form</source>
        <translation>Enviar un formulario</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="280"/>
        <source>Run a JavaScript</source>
        <translation>Ejecutar un JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="212"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="30"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="34"/>
        <source>Current Page</source>
        <translation>Página Actual</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="132"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="151"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="14"/>
        <source>Printer Settings</source>
        <translation>Ajustes Impresora</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="20"/>
        <source>Paper</source>
        <translation>Papel</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="26"/>
        <source>Width:</source>
        <translation>Ancho:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="58"/>
        <source>Height:</source>
        <translation>Alto:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="77"/>
        <source>Page size:</source>
        <translation>Tamaño de Página:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="87"/>
        <source>Margins</source>
        <translation>Margen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="95"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="98"/>
        <source>bottom margin</source>
        <translation>Margen Inferior</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="111"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="114"/>
        <source>top margin</source>
        <translation>Margen superior</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="174"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="177"/>
        <source>left margin</source>
        <translation>Margen izquierdo</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="206"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="209"/>
        <source>right margin</source>
        <translation>Margen derecho</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="264"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="271"/>
        <source>Resolution</source>
        <translation>Resolución</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="285"/>
        <source>72</source>
        <translation>72</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="290"/>
        <source>96</source>
        <translation type="unfinished">96</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="295"/>
        <source>100</source>
        <translation type="unfinished">100</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="300"/>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="305"/>
        <source>200</source>
        <translation type="unfinished">200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="310"/>
        <source>240</source>
        <translation type="unfinished">240</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="315"/>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="320"/>
        <source>400</source>
        <translation type="unfinished">400</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="325"/>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="330"/>
        <source>760</source>
        <translation type="unfinished">760</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="335"/>
        <source>800</source>
        <translation type="unfinished">800</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="340"/>
        <source>1200</source>
        <translation>1200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="345"/>
        <source>2400</source>
        <translation type="unfinished">2400</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="399"/>
        <source>Points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="404"/>
        <source>Inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="409"/>
        <source>Millimeters</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="455"/>
        <source>Paper Source</source>
        <translation>Fuente de papel</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="313"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="332"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="348"/>
        <source> mm</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>Entre Contraseña</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>El archivo es protegido. Por favor, entre una Contraseña Abrir Documento</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation>Pegar en varias páginas</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="39"/>
        <source>Page Range</source>
        <translation>Rango de Página</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="45"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="71"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Muestra: : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="91"/>
        <source>All pages</source>
        <translation>Todas las Páginas</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="101"/>
        <source>Except current one</source>
        <translation>Excepto el actual</translation>
    </message>
</context>
<context>
    <name>PlaceInitialsDlg</name>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="14"/>
        <source>Place Initials</source>
        <translation>Colocar Iniciales</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="26"/>
        <source>How would like to create your initials?</source>
        <translation>¿Cómo le gustaría crear sus iniciales?</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="33"/>
        <source>Type my initials</source>
        <translation>Escriba mis iniciales</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="38"/>
        <source>Draw my initials</source>
        <translation>Dibujar mis iniciales</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="43"/>
        <source>Select signature image</source>
        <translation>Seleccione imagen de la firma</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="90"/>
        <source>Enter your initials:</source>
        <translation>Ingrese sus iniciales</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="97"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="241"/>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="245"/>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="128"/>
        <source>Font Family</source>
        <translation>Familia Fuente</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="167"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="197"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="353"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="234"/>
        <source>Change Initials Style</source>
        <translation>Cambiar Estilo de Iniciales</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="261"/>
        <source>Custom</source>
        <translation>Personal</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="275"/>
        <source>Review Initials:</source>
        <translation>Revisar Iniciales:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="315"/>
        <source>Draw Initials:</source>
        <translation>Dibujar Iniciales:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="386"/>
        <source>Width</source>
        <translation>Ancho</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="425"/>
        <source>Browse and select an image of your signature</source>
        <translation>Navega y selecciona una imagen de tu firma</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="445"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="67"/>
        <source>Clear</source>
        <translation>Claro</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="95"/>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="179"/>
        <source>Open Image</source>
        <translation>Abrir Imagen</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="179"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Archivos de Imágenes (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="245"/>
        <source>of</source>
        <translation>de</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <location filename="../../src/docpage/texteditor/plaintextedit.cpp" line="225"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>Esta fuente no contiene estos caracteres.
Trate de elegir otra fuente.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>Print Preview</source>
        <translation type="vanished">Vista Previa Impresión</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="318"/>
        <source>Printer</source>
        <translation>Impresora</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="305"/>
        <source>Properties</source>
        <translation>Propiedades</translation>
    </message>
    <message>
        <source>72</source>
        <translation type="vanished">72</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="202"/>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="207"/>
        <source>Document and Annotations</source>
        <translation>Documento y Anotaciones</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="215"/>
        <source>Print:</source>
        <translation>Imprimir:</translation>
    </message>
    <message>
        <source>150</source>
        <translation type="vanished">150</translation>
    </message>
    <message>
        <source>300</source>
        <translation type="vanished">300</translation>
    </message>
    <message>
        <source>600</source>
        <translation type="vanished">600</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <source>1200</source>
        <translation type="vanished">1200</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="vanished">DPI</translation>
    </message>
    <message>
        <source>Print What:</source>
        <translation type="vanished">Que Imprimir:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">auto</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation type="obsolete">Suavizado</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="799"/>
        <source>Actual Size</source>
        <translation>Tamaño Actual</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="858"/>
        <location filename="../../src/printdialog/printdialog.ui" line="953"/>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="277"/>
        <source>Print as Grayscale</source>
        <translation>Imprimir Escala de Grises</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="590"/>
        <source>Multiple</source>
        <translation>Múltiplo</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="745"/>
        <source>Aspect Ratio</source>
        <translation>Relación Aspecto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="792"/>
        <location filename="../../src/printdialog/printdialog.ui" line="986"/>
        <source>Scale</source>
        <translation>Escala</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="845"/>
        <source>Fit Page</source>
        <translation>Ajustar a Página</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="872"/>
        <source>Overlay</source>
        <translation>Cubierta</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1007"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1178"/>
        <source>Points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1012"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1183"/>
        <source>Inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1017"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1188"/>
        <source>Millimeters</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="973"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1109"/>
        <source>Pages per sheet:</source>
        <translation>Páginas por hoja:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1116"/>
        <source>x</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1124"/>
        <source>Horizontal</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1129"/>
        <source>Horizontal Reversed</source>
        <translation>Horizontal al Revés</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1134"/>
        <source>Vertical</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1139"/>
        <source>Vertical Reversed</source>
        <translation>Vertical al Revés</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1163"/>
        <source>Additional spacing:</source>
        <translation>Espaciado adicional:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1170"/>
        <source>pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1042"/>
        <source>Center pages in cells</source>
        <translation>Centrarr páginas en celdas</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="806"/>
        <source>Shrink to printable area</source>
        <translation>Reducir al área imprimible</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="753"/>
        <source>Ignore aspect ratio</source>
        <translation>Ignore Relación Aspecto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="758"/>
        <source>Keep aspect ratio</source>
        <translation>Conserve Relación Aspecto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="763"/>
        <source>Keep aspect ratio by expanding</source>
        <translation>Conserve relación aspecto expandiendo</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="565"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="543"/>
        <source>Poster</source>
        <translation>Póster</translation>
    </message>
    <message>
        <source>Booklet</source>
        <translation type="vanished">Folleto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="244"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="246"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="496"/>
        <source>Orientation</source>
        <translation>Orientación</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="674"/>
        <source>Portrait</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="679"/>
        <source>Landscape</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="435"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="402"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="obsolete">Páginas Impares y Pares</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="415"/>
        <source>Even pages</source>
        <translation>Págs. Pares</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="420"/>
        <source>Odd pages</source>
        <translation>Págs. Impares</translation>
    </message>
    <message>
        <source>Print as Image</source>
        <translation type="vanished">Imprimir como imagen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="455"/>
        <source>Subset</source>
        <translation>Subconjunto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="410"/>
        <source>All pages in range</source>
        <translation>Todas las páginas del rango</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="340"/>
        <source>Duplex Printing</source>
        <translation>Impresion a doble cara</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="87"/>
        <location filename="../../src/printdialog/printdialog.ui" line="348"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="358"/>
        <source>Long side</source>
        <translation>Lado largo</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="353"/>
        <location filename="../../src/printdialog/printdialog.ui" line="669"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="826"/>
        <location filename="../../src/printdialog/printdialog.ui" line="879"/>
        <source>%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="363"/>
        <source>Short side</source>
        <translation>Lado corto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="462"/>
        <source>Current view</source>
        <translation>Vista de Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="67"/>
        <source>Saved Settings</source>
        <translation>Configuración guardada</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="73"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="98"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="148"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="158"/>
        <source>of:</source>
        <translation>de:</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="vanished">Resolución</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="393"/>
        <source>Page Range</source>
        <translation>Rango Página</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas las Páginas</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Páginas desde</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="445"/>
        <source>Current Page</source>
        <translation>Actual página</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">hasta:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="625"/>
        <source>Number of copies</source>
        <translation>Número de copias</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="652"/>
        <source>Collate</source>
        <translation>Comparar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="286"/>
        <source>Page Setup</source>
        <translation>Configurar Página</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="290"/>
        <source>System Properties</source>
        <translation>Propiedades del Sistema</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1122"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1501"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1512"/>
        <source>of </source>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1365"/>
        <source>Save Settings</source>
        <translation>Guardar ajustes</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1365"/>
        <source>Save current settings as:</source>
        <translation>Guarde la configuración actual como:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1375"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Este nombre de configuración ya existe. ¿Desea sustituir la configuración anterior?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1412"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>¿Está seguro de que desea eliminar la configuración </translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1412"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
</context>
<context>
    <name>PrintingMode</name>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="149"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="176"/>
        <source>There was an error printing the document</source>
        <translation>Hubo un error imprimiendo el documento</translation>
    </message>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="151"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="178"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="18"/>
        <source>Attachment</source>
        <translation>Adjunto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="23"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="23"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="23"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="23"/>
        <source>Location</source>
        <translation>Lugar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="38"/>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="39"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Guardar Como...</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Abrir</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="111"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="574"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Page </source>
        <translation type="vanished">Página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="115"/>
        <source>Attachment Tab</source>
        <translation>Pestaña Adjunto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="500"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="16"/>
        <source>Add Bookmark</source>
        <translation>Agrega Marcador</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation type="vanished">Borra Marcador</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="17"/>
        <source>Delete Bookmark(s)</source>
        <translation>Borra Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="18"/>
        <source>Bookmark Properties</source>
        <translation>Propiedades Marcador</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="19"/>
        <source>Set Destination</source>
        <translation>Fijar Destino</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="175"/>
        <source>untitled</source>
        <translation>sin título</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="vanished">El portapaeles no contiene datos</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="41"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="45"/>
        <source>Close All</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="49"/>
        <source>Close All Other Tabs</source>
        <translation>Cerrar Todas las Otras Pestañas</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="53"/>
        <source>Close All Tabs to the Right</source>
        <translation>Cerrar Todas las Pestañas a la Derecha</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="1181"/>
        <location filename="../../src/document/qdoctab.cpp" line="1204"/>
        <source>The clipboard doesn&apos;t contain any data</source>
        <translation>El portapaeles no contiene datos</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Guardar</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Guardar Como...</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="65"/>
        <source>Move to New Window</source>
        <translation>Mover a una nueva ventana</translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation>Entregar mensajes</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation>A:</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation>Sujeto</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="9"/>
        <source>Send</source>
        <translation>Enviar</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="obsolete">Conexión HTTPS solicitada pero apoyo SSL no compilado en</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Error desconocido</translation>
    </message>
    <message>
        <source>Request aborted</source>
        <translation type="obsolete">Solicitud abortada</translation>
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation type="obsolete">No hay ningún servidor configurado para conectarse a</translation>
    </message>
    <message>
        <source>Wrong content length</source>
        <translation type="obsolete">Longitud de contenido incorrecto</translation>
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation type="obsolete">Servidor cerró la conexión de forma inesperada</translation>
    </message>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation type="obsolete">Conexión rechazada (o el tiempo de espera)</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation type="obsolete">Anfitrión %1 no encontrado</translation>
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation type="obsolete">Falló solicitud HTTP</translation>
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation type="obsolete">Encabezado de respuesta HTTP no válida</translation>
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation type="obsolete">Método de autenticación desconocido</translation>
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation type="obsolete">Se requiere autenticación proxy</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation type="obsolete">Autenticación requerida</translation>
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation type="obsolete">HTTP no válida cuerpo fragmentado</translation>
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation type="obsolete">Error al escribir respuesta a dispositivo</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <source>Zoom In</source>
        <translation type="vanished">Acercamiento</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="vanished">Alejamiento</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="104"/>
        <source>Zoom to Selection</source>
        <translation>Zoom a la selección</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Ajustar a Página</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="112"/>
        <source>Clear Selections</source>
        <translation>Borrar selecciones</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/app_config.cpp" line="8"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation>No está permitido utilizar este</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="12"/>
        <source>The unregistered version will insert a watermark</source>
        <translation>La versión no registrada insertará una marca de agua</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="17"/>
        <source>Open with</source>
        <translation>Abrir con</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="24"/>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="32"/>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="40"/>
        <source>Build</source>
        <translation>Incorporado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="24"/>
        <location filename="../../src/app_config.cpp" line="36"/>
        <source>32 bit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="32"/>
        <location filename="../../src/app_config.cpp" line="40"/>
        <source>64 bit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="67"/>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="72"/>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="77"/>
        <source>Brightness</source>
        <translation>Brillo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="82"/>
        <source>Contrast</source>
        <translation>Contraste</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="87"/>
        <source>Gamma</source>
        <translation>Gama</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="92"/>
        <source>Approved</source>
        <translation>Aprobado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="97"/>
        <source>Confidential</source>
        <translation>Confidencial</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="102"/>
        <source>Received</source>
        <translation>Recibido</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="107"/>
        <source>Reviewed</source>
        <translation>Repasar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="112"/>
        <source>Revised</source>
        <translation>Revisado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="117"/>
        <source>Completed</source>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="122"/>
        <source>Draft</source>
        <translation>Borrador</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="127"/>
        <source>Emergency</source>
        <translation>Emergencia</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="132"/>
        <source>Expired</source>
        <translation>Caducado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="137"/>
        <source>Final</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="142"/>
        <source>Verified</source>
        <translation>Verificado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="147"/>
        <source>Void</source>
        <translation>Nulo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="152"/>
        <source>Accepted</source>
        <translation>Aceptado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="157"/>
        <source>Initial</source>
        <translation>Inicial</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="162"/>
        <source>Rejected</source>
        <translation>Rechazado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="167"/>
        <source>SignHere</source>
        <translation>Firmar aquí</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="172"/>
        <source>Witness</source>
        <translation>Testigo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="177"/>
        <source>Dynamic</source>
        <translation>Dinámica</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="182"/>
        <source>Standard</source>
        <translation>Estándar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="187"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="200"/>
        <source>Icon</source>
        <translation>ícono</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="205"/>
        <source>Info</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="210"/>
        <source>Press Help button to get more info.</source>
        <translation>Presione el botуn Ayuda para obtener mбs info.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="215"/>
        <source>Error.</source>
        <translation>Error.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="220"/>
        <source>Object</source>
        <translation>Objeto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="225"/>
        <location filename="../../src/app_config.cpp" line="705"/>
        <source>Objects</source>
        <translation>Objetos</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="230"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="235"/>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="240"/>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="245"/>
        <source>Shading</source>
        <translation>Sombreado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="250"/>
        <source>All Objects</source>
        <translation>Todos los objetos</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="255"/>
        <location filename="../../src/app_config.cpp" line="660"/>
        <source>Forms</source>
        <translation>Formas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="260"/>
        <source>Comments</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="265"/>
        <source>Container</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="270"/>
        <source>Sticky Note</source>
        <translation>Nota Adhesiva</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="275"/>
        <source>Highlight</source>
        <translation>Resaltado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="280"/>
        <source>Underline</source>
        <translation>Subrayado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="285"/>
        <source>StrikeOut</source>
        <translation>Tachar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="290"/>
        <source>Reply</source>
        <translation>Respuesta</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="405"/>
        <source>Typewriter</source>
        <translation>Maquina de escribir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="410"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="415"/>
        <source>Separator</source>
        <translation>Separador</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="420"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="425"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="430"/>
        <source>Save As...</source>
        <translation>Guardar Como...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="435"/>
        <source>Toolbars</source>
        <translation>Barras de Herramientas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="440"/>
        <source>Email delivery</source>
        <translation>Entregar mensajes</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="445"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="450"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="455"/>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="460"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="465"/>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="470"/>
        <source>Delete Object(s)</source>
        <translation>Eliminar Objeto(s)</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="475"/>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="480"/>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="485"/>
        <source>Align Left</source>
        <translation>Alinear a Izquierda</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="490"/>
        <source>Align Right</source>
        <translation>Alinear a Derecha</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="495"/>
        <source>Align Top</source>
        <translation>Alinear Arriba</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="500"/>
        <source>Align Bottom</source>
        <translation>Alinear Abajo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="505"/>
        <source>Align Center Horizontal</source>
        <translation>Alinear al centro horizontal</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="510"/>
        <source>Align Center Vertical</source>
        <translation>Alinear al centro vertical</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="515"/>
        <source>Send To Back</source>
        <translation>Enviar al Fondo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="520"/>
        <source>Send Backward</source>
        <translation>Enviar Atrás</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="525"/>
        <source>Bring Forward</source>
        <translation>Adelantar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="530"/>
        <source>Bring To Front</source>
        <translation>Traer al Frente</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="535"/>
        <source>Grid</source>
        <translation>Cuadrícula</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="540"/>
        <source>Snap To Grid</source>
        <translation>Encajar a la cuadricula</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="545"/>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="550"/>
        <source>Previous View</source>
        <translation>Vista Anterior</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="555"/>
        <source>Next View</source>
        <translation>Siguiente Vista</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="560"/>
        <source>Previous Page</source>
        <translation>Página Anterior</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="565"/>
        <source>Next Page</source>
        <translation>Página Siguiente</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="570"/>
        <source>Zoom Out</source>
        <translation>Alejamiento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="575"/>
        <source>Actual Size</source>
        <translation>Tamaño Actual</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="580"/>
        <source>Zoom In</source>
        <translation>Acercamiento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="585"/>
        <source>Fit Page</source>
        <translation>Ajustar a Página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="590"/>
        <source>Fit Width</source>
        <translation>Ajustar al Ancho</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="595"/>
        <source>Facing Pages</source>
        <translation>Páginas Enfrentadas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="600"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Rotar 90 grados a la Izquierda</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="605"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Rotar 90 grados a la Derecha</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="610"/>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="615"/>
        <source>Edit Document</source>
        <translation>Editar Documento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="620"/>
        <source>Edit Text</source>
        <translation>Editar Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="625"/>
        <source>Edit Images</source>
        <translation>Editar Imágenes</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="630"/>
        <source>Edit Vector Images</source>
        <translation>Editar Imágenes de Vector</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="635"/>
        <source>Edit Forms</source>
        <translation>Editar Formularios</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="640"/>
        <source>Edit Tools</source>
        <translation>Herramientas Edición</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="645"/>
        <source>Hand Tool</source>
        <translation>Herramienta Mano</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="650"/>
        <source>Select Text</source>
        <translation>Seleccionar Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="655"/>
        <source>Take Snapshot</source>
        <translation>Tomar una Instantánea</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="665"/>
        <source>Insert Link</source>
        <translation>Insertar Vínculo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="670"/>
        <source>Button</source>
        <translation>Botón</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="675"/>
        <source>Check Box</source>
        <translation>Caja de Verificación</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="680"/>
        <source>Combo Box</source>
        <translation>Cuadro combinado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="685"/>
        <source>Text Field</source>
        <translation>Caja de Edición</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="690"/>
        <source>List Box</source>
        <translation>Caja de Lista</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="695"/>
        <source>Radio Button</source>
        <translation>Botón Circular</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="700"/>
        <source>Signature</source>
        <translation>Firma</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="710"/>
        <source>Insert Formatted Text</source>
        <translation>Insertar Texto Formateado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="715"/>
        <source>Insert Text</source>
        <translation>Insertar Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="720"/>
        <source>Insert Image</source>
        <translation>Insertar Imagen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="725"/>
        <source>Line</source>
        <translation>Línea</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="730"/>
        <source>Rectangle</source>
        <translation>Rectángulo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="735"/>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="740"/>
        <source>Pencil</source>
        <translation>Lápiz</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="745"/>
        <source>Attach a File as a Comment</source>
        <translation>Adjuntar un archivo como comentario</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="750"/>
        <source>Redaction</source>
        <translation>Redacción</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="755"/>
        <source>Mark for Redaction</source>
        <translation>Marca para Redacción</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="760"/>
        <source>Search And Redact</source>
        <translation>Busca y Redacta</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="765"/>
        <source>Apply Redaction</source>
        <translation>Aplicar Redacciones</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="770"/>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="775"/>
        <source>Insert Blank Pages</source>
        <translation>Inserta Página en Blanco</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="780"/>
        <source>Delete Pages</source>
        <translation>Eliminar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="785"/>
        <source>Crop Pages</source>
        <translation>Recortar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="790"/>
        <source>Page layout</source>
        <translation>Diseño de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="795"/>
        <source>Rotate Pages</source>
        <translation>Rotar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="800"/>
        <source>Extract Pages...</source>
        <translation>Extraer Páginas...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="805"/>
        <source>Insert Pages...</source>
        <translation>Insertar Páginas...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="810"/>
        <source>Document Actions</source>
        <translation>Acciones de Documento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="815"/>
        <source>Document JavaScript</source>
        <translation>JavaScript Documento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="820"/>
        <source>Page Properties</source>
        <translation>Propiedades de la página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="825"/>
        <source>OCR</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="830"/>
        <source>Header and Footer</source>
        <translation>Encabezados/Pies de página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="835"/>
        <source>Watermark</source>
        <translation>Marcas de agua</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="840"/>
        <source>Background</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="850"/>
        <source>Page Counter</source>
        <translation>Contador de Página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="855"/>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="860"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="875"/>
        <source>Highlight Text</source>
        <translation>Resaltar Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="880"/>
        <source>Draw Comment Tools</source>
        <translation>Herramientas de Dibujar Comentario</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="885"/>
        <source>Measurement Tools</source>
        <translation>Herramientas de Medida</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="905"/>
        <source>Continuous Page</source>
        <translation>Página Continua</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="910"/>
        <source>Single Page</source>
        <translation>Página Individual</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="845"/>
        <location filename="../../src/app_config.cpp" line="865"/>
        <source>Zoom</source>
        <translation>Acercamiento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="870"/>
        <source>Find</source>
        <translation>Encontrar</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Comentario</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="890"/>
        <source>Stamp</source>
        <translation>Clonar sello</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="895"/>
        <source>Comment View</source>
        <translation>Vista de Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="900"/>
        <source>Place Initials</source>
        <translation>Colocar Iniciales</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="295"/>
        <source>Text Box</source>
        <translation>Cuadro de Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="300"/>
        <source>Formatted Text</source>
        <translation>Texto Formateado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="305"/>
        <source>Issued by:</source>
        <translation>Emitido por:</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="310"/>
        <source>Expires</source>
        <translation>Expira</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="315"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="320"/>
        <source>Cancelled</source>
        <translation>Cancelado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="325"/>
        <source>Confirmed</source>
        <translation>Confirmado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="330"/>
        <source>Not Confirmed</source>
        <translation>No Confirmado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="335"/>
        <source>Open Object Inspector</source>
        <translation>Abrir Inspector de Objetos</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="340"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="345"/>
        <source>Review History</source>
        <translation>Revisar Historial</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="350"/>
        <source>Make Current Properties Default</source>
        <translation>Hacer Propiedades Actuales Predeterminadas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="355"/>
        <source>Error Loading Image!</source>
        <translation>ERROR Cargar Imagen !</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="360"/>
        <source>Incorrect date/time format. Please, insert date/time to match format: </source>
        <translation>Formato fecha/hora incorrecta. Por favor, inserte fecha/hora para coincidir formato:</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="365"/>
        <source>You have exceeded the number of available activations.</source>
        <translation>Ha excedido el nъmero de activaciones disponibles.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="370"/>
        <source>Please, deactivate your license on another PC.</source>
        <translation>Por favor, desactive su licencia en otra PC.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="375"/>
        <source>Your license doesn&apos;t allow to use this version. Please, renew your license.</source>
        <translation>Su licencia no permite usar esta versión. Por favor, renueve su licencia.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="380"/>
        <source>Your license is expired. Please, renew your license.</source>
        <translation>Su licencia expiró. Por favor, renueve su licencia.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="385"/>
        <source>Impossible to verify your license! Check your internet connection and press Verify Now</source>
        <translation>¡Imposible verificar su licencia! Verifique su conexión a internet y presione Verificar Ya</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="390"/>
        <source>Print using Windows API</source>
        <translation>Imprimir  usando Windows API</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="395"/>
        <source>Do not show this message again</source>
        <translation>No muestre este mensaje de nuevo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="400"/>
        <source>If OpenSSL is not installed, encryption and signature functionality will be unavailable.</source>
        <translation>Si OpenSSL no está instalado, el encriptado y la funcionabilidad de la firma no estarán disponibles.</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="23"/>
        <source>Mouse Enter</source>
        <translation>Enter Ratón</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Mouse Exit</source>
        <translation>Salir Ratón</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Mouse Down</source>
        <translation>Ratón Abajo</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Mouse Up</source>
        <translation>Ratón Arriba</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>On Receive Focus</source>
        <translation>Al Recibir Foco</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>On Lose Focus</source>
        <translation>Al Perder Foco</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>Page Open</source>
        <translation>Página Abierta</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>Page Close</source>
        <translation>Página Cerrada</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Page Visible</source>
        <translation>Página Visible</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Page Invisible</source>
        <translation>Página Invisible</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Open Page</source>
        <translation>Abrir Página</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Close Page</source>
        <translation>Cerrar Página</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>KeyStroke</source>
        <translation>Guión</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Validate</source>
        <translation>Validar</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Calculate</source>
        <translation>Calcular</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="55"/>
        <source>Close Document</source>
        <translation>Cerrar Documento</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="57"/>
        <source>Save Document</source>
        <translation>Guardar Documento</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="59"/>
        <source>Document Saved</source>
        <translation>Documento Guardado</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="61"/>
        <source>Print Document</source>
        <translation>Imprimir Documento</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="63"/>
        <source>Document Printed</source>
        <translation>Documento Impreso</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="78"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <source>Goto a Page View</source>
        <translation>Ir a Vista Página</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Open/execute a File</source>
        <translation>Abrir/ejecutar Archivo</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="88"/>
        <source>Thread</source>
        <translation>Hilo</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Open a web link</source>
        <translation>Abrir vínculo web</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Sound</source>
        <translation>Sonar</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Movie</source>
        <translation>Película</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Show/Hide fields</source>
        <translation>Muestra/Oculta campos</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="100"/>
        <source>Submit Form</source>
        <translation>Remitir una forma</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="102"/>
        <source>Reset Form</source>
        <translation>Restaurar Formulario</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Import Data</source>
        <translation>Importar Datos</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="106"/>
        <source>Run a JavaScript</source>
        <translation>Ejecutar un JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="110"/>
        <source>Rendition</source>
        <translation>Interpretación</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="114"/>
        <source>Goto 3D View</source>
        <translation>Ir A Vista 3D</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="53"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="56"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="53"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="56"/>
        <source>FDF Files (*.fdf)</source>
        <translation>Archivos FDF (*.fdf)</translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="28"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="3363"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="721"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="723"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="725"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="727"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="737"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="739"/>
        <source>of</source>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="733"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="735"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="737"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="739"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2901"/>
        <source>Error!</source>
        <translation>Error!</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3367"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3372"/>
        <source> mm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3418"/>
        <source>PDF document action attempts to submit form data to another location. Proceed?</source>
        <translation>La acción del DOCUMENTO PDF trata de enviar los datos de la forma a otro lugar. ¿Procedo?</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3452"/>
        <source>There was a problem with your form submission.</source>
        <translation>Hubo un problema con el envío del formulario.</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3454"/>
        <source>Your form was successfully submitted!</source>
        <translation>Su formulario fue enviado correctamente!</translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="37"/>
        <source>Open Document</source>
        <translation>Abrir documento</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="42"/>
        <source>Blank PDF</source>
        <translation>En blanco</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="47"/>
        <source>From Files</source>
        <translation>Desde archivo</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="53"/>
        <source>Empty recent files list</source>
        <translation>Vaciar lista archivos recientes</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="58"/>
        <source>From Scanner</source>
        <translation>Desde escáner</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="65"/>
        <source>Settings</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="71"/>
        <source>User Guide</source>
        <translation>Guía del usuario</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="81"/>
        <source>Register...</source>
        <translation>Registro...</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="87"/>
        <source>Buy Online</source>
        <translation>Compre EnLínea</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="369"/>
        <source>Create New Document</source>
        <translation>Crear nuevo documento</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="373"/>
        <source>Pinned Files</source>
        <translation>Archivos Anclados</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="391"/>
        <source>Recent Files</source>
        <translation>Archivos Recientes</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="884"/>
        <source>You have reached the limit of 10 pinned files.</source>
        <translation>Usted ha llegado al límite de 10 archivos anclados.</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="146"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="151"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Agrandar Página Miniaturas</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="154"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Reducir Página Miniaturas</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="vanished">Propiedades de la página</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="vanished">Eliminar Páginas</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">Rotar 90 grados a la Derecha</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">Rotar 90 grados a la Izquierda</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="189"/>
        <source>Bookmarks</source>
        <translation>Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="201"/>
        <source>Attachment</source>
        <translation>Adjunto</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="211"/>
        <source>Search</source>
        <translation>Busca</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="215"/>
        <source>Object TreeView</source>
        <translation>Objeto VistaÁrbol</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="232"/>
        <source>Signatures</source>
        <translation>Firmas</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="247"/>
        <source>Object Inspector</source>
        <translation>Inspector de Objetos</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="512"/>
        <source>Layers</source>
        <translation>Capas</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="631"/>
        <source>This document contains interactive form fields</source>
        <translation>Este documento contiene campos de forma interactivos</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="632"/>
        <source>Highlight Fields</source>
        <translation>Campos Resaltados</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="641"/>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation>Este documento está protegido. Usted no tiene permisos para editar este documento</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="642"/>
        <source>Change</source>
        <translation>Cambiar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="691"/>
        <source>Registration</source>
        <translation>Registro</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage_print.cpp" line="642"/>
        <location filename="../../src/docpage/qtabpage_print.cpp" line="670"/>
        <source>There was an error printing the document</source>
        <translation>Hubo un error imprimiendo el documento</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage_print.cpp" line="644"/>
        <location filename="../../src/docpage/qtabpage_print.cpp" line="672"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1418"/>
        <source>Error loading font: </source>
        <translation>Error al cargar fuente:</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1448"/>
        <source>Error!</source>
        <translation>Error!</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="vanished">Insertar Páginas en Blanco</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3159"/>
        <source>Do you want to open?</source>
        <translation>¿Quieres abrir?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4069"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>¿Seguro que desea establecer el destino del marcador seleccionado a la ubicación actual?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4072"/>
        <source>Set current zoom</source>
        <translation>Establecer el zoom actual</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4159"/>
        <source>untitled</source>
        <translation>sin título</translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="8"/>
        <source>Millimeters (mm)</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="9"/>
        <source>Inches (in)</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="10"/>
        <source>Points (pt)</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="11"/>
        <source>Pica (P̸)</source>
        <translation>Pica (P̸)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="12"/>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="13"/>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="35"/>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="39"/>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="43"/>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="47"/>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="51"/>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="55"/>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="136"/>
        <source>More...</source>
        <translation>Más...</translation>
    </message>
    <message>
        <source>User color %1</source>
        <translation type="obsolete">Usar color %1</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="325"/>
        <source>User Color 99</source>
        <translation>Usar color 99</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="339"/>
        <source>Black</source>
        <translation>Negro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="340"/>
        <source>White</source>
        <translation>Blanco</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="341"/>
        <source>Red</source>
        <translation>Rojo</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="342"/>
        <source>Dark red</source>
        <translation>Rojo Oscuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="343"/>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="344"/>
        <source>Dark green</source>
        <translation>Verde Oscuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="345"/>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="346"/>
        <source>Dark blue</source>
        <translation>Azul Oscuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="347"/>
        <source>Cyan</source>
        <translation>Cyan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="348"/>
        <source>Dark cyan</source>
        <translation>Dark cyan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="349"/>
        <source>Magenta</source>
        <translation>Magenta</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="350"/>
        <source>Dark magenta</source>
        <translation>Dark magenta</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="351"/>
        <source>Yellow</source>
        <translation>Amarillo</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="352"/>
        <source>Dark yellow</source>
        <translation>Amarillo Oscuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="353"/>
        <source>Gray</source>
        <translation>Gris</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="354"/>
        <source>Dark gray</source>
        <translation>Gris Oscuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="355"/>
        <source>Light gray</source>
        <translation>Gris Claro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="357"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
</context>
<context>
    <name>RedactionCodesDlg</name>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="14"/>
        <source>Redaction Code Editor</source>
        <translation>Editor Código de Redacción</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="30"/>
        <source>Code Sets</source>
        <translation>Conjuntos de Códigos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="49"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="150"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="56"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="157"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="76"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="180"/>
        <source>Rename</source>
        <translation>Rebautizar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="101"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="108"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="134"/>
        <source>Code Entries</source>
        <translation>Entradas de Código</translation>
    </message>
</context>
<context>
    <name>RedactionDlg</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulario</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="169"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="41"/>
        <source>Redacted Area Fill Color</source>
        <translation>Color Completo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="48"/>
        <source>Use Overlay Text</source>
        <translation>Use texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="73"/>
        <source>Code Sets</source>
        <translation>Conjuntos de Códigos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="80"/>
        <source>Code Entries:</source>
        <translation>Entradas de Código:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="113"/>
        <source>Edit Codes</source>
        <translation>Editar Códigos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="64"/>
        <source>Redaction Code</source>
        <translation>Código de Redacción</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="123"/>
        <source>Auto-size text</source>
        <translation>Texto de tamaño automático</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="130"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="137"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="149"/>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="198"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="57"/>
        <source>Repeat Overlay Text</source>
        <translation>Repita el texto de superposición</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>Información de Registro</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">Ok</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>Después de que su pedido ha sido completado,
Automáticamente
recibira su código de registro por correo electrónico.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation>Compre EnLínea</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="341"/>
        <source>Registration Code</source>
        <translation>Código de Registro</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="361"/>
        <source>Activate</source>
        <translation>Activar</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation>Activación Fuera Línea</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="212"/>
        <source>Registered version</source>
        <translation>Versión Registrada</translation>
    </message>
    <message>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="vanished">Si desea registrar dicha licencia en otro PC
haga click en &quot;Desactivar&quot;.

Luego regístrelo donde usted lo necesita.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="199"/>
        <source>Deactivate</source>
        <translation>Desactivar</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="219"/>
        <source>If you want to register that license on another PC click the &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Si desea registrar dicha licencia en otro PC
haga click en &quot;Desactivar&quot;.

Luego regístrelo donde usted lo necesita.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="256"/>
        <source>Purchased On:</source>
        <translation>Comprado en:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="263"/>
        <source>Maintenance Plan Expires:</source>
        <translation>Plan de Mantenimiento Expira:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="381"/>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="402"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Por favor envíe la clave de ID y el código de Registro a: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Una vez que reciba su código ingréselo en el campo &amp;quot;Código de activación&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="351"/>
        <source>Activation Code</source>
        <translation>Código Activación</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="388"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="24"/>
        <source>Thanks for registration.</source>
        <translation>Gracias por registrarse.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="25"/>
        <source>License is deactivated.</source>
        <translation>La Licencia estб desactivada</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="30"/>
        <source>License is expired!</source>
        <translation>¡La licencia expiró!</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="48"/>
        <source>Please, renew your license</source>
        <translation>Por favor, renueve su licencia</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="324"/>
        <location filename="../../src/regdialog.cpp" line="474"/>
        <source>Incorrect registration code.</source>
        <translation>Código de registro incorrecto.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="519"/>
        <source>Renew</source>
        <translation>Renovar</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="548"/>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact support@code-industry.net</source>
        <translation>¡Falló la deactivación!
Verifique la conexión a internet.
Si el error se repite, contacte a support@code-industry.net</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="353"/>
        <location filename="../../src/regdialog.cpp" line="576"/>
        <source>Activation failed! Check internet connection.</source>
        <translation>¡La activación falló! Verifique la conexión a internet.</translation>
    </message>
    <message>
        <source>You have exceeded the number of available activations.</source>
        <translation type="vanished">Ha excedido el nъmero de activaciones disponibles.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="27"/>
        <source>Too many activations!</source>
        <translation>Muchas activaciones!</translation>
    </message>
    <message>
        <source>Many activations!</source>
        <translation type="vanished">Muchas activaciones!</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation>Rotar</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="20"/>
        <source>Page Range</source>
        <translation>Rango Página</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="52"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="62"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Muestra: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="72"/>
        <source>Current Page</source>
        <translation>Actual Página</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="83"/>
        <source>Even and Odd pages</source>
        <translation>Páginas Impares y Pares</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="88"/>
        <source>Even pages</source>
        <translation>Págs. Pares</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="93"/>
        <source>Odd pages</source>
        <translation>Págs. Impares</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="101"/>
        <source>All Pages</source>
        <translation>Todas las Páginas</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Páginas desde</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">hasta:</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="111"/>
        <source>Direction</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="118"/>
        <source>Clockwise 90 degrees</source>
        <translation>90 grados derecha</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="123"/>
        <source>180 degrees</source>
        <translation>180 grados</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="128"/>
        <source>Counterclockwise 90 degrees</source>
        <translation>90 grados izquierda</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>Exportar a Imagen</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="318"/>
        <source>File Name</source>
        <translation>Nombre Archivo</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="327"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="250"/>
        <source>Page Range</source>
        <translation>Rango Páginas</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="262"/>
        <source>All Pages</source>
        <translation>Todas las Páginas</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="278"/>
        <source>Pages from</source>
        <translation>Págs. desde</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="295"/>
        <source>to:</source>
        <translation>hasta:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="61"/>
        <location filename="../../src/SaveImageDialog.ui" line="130"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="26"/>
        <source>BMP</source>
        <translation>BMP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="33"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="71"/>
        <source>TIFF</source>
        <translation>TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="40"/>
        <source>JPEG Quality</source>
        <translation>Calidad JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="110"/>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="115"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>CCITT FAX 3</source>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="125"/>
        <source>CCITT FAX 4</source>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="47"/>
        <source>TIFF Compression</source>
        <translation>Compresión TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="54"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="138"/>
        <source>MultiPage</source>
        <translation>MultiPáginas</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="154"/>
        <source>Width</source>
        <translation>Ancho</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="183"/>
        <source>Height</source>
        <translation>Alto</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="379"/>
        <source>Export:</source>
        <translation>Exportar:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="387"/>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="392"/>
        <source>Document and Annotations</source>
        <translation>Documento y Anotaciones</translation>
    </message>
    <message>
        <source>72</source>
        <translation type="obsolete">72</translation>
    </message>
    <message>
        <source>96</source>
        <translation type="obsolete">96</translation>
    </message>
    <message>
        <source>120</source>
        <translation type="obsolete">120</translation>
    </message>
    <message>
        <source>150</source>
        <translation type="obsolete">150</translation>
    </message>
    <message>
        <source>200</source>
        <translation type="obsolete">200</translation>
    </message>
    <message>
        <source>240</source>
        <translation type="obsolete">240</translation>
    </message>
    <message>
        <source>300</source>
        <translation type="obsolete">300</translation>
    </message>
    <message>
        <source>400</source>
        <translation type="obsolete">400</translation>
    </message>
    <message>
        <source>500</source>
        <translation type="obsolete">500</translation>
    </message>
    <message>
        <source>600</source>
        <translation type="obsolete">600</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="337"/>
        <source>Antialiasing</source>
        <translation>Suavizado</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="13"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="14"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="77"/>
        <source>Can&apos;t save to the file:</source>
        <translation>No puede guardar el archivo:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="77"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
El archivo puede ser de sólo lectura o usado por otra aplicación.</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="444"/>
        <source>Save As TIFF Image</source>
        <translation>Guardar Como Imagen TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="444"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>Archivos TIFF (*.tif *.tiff)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="463"/>
        <source>Save As Image</source>
        <translation>Guarde Como Imagen</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="463"/>
        <source>All Files (*)</source>
        <translation>Todos los Archivos (*.*)</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation>Guarda Optimizado Como...</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="323"/>
        <source>Remove unused elements</source>
        <translation>Quitar elementos sin usar</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="313"/>
        <source>Flatten form fields</source>
        <translation>Aplanar campos de la forma</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="166"/>
        <source>Color and Grayscale Images</source>
        <translation>Color y escala de grises Imágenes</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="57"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="178"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="211"/>
        <source>Compression</source>
        <translation>Compresión</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="110"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="231"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="236"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="244"/>
        <source>Lossless</source>
        <translation>Sin pérdida</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="264"/>
        <source>JPEG Quality</source>
        <translation>Calidad JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="333"/>
        <source>Merge all layers</source>
        <translation>Fusionar todas las capas</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="45"/>
        <source>Black and White Images</source>
        <translation>Imágenes Blanco y Negro</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="115"/>
        <source>CCITT Group 4</source>
        <translation>CCITT Grupo 4</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="120"/>
        <source>JBIG2</source>
        <translation>JBIG2</translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation>Escaneado...</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="12"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="12"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="10"/>
        <source>Scan</source>
        <translation>Digitalizar</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="37"/>
        <source>Settings</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="62"/>
        <source>Single Page</source>
        <translation>Página Sencilla</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="67"/>
        <source>All Pages From Feeder</source>
        <translation>Todas las Páginas del Alimentador</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="101"/>
        <source>Scan:</source>
        <translation>Escanear:</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="143"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="84"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="74"/>
        <source>Output</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="152"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="93"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="83"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="158"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="99"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="89"/>
        <source>Before current page</source>
        <translation>Antes de página actual</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="168"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="109"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="99"/>
        <source>After last page</source>
        <translation>Después de Última Página</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="175"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="116"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="106"/>
        <source>After current page</source>
        <translation>Después de página actual</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="185"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="126"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="116"/>
        <source>Before first page</source>
        <translation>Antes de Primera Página</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="220"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="161"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="141"/>
        <source>Append to Current Document </source>
        <translation>Insertar en el documento actual</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="210"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="151"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="148"/>
        <source>Create New Document</source>
        <translation>Crear nuevo documento</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="49"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="20"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="36"/>
        <source>Input</source>
        <translation>Entrada</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="132"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="42"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="64"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="81"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="35"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="48"/>
        <source>Scanner</source>
        <translation>Escáner</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="121"/>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="233"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="174"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="164"/>
        <source>Browse</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="263"/>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="302"/>
        <source>Preview</source>
        <translation>Vista Previa</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="322"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="219"/>
        <source>Looking for devices. Please wait.</source>
        <translation>Buscando dispositivos. Por favor espera.</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="48"/>
        <source>Mode</source>
        <translation>Modo</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="58"/>
        <source>Resolution</source>
        <translation>Resolución</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="68"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="265"/>
        <source>Flatbed</source>
        <translation>Tapa plana</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="267"/>
        <source>Positive Transparency</source>
        <translation>Transparencia Positiva</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="269"/>
        <source>Negative Transparency</source>
        <translation>Transparencia Negativa</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="271"/>
        <source>Document Feeder</source>
        <translation>Alimentador de Documentos</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="55"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="41"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="33"/>
        <source>untitled</source>
        <translation>intitulado</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="123"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="344"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="293"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="324"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="164"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="201"/>
        <source>Save As PDF</source>
        <translation>Guarde Como PDF</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="125"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="346"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="295"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="326"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="166"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="203"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Archivos PDF (*.pdf)</translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation>Escanear más páginas</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation>Escaneado completo</translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="14"/>
        <source>Preview</source>
        <translation>Vista Previa</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="30"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="33"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="36"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="39"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Rotar 90 grados a la Derecha</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="59"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="62"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="65"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="68"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Rotar 90 grados a la Izquierda</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="115"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="196"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="62"/>
        <source>0 result</source>
        <translation>0 resultados</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="69"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="126"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="175"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="225"/>
        <source>Check All</source>
        <translation>Verificar todo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="105"/>
        <source>Mark Checked Results for Redaction</source>
        <translation>Marque Resultados Verificados para Redacción</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="11"/>
        <source>Case Sensitive</source>
        <translation>Distingue Mayúsculas y Minúsculas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="15"/>
        <source>Include Comments</source>
        <translation>Incluye Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Whole Words Only</source>
        <translation>Solo Palabras Completas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="84"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="94"/>
        <source> result</source>
        <translation> resultado</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="96"/>
        <source> result(s)</source>
        <translation> resultado(s)</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="98"/>
        <source> results</source>
        <translation> resultados</translation>
    </message>
    <message>
        <source>Search and Redact</source>
        <translation type="vanished">Buscar y Redactar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="221"/>
        <source>Uncheck All</source>
        <translation>Desmarcar todo</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="118"/>
        <source>Case Sensitive</source>
        <translation>Distingue Mayúsculas y Minúsculas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="119"/>
        <source>Include Comments</source>
        <translation>Incluye Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="120"/>
        <source>Whole Words Only</source>
        <translation>Solo Palabras Completas</translation>
    </message>
</context>
<context>
    <name>SecurityCertificateDialog</name>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="14"/>
        <source>Certificate Security</source>
        <translation>Seguridad Certificado</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="51"/>
        <source>Recipient</source>
        <translation>Recipiente</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="64"/>
        <source>Permissions</source>
        <translation>Permisos</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="82"/>
        <source>Content copying for accessibility</source>
        <translation>Copiar contenido para accesibilidad</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="98"/>
        <source>Modifying document</source>
        <translation>Modificando documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="114"/>
        <source>Commenting</source>
        <translation>Comentando</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="130"/>
        <source>Printing the document</source>
        <translation>Imprimiendo el documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="146"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Administrar Páginas y marcadores</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="162"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Complete campos de forma o de firmas existentes</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="178"/>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimir una alta resolución de versión del documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="194"/>
        <source>Extract the content of the document</source>
        <translation>Extraer el contenido del documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="210"/>
        <source>Encryption</source>
        <translation>Encriptar</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="216"/>
        <source>128 bit AES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="226"/>
        <source>256 bit AES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="272"/>
        <source>Recipients</source>
        <translation>Recipientes</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="278"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="24"/>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="26"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="33"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="33"/>
        <source>Email</source>
        <translation>Correo</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Security PDF</source>
        <translation type="vanished">Seguridad PDF</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="14"/>
        <source>Password Security</source>
        <translation>Contraseña de Seguridad</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation>Se requiere una contraseña para abrir el documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation>Contraseña Abrir Documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="71"/>
        <location filename="../../src/security/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation>Confirme Contraseña</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation>Permisos</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation>Comentando</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation>Modificando documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation>Copiando contenido para accesibilidad</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation>Imprimiendo el documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation>Extraer el contenido del documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimir versión de alta resolución del documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Complete campos de la forma o firmas existentes</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation>Permisos Contraseña</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="233"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Administra Páginas y Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="275"/>
        <source>Encryption</source>
        <translation>Encriptar</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="288"/>
        <source>40 bit RC4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="293"/>
        <source>128 bit RC4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="298"/>
        <source>128 bit AES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="303"/>
        <source>256 bit AES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="96"/>
        <source>Document Open password does not match.</source>
        <translation>Contraseña Abrir Documento no coincide.</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="108"/>
        <source>Document Permission password does not match.</source>
        <translation>Contraseña Permiso Documento no coincide.</translation>
    </message>
</context>
<context>
    <name>SetLinkDlg</name>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="14"/>
        <source>Set Destination</source>
        <translation>Fijar Destino</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="20"/>
        <source>Use the scrollbars, mouse and zoom tools to select the target view, then press Set Link to create the Link destination</source>
        <translation>Use las barras de desplazamiento, el mouse y las herramientas de zoom para seleccionar la vista de destino, luego presione Establecer Vínculo para crear el destino del Vínculo</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="46"/>
        <source>Set Link</source>
        <translation>Fijar Vínculo</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="53"/>
        <source>Custom</source>
        <translation>Personal</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="60"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="80"/>
        <source>Set current zoom</source>
        <translation>Establecer el zoom actual</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation>Propiedades de Firma</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="46"/>
        <source>Signature is VALID</source>
        <translation>Firma es VÁLIDA</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation>Firmado por:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="366"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="403"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="449"/>
        <source>Reason:</source>
        <translation>Razón:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="373"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="456"/>
        <source>Date:</source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation>Lugar:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation>Resumen Validación</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Firmante de Información de contacto:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="301"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="328"/>
        <source>Custom</source>
        <translation>Personal</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="344"/>
        <source>Show Image</source>
        <translation>Muestra Imagen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="373"/>
        <source>Stretch Image</source>
        <translation>Estirar Imagen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="436"/>
        <source>Saved Settings</source>
        <translation>Configuración guardada</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="455"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="469"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="477"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="366"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="292"/>
        <source>Show Text</source>
        <translation>Muestra Texto</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="35"/>
        <source>Info</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="237"/>
        <source>Sign As</source>
        <translation>Firme Como</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="247"/>
        <source>Text For Signing</source>
        <translation>Texto para Firmar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="260"/>
        <source>Location</source>
        <translation>Lugar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="267"/>
        <source>Reason</source>
        <translation>Razón</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="487"/>
        <source>Lock document after signing</source>
        <translation>Bloquee documento después de firmar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="392"/>
        <source>Signature Preview</source>
        <translation>Vista Previa Firma</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="64"/>
        <source>I have reviewed this document</source>
        <translation>Yo he revisado este documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="65"/>
        <source>I am approving this document</source>
        <translation>Yo estoy aprobando este documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="66"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Doy fe de la exactitud e integridad de este documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="67"/>
        <source>I agree to specified parts of this document</source>
        <translation>Estoy de acuerdo con las partes especificadas de este documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="43"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>El documento ha sido alterado o dañado desde la aplicación de las firmas.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="44"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>El documento no ha sido alterado desde la aplicación de las firmas.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="45"/>
        <source>Signature is INVALID</source>
        <translation>La Firma es INVÁLIDA</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="47"/>
        <source>Signature validity is UNKNOWN</source>
        <translation>DESCONOCIDA validez de la firma</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="48"/>
        <source>This certificate is not trusted</source>
        <translation>Este certificado no es de confianza</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="49"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>Se desconoce identidades firmantes, ya que no ha sido incluido en su lista de identidades de confianza y ninguno de sus certificados de padres es identidades de confianza.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="50"/>
        <source>Error during signature verification.</source>
        <translation>Error durante la verificación de firma.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="51"/>
        <source>Details: The signature byte range is invalid</source>
        <translation>Detalles: El rango de byte de firma es inválido</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="52"/>
        <source>I am the author of this document</source>
        <translation>Yo soy el autor de este documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="124"/>
        <source>Open Image</source>
        <translation>Abrir Imagen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="124"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Archivos Imagen (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="247"/>
        <source>Browse</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="248"/>
        <source>Certificate Manager</source>
        <translation>Administrador de Certificados</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="350"/>
        <source>Digitally signed by </source>
        <translation>Firmado por:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="358"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="441"/>
        <source>Email</source>
        <translation>Correo</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="435"/>
        <source>Digitally signed by</source>
        <translation>Firmado por</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="552"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="552"/>
        <source>All Supported Files (*.p12 *.pfx);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Todos los Archivos Compatibles (*.p12 *.pfx);; Archivos p12 (*.p12);;Archivos pfx (*.pfx);; Todos los Archivos (*)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="800"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <source>p12 Files (*.p12)</source>
        <translation type="vanished">Archivos p12 (*.p12)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="728"/>
        <source>Save Settings</source>
        <translation>Guardar ajustes</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="728"/>
        <source>Save current settings as:</source>
        <translation>Guarde la configuración actual como:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="738"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Este nombre de configuración ya existe. ¿Desea sustituir la configuración anterior?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="800"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>¿Está seguro de que desea eliminar la configuración </translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="386"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Ocurrió un error durante la verificación de firma!</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="vanished">Buscar...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="559"/>
        <source>A password is required to open certificate:</source>
        <translation>Se requiere una contraeña para abrir certificado:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="217"/>
        <source>Sign</source>
        <translation>Firma</translation>
    </message>
</context>
<context>
    <name>SignatureFormTab</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulario</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.ui" line="88"/>
        <source>Signatures</source>
        <translation>Firmas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="221"/>
        <source>Unsigned Signature</source>
        <translation>Firma sin Firmar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="224"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="259"/>
        <source>Location</source>
        <translation>Lugar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="224"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="259"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="234"/>
        <source>Signed Signature</source>
        <translation>Firma Firmada</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="237"/>
        <source>Signed by:</source>
        <translation>Firmado por:</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="238"/>
        <source>Reason:</source>
        <translation>Razón:</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="271"/>
        <source>Click to view this version</source>
        <translation>Haga clic para ver esta versión.</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation>Expedidor</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation>Nombre Común (CN)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation>Organización (O)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation>Unidad Organizacional (OU)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation>Número Serie</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation>Algoritmo</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>Sujeto</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation>Correo</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation>Validez</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation>No Antes De</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation>No Después De</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>SHA-256</source>
        <translation></translation>
    </message>
    <message>
        <source>MD5</source>
        <translation type="vanished">MD5</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation>Agregar a Identidades Creíbles</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="285"/>
        <source>File Name</source>
        <translation>Nombre del Archivo</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="298"/>
        <source>Data</source>
        <translation>Datos</translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <location filename="../../src/stamps/StampDlg.ui" line="72"/>
        <source>Manage Stamps</source>
        <translation>Sellos personalizados</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="90"/>
        <source>Custom</source>
        <translation>Personal</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Ajustes</translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation>Sellos personalizados</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation>Vista Previa</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation>Clonar sello</translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation>Editar Sello</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation>Plantilla</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Formulario</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="74"/>
        <source>Reply</source>
        <translation>Respuesta</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="35"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
</context>
<context>
    <name>StickyNoteReply</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulario</translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <location filename="../../src/widgets/TextEditDlg.ui" line="14"/>
        <source>Text Editor</source>
        <translation>Editor de Texto</translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="29"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Familia de Fuentes&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambiar Familia de Fuentes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="35"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Color de fuente&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cambiar color de relleno&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolBarCommentsForm</name>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="81"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="84"/>
        <source>Highlight</source>
        <translation type="unfinished">Resaltado</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="119"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="122"/>
        <source>StrikeOut</source>
        <translation type="unfinished">Tachar</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="154"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="157"/>
        <source>Underline</source>
        <translation type="unfinished">Subrayado</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="189"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="192"/>
        <source>Copy</source>
        <translation type="unfinished">Copiar</translation>
    </message>
</context>
<context>
    <name>ToolBarSettings</name>
    <message>
        <source>New</source>
        <translation type="obsolete">Nuevo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Abrir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="502"/>
        <source>Zoom</source>
        <translation>Acercamiento</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">Encontrar</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Comentario</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="obsolete">Clonar sello</translation>
    </message>
    <message>
        <source>Comment View</source>
        <translation type="obsolete">Vista de Comentarios</translation>
    </message>
    <message>
        <source>Place Initials</source>
        <translation type="obsolete">Colocar Iniciales</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">Principal</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Editar</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Ver</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="obsolete">Objetos</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">Comentarios</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="480"/>
        <source>Open a PDF file</source>
        <translation>Abrir un archivo PDF</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="obsolete">Mostrar</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation type="obsolete">Maquina de escribir</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Nota Adhesiva</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Deshacer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Rehacer</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Cortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Pegar</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Archivo</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Guardar</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">Imprimir</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formas</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">Firma</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">Botón Circular</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">Caja de Lista</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">Caja de Edición</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">Cuadro combinado</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">Caja de Verificación</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="obsolete">Botón</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">Lápiz</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">Elipse</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rectángulo</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Línea</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Insertar Texto</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation type="obsolete">Redacción</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation type="obsolete">Marca para Redacción</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="obsolete">Herramientas</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">Editar Texto</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">Herramienta Mano</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation type="obsolete">Vista Anterior</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation type="obsolete">Siguiente Vista</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Alejamiento</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Acercamiento</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">Ajustar a Página</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="obsolete">Ajustar al Ancho</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation>Agregar marcas de agua</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Config. guardadas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="503"/>
        <source>Saved Settings</source>
        <translation>Configuración guardada</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="522"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="536"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="544"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="311"/>
        <source>Source</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="317"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="347"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="354"/>
        <source>Scale</source>
        <translation>Escala</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="364"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="350"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="356"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="451"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="578"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="584"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="615"/>
        <source>Total pages :</source>
        <translation>Total de Páginas. :</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="371"/>
        <source>Page Number</source>
        <translation>Número Página</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="388"/>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="394"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="414"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="421"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="437"/>
        <source>Font Family</source>
        <translation>Familia Fuente</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="473"/>
        <source>Browse</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Appearance</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="26"/>
        <source>Rotation</source>
        <translation>Rotación</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="44"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="64"/>
        <source>Opacity</source>
        <translation>Opacidad</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="120"/>
        <source>Scale relative to target page</source>
        <translation>Escala relativa a la página de destino</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="161"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="167"/>
        <source>Vertical distance</source>
        <translation>Distancia Vertical</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="181"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="240"/>
        <source>from</source>
        <translation>desde</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="195"/>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="200"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="256"/>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="205"/>
        <source>Bottom</source>
        <translation>Desde abajo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="226"/>
        <source>Horizontal distance</source>
        <translation>Distancia horizontal</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="251"/>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="261"/>
        <source>Right</source>
        <translation>Derecho</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="269"/>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="277"/>
        <source>Points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="282"/>
        <source>Inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="287"/>
        <source>Millimeters</source>
        <translation>milímetros</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">puntos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pulgadas</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">milímetros</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="138"/>
        <source>Page Range Options...</source>
        <translation>Opciones de rango de páginas...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="150"/>
        <source>Save Settings</source>
        <translation>Guardar ajustes</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="150"/>
        <source>Save current settings as:</source>
        <translation>Guarde la configuración actual como:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="160"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Este nombre de configuración ya existe. ¿Desea sustituir la configuración anterior?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="196"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>¿Está seguro de que desea eliminar la configuración </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="196"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="278"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="294"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="312"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="334"/>
        <source>Open File</source>
        <translation>Abrir Archivo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="334"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Todos los Archivos Compatibles (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="vanished">Archivos PDF (*.pdf *.PDF)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="360"/>
        <source>There was an error opening the document !</source>
        <translation>Hubo un error abriendo el documento !</translation>
    </message>
</context>
<context>
    <name>layerForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulario</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/layer/layerform.ui" line="27"/>
        <source>Layers</source>
        <translation>Capas</translation>
    </message>
</context>
</TS>

<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Registered version.</source>
        <translation>已注册版本。</translation>
    </message>
    <message>
        <source>Purchased On:</source>
        <translation>购买于：</translation>
    </message>
    <message>
        <source>Maintenance Plan Expires:</source>
        <translation>维护计划到期：</translation>
    </message>
    <message>
        <source>Registration Info</source>
        <translation>注册信息</translation>
    </message>
    <message>
        <source>License Agreement</source>
        <translation>许可协议</translation>
    </message>
    <message>
        <source>Not Registered version.</source>
        <translation>未注册版本。</translation>
    </message>
    <message>
        <source>Version Info</source>
        <translation>版本信息</translation>
    </message>
    <message>
        <source>Built with</source>
        <translation>由以下构建</translation>
    </message>
    <message>
        <source>Legal Notices</source>
        <translation>法律提示</translation>
    </message>
    <message>
        <source>This software uses, with permission, the following copyrighted software.</source>
        <translation>经许可，本软件使用下列受版权保护的软件。</translation>
    </message>
    <message>
        <source>Please, renew your license</source>
        <translation>请更新您的许可协议</translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <source>Document Actions</source>
        <translation>文档动作</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Java Script</source>
        <translation>Java Script</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Document Will Close</source>
        <translation>文档将被关闭</translation>
    </message>
    <message>
        <source>Document Will Save</source>
        <translation>文档将被保存</translation>
    </message>
    <message>
        <source>Document Did Save</source>
        <translation>文档已被保存</translation>
    </message>
    <message>
        <source>Document Will Print</source>
        <translation>文档将被打印</translation>
    </message>
    <message>
        <source>Document Did Print</source>
        <translation>文档已经打印</translation>
    </message>
</context>
<context>
    <name>AdvancedPrintDialog</name>
    <message>
        <source>Advanced Print Setup</source>
        <translation>高级打印设置</translation>
    </message>
    <message>
        <source>Print as Image</source>
        <translation>作为图像打印</translation>
    </message>
    <message>
        <source>Queue In Subset Pages</source>
        <translation>在子集页中排队</translation>
    </message>
    <message>
        <source>Сompatible with Laser Engraving</source>
        <translation>兼容激光雕刻</translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation>边框和颜色</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation>边框色</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation>填充色</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation>实线</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation>虚线</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="obsolete">线条粗细</translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation>线宽</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation>线型</translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <source>Appearance Options</source>
        <translation>外观选项</translation>
    </message>
    <message>
        <source>Show when printing</source>
        <translation>打印时显示</translation>
    </message>
    <message>
        <source>Show when displaying on screen</source>
        <translation>屏幕阅读时显示</translation>
    </message>
    <message>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation>不论打印到多大的页面，均保持水印文字的位置和大小不变</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <source>File</source>
        <translation type="obsolete">文件</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">创建PDF</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">打开</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="obsolete">最近打开的文件</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">帮助</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation type="obsolete">注册...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="obsolete">检查更新</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">帮助...</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">设置</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>源</translation>
    </message>
    <message>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation>页数：</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>页码</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>比例</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>外观</translation>
    </message>
    <message>
        <source>Rotation</source>
        <translation>旋转</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <source>Scale relative to target page</source>
        <translation>相对于目标页面缩放</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Vertical distance</source>
        <translation>垂直距离</translation>
    </message>
    <message>
        <source>from</source>
        <translation>从</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>顶端</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>中间</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>底部</translation>
    </message>
    <message>
        <source>Horizontal distance</source>
        <translation>水平距离</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>左侧</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>右侧</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>单位</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation>页面范围选项...</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation>保存设置</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation>将当前设置保存为：</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>同名文件已存在。确定要替换原有文件吗？</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation>确定删除此设置吗 </translation>
    </message>
    <message>
        <source> ?</source>
        <translation> ？</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation>打开文档时出错。文件已损坏，无法修复！</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>设置已保存</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>所有支持的文件(*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <source>Bookmark Properties</source>
        <translation>书签属性</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>风格</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation>原样</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>斜体</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>加粗</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation>粗斜体</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>添加一个动作</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation>鼠标向上</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>转到页面视图</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>打开文件/执行程序</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>打开网页链接</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>重置表单</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>显示/隐藏表单域</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>提交表单</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>运行JavaScript脚本</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>页码</translation>
    </message>
    <message>
        <source>Set current position</source>
        <translation>设置当前位置</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>外观</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>未命名</translation>
    </message>
    <message>
        <source>Do you want to set the current position?</source>
        <translation>确定要设置当前位置吗？</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
</context>
<context>
    <name>CertificateManagerDlg</name>
    <message>
        <source>Certificate Manager</source>
        <translation>证书管理器</translation>
    </message>
    <message>
        <source>Your Certificates</source>
        <translation>您的证书</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>导入</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Trusted System Certificates</source>
        <translation>可信系统证书</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>All Supported Files (*.p12 *.pfx *.cer *.crt *.pem);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>所有支持的文件 (*.p12 *.pfx *.cer *.crt *.pem);; p12 文件 (*.p12);; pfx 文件 (*.pfx);; 所有文件 (*)</translation>
    </message>
    <message>
        <source>A password is required to open certificate:</source>
        <translation>打开证书需要密码：</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation>错误！</translation>
    </message>
    <message>
        <source>pfx Files (*.pfx)</source>
        <translation>pfx 文件 (*.pfx)</translation>
    </message>
    <message>
        <source>crt Files (*.crt)</source>
        <translation>crt 文件 (*.crt)</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation>保存文件</translation>
    </message>
    <message>
        <source>Please, specify private key password:</source>
        <translation>请指定私钥密码：</translation>
    </message>
    <message>
        <source>Are you sure you want to delete certificate?</source>
        <translation>确定要删除证书吗？</translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <source>Create a new document from files</source>
        <translation>从此文件创建新文档</translation>
    </message>
    <message>
        <source>Add Files</source>
        <translation>添加文件</translation>
    </message>
    <message>
        <source>Add Folder</source>
        <translation>添加文件夹</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>向上</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>向下</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">保存</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>未命名</translation>
    </message>
    <message>
        <source>Total pages</source>
        <translation>页数</translation>
    </message>
    <message>
        <source>Save As PDF</source>
        <translation>另存为PDF</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF 文件 (*.pdf)</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">打开</translation>
    </message>
    <message>
        <source>Select directory</source>
        <translation>选择目录</translation>
    </message>
    <message>
        <source>Save failed</source>
        <translation>保存失败</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>不能保存到文件：</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
该文件可能只读，或者正被其他应用程序使用。</translation>
    </message>
    <message>
        <source>Output</source>
        <translation>输出</translation>
    </message>
    <message>
        <source>Append to Current Document </source>
        <translation>附加到当前文档 </translation>
    </message>
    <message>
        <source>Create New Document</source>
        <translation>创建新文档</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation>当前页之前</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>末页之后</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation>当前页之后</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>首页之前</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>所有支持的文件 (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation>导入书签</translation>
    </message>
    <message>
        <source>Insert Pages</source>
        <translation>插入页面</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>所有支持的文件 (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; 所有文件 (*)</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <source>The removed page(s) will never recovered, delete it anyway?</source>
        <translation type="obsolete">确定要删除这些页面吗？此操作不能撤销。</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation>删除页面</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>当前页面</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>选择页面，从</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>到：</translation>
    </message>
    <message>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>撤消操作无法恢复被删除的页面。</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>示例：1,6-8,12</translation>
    </message>
</context>
<context>
    <name>DialogFormFields</name>
    <message>
        <source>Button</source>
        <translation type="obsolete">按钮</translation>
    </message>
</context>
<context>
    <name>DialogNotes</name>
    <message>
        <source>Opacity</source>
        <translation type="vanished">透明度</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">文字</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="obsolete">外观</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="obsolete">颜色</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="obsolete">作者</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="obsolete">主题</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="obsolete">锁定</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">选项</translation>
    </message>
</context>
<context>
    <name>DialogRotatePage</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">页面范围</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">到：</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">选择页面，从</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">当前页面</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <source>Distance Tool</source>
        <translation>距离工具</translation>
    </message>
    <message>
        <source>Measurement</source>
        <translation>测量</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>距离：</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>角度：</translation>
    </message>
    <message>
        <source>Cursor Location</source>
        <translation>光标位置</translation>
    </message>
    <message>
        <source>X:</source>
        <translation>X：</translation>
    </message>
    <message>
        <source>Y:</source>
        <translation>Y：</translation>
    </message>
    <message>
        <source>Units and Markup Settings</source>
        <translation>单位和标记设置</translation>
    </message>
    <message>
        <source>Scale Ratio:</source>
        <translation>缩放比例：</translation>
    </message>
    <message>
        <source>pt</source>
        <translation>点</translation>
    </message>
    <message>
        <source>in</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>mm</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source>=</source>
        <translation>=</translation>
    </message>
    <message>
        <source>Annotation:</source>
        <translation>批注：</translation>
    </message>
    <message>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <source>Distance</source>
        <translation>距离</translation>
    </message>
    <message>
        <source>Perimeter</source>
        <translation>周长</translation>
    </message>
    <message>
        <source>Area</source>
        <translation>区域</translation>
    </message>
    <message>
        <source> sq</source>
        <translation> 平方</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <source>Icon Placement</source>
        <translation>图标放置</translation>
    </message>
    <message>
        <source>Fit to bounds</source>
        <translation>适合边界</translation>
    </message>
    <message>
        <source>When to scale:</source>
        <translation>当缩放到此时：</translation>
    </message>
    <message>
        <source>Proportionally</source>
        <translation>按比例</translation>
    </message>
    <message>
        <source>Non-Proportionally</source>
        <translation>不按比例</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>按钮</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>缩放：</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>总是</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>从不</translation>
    </message>
    <message>
        <source>Icon is too big</source>
        <translation>图标太大</translation>
    </message>
    <message>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation>使用此对话框可修改图标的缩放方式来适合按钮</translation>
    </message>
    <message>
        <source>Icon is too small</source>
        <translation>图标太小</translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <source>Page Number and Date Format</source>
        <translation>页码和日期格式</translation>
    </message>
    <message>
        <source>Date Format</source>
        <translation>日期格式</translation>
    </message>
    <message>
        <source>Page Number Format</source>
        <translation>页码格式</translation>
    </message>
    <message>
        <source>Start Page Number</source>
        <translation>起始页码</translation>
    </message>
    <message>
        <source>of</source>
        <translation>/</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页面</translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <source>Page Range Options</source>
        <translation>页面范围选项</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>示例：1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>所有页面</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation>奇偶页</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation>偶数页</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation>奇数页</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Edit text</source>
        <translation type="vanished">编辑文本</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">将图像保存到文件</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">对象属性...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">剪切</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">复制</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">删除</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">撤消</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>全选</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">粘贴</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">另存为...</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation>添加便签备注</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>删除线</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>下划线</translation>
    </message>
    <message>
        <source>Add Bookmark</source>
        <translation>添加书签</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>转到页面视图</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>打开网页链接</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>打开文件/执行程序</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>运行JavaScript脚本</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Set Status</source>
        <translation>设置状态</translation>
    </message>
    <message>
        <source>pt</source>
        <translation>点</translation>
    </message>
    <message>
        <source>The selected area has been copied</source>
        <translation>选定区域已复制</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation type="vanished">复制</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">剪切</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">粘贴</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>全选</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="vanished">编辑文本</translation>
    </message>
    <message>
        <source>Signature options</source>
        <translation>签名选项</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">撤消</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>打开图像</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation>适合页面</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation>将图像保存到文件</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">另存为...</translation>
    </message>
    <message>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>PNG 图片 (*.png);;BMP 图片 (*.bmp)</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation>PNG 图片 (*.png)</translation>
    </message>
    <message>
        <source>Edit Image</source>
        <translation>编辑图片</translation>
    </message>
    <message>
        <source>Edit Path Nodes</source>
        <translation>编辑路径节点</translation>
    </message>
    <message>
        <source>Edit the image and press Replace</source>
        <translation>编辑图片并按“替换”</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>替换</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Delete Node</source>
        <translation>删除节点</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>图片文件 (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; 所有文件 (*)</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>图片</translation>
    </message>
    <message>
        <source>Clear Signature</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Java script editor</source>
        <translation>Java script编辑器</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>显示</translation>
    </message>
    <message>
        <source>Select Fields</source>
        <translation>选择区域</translation>
    </message>
    <message>
        <source>Deselect All</source>
        <translation>全部不选</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>隐藏</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>全选</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <source>FDF</source>
        <translation>FDF</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <source>Method</source>
        <translation>方法</translation>
    </message>
    <message>
        <source>Show/Hide Fields</source>
        <translation>显示/隐藏表单域</translation>
    </message>
    <message>
        <source>Reset Form</source>
        <translation>重置表单</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">选项</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>本地文件</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Use anonymous</source>
        <translation>使用匿名</translation>
    </message>
    <message>
        <source>Need user name and password</source>
        <translation>需要用户名和密码</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>用户名</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>所有文件(*.*)</translation>
    </message>
    <message>
        <source>Select Field</source>
        <translation>选定区域</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>打开文件/执行程序</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation>输入一个文件：</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation>转到页面</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>页码</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation>缩放模式</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation>缩放(%)</translation>
    </message>
    <message>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source> px</source>
        <translation> 像素</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>打开网页链接</translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation>输入网址：</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>所有文件(*.*)</translation>
    </message>
    <message>
        <source>Named Action</source>
        <translation>已命名的动作</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>适合页面</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>适合宽度</translation>
    </message>
    <message>
        <source>Fit Height</source>
        <translation>适合高度</translation>
    </message>
    <message>
        <source>Fit Visible</source>
        <translation>适合可见区域</translation>
    </message>
    <message>
        <source> =  -1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <source>Extract pages as a single file</source>
        <translation>提取页面合并为单一文件</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Extract Pages</source>
        <translation>提取页面</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>当前页面</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">选择页面，从</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">到：</translation>
    </message>
    <message>
        <source>Save As PDF</source>
        <translation>另存为PDF</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF 文件 (*.pdf)</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>不能保存到文件：</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
此文件可能只读，或者正被其他应用程序使用。</translation>
    </message>
    <message>
        <source>Export Pages</source>
        <translation>导出页面</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>全部页面</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>示例：1,6-8,12</translation>
    </message>
    <message>
        <source>Export bookmarks</source>
        <translation>导出书签</translation>
    </message>
    <message>
        <source>Delete pages after extracting</source>
        <translation>提取后删除页面</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <source>Export to text</source>
        <translation>导出到文本</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>当前页面</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>全部页面</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>示例：1,6-8,12</translation>
    </message>
    <message>
        <source>Extract pages as a single file</source>
        <translation>提取页面合并为单一文件</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <source>txt files (*.txt)</source>
        <translation>文本文件 (*.txt)</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>不能保存到文件：</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
此文件可能只读，或者正被其他应用程序使用。</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <source>Document Properties</source>
        <translation>文档属性</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation>文档信息</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>主题</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>关键词</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>创建者</translation>
    </message>
    <message>
        <source>Producer</source>
        <translation>制作者</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>安全</translation>
    </message>
    <message>
        <source>Initial View</source>
        <translation>初始视图</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">图像</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Fonts used in this document</source>
        <translation>文档中用到的字体</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">文档保护</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">用户口令</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">所有者密码</translation>
    </message>
    <message>
        <source>Password Encryption</source>
        <translation>密码加密</translation>
    </message>
    <message>
        <source>No Encryption</source>
        <translation>无加密</translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation>打印文档</translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation>以高分辨率打印</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">提取文本和图形</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">深度提取文本和图形</translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation>修改文档</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">文档注释或表单域</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation>填写已有的表单或签名区域</translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation>管理页面和书签</translation>
    </message>
    <message>
        <source>Open to Page:</source>
        <translation>打开到页面：</translation>
    </message>
    <message>
        <source>of :</source>
        <translation>:</translation>
    </message>
    <message>
        <source>PDF Information</source>
        <translation>PDF信息</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation type="vanished">页面模式：</translation>
    </message>
    <message>
        <source>Page Only</source>
        <translation>仅页面</translation>
    </message>
    <message>
        <source>Bookmarks Panel</source>
        <translation>书签面板</translation>
    </message>
    <message>
        <source>Pages Panel</source>
        <translation>页面面板</translation>
    </message>
    <message>
        <source>Attachments Panel</source>
        <translation>附件面板</translation>
    </message>
    <message>
        <source>Layers Panel</source>
        <translation>图层面板</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>修改</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation>许可</translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation>提取文档内容</translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation>复制文档内容</translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation>批注</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>文档被保护。请输入许可密码：</translation>
    </message>
    <message>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>密码不正确。请输入所有者密码。</translation>
    </message>
    <message>
        <source>User Interface Options</source>
        <translation>用户界面选项</translation>
    </message>
    <message>
        <source>Hide tool bar</source>
        <translation>隐藏工具栏</translation>
    </message>
    <message>
        <source>Hide menu bar</source>
        <translation>隐藏菜单栏</translation>
    </message>
    <message>
        <source>Hide Window Controls</source>
        <translation>隐藏窗口控制器</translation>
    </message>
    <message>
        <source>Windows Options</source>
        <translation>窗口选项</translation>
    </message>
    <message>
        <source>Center window on screen</source>
        <translation>窗口居于屏幕中央</translation>
    </message>
    <message>
        <source>Display document title</source>
        <translation>显示文档标题</translation>
    </message>
    <message>
        <source>Open in Full Screen mode</source>
        <translation>以全屏模式打开</translation>
    </message>
    <message>
        <source>Layout and Destination</source>
        <translation>布局</translation>
    </message>
    <message>
        <source>Navigation Tab:</source>
        <translation>导航标签：</translation>
    </message>
    <message>
        <source>Page layout:</source>
        <translation>页面布局：</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation>单页</translation>
    </message>
    <message>
        <source>Single Page Continuous</source>
        <translation>连续单面</translation>
    </message>
    <message>
        <source>Two-Up (Facing)</source>
        <translation>双页（对开面）</translation>
    </message>
    <message>
        <source>Two-Up Continuous (Facing)</source>
        <translation>连续双页（对开面）</translation>
    </message>
    <message>
        <source>Two-Up (Cover Page)</source>
        <translation>双页（正反面）</translation>
    </message>
    <message>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation>连续双页（正反面）</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>实际大小</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>适合页面</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>适合宽度</translation>
    </message>
    <message>
        <source>Fit Height</source>
        <translation>适合高度</translation>
    </message>
    <message>
        <source>Fit Visible</source>
        <translation>适合可见区域</translation>
    </message>
    <message>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Document Open Actions</source>
        <translation>文档打开动作</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>添加动作</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>转到页面视图</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>打开文件/执行程序</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>打开网页链接</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>重置表单</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>显示/隐藏表单域</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>提交表单</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>运行JavaScript脚本</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Certificate Encryption</source>
        <translation>证书加密</translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>System</source>
        <translation type="obsolete">系统</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">外观</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">选项</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">动作</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">删除</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">线型</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">颜色</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">添加</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">锁定</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">名称</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">边框和颜色</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="vanished">工具提示</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">方向</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">线型</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="vanished">线条粗细</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="vanished">填充色</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">边框色</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">向上</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">向下</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">属性</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">文字</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">大小</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="obsolete">插入</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">编辑</translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <source>Header &amp; Footer</source>
        <translation>页眉与页脚</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>上边距</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>右边距</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>下边距</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>左边距</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">设置</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Right Footer Text</source>
        <translation>页脚文本居右</translation>
    </message>
    <message>
        <source>Center Header Text</source>
        <translation>页眉文本居中</translation>
    </message>
    <message>
        <source>Left Footer Text</source>
        <translation>页脚文本居左</translation>
    </message>
    <message>
        <source>Right Header Text</source>
        <translation>页眉文本居右</translation>
    </message>
    <message>
        <source>Center Footer Text</source>
        <translation>页眉文本居中</translation>
    </message>
    <message>
        <source>Left Header Text</source>
        <translation>页眉文本居左</translation>
    </message>
    <message>
        <source>Insert Date</source>
        <translation>插入日期</translation>
    </message>
    <message>
        <source>Insert Page Number</source>
        <translation>插入页码</translation>
    </message>
    <message>
        <source>Page number and date format</source>
        <translation>页码和日期格式</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation>页面范围选项...</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation>保存设置</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation>将当前设置保存为：</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>同名文件已存在。确定要替换原有文件吗？</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation>确定删除此设置吗 </translation>
    </message>
    <message>
        <source> ?</source>
        <translation> ？</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>单位</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>设置已保存</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>页边距</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">页面范围</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全部页面</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">选择页面，从</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">到：</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="obsolete">文件名</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">浏览</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">页面</translation>
    </message>
</context>
<context>
    <name>InitialsDlg</name>
    <message>
        <source>Form</source>
        <translation>表单</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <source>Install languages</source>
        <translation>安装语言</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>语言</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>安装</translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <source>JavaScript Console</source>
        <translation>JavaScript控制台</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <source>Stays On Top</source>
        <translation>总在顶层</translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <source>Document JavaScript</source>
        <translation>文档JavaScript</translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation>函数名称</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <source>Java Script Editor</source>
        <translation>Java script编辑器</translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation>函数名称</translation>
    </message>
    <message>
        <source>Java Script</source>
        <translation>Java Script脚本</translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translatorcomment>此文本是一个“未完成”快捷方式，展开方式为“Ctrl+A…”</translatorcomment>
        <translation>%1，...</translation>
    </message>
    <message>
        <source>Press shortcut</source>
        <translation>按快捷键</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <source>Keyboard shortcuts</source>
        <translation>键盘快捷键</translation>
    </message>
    <message>
        <source>Reset All</source>
        <translation>全部重置</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>快捷键</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>命令</translation>
    </message>
    <message>
        <source>Key sequence has potential conflicts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <source>System</source>
        <translation>系统</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>表单</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation>高亮颜色</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation>高亮必填字段</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation>请选择界面语言</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation>自动检查更新</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation>每周</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation>每月</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>从不</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source> ms</source>
        <translation> 毫秒</translation>
    </message>
    <message>
        <source>Smooth text and images</source>
        <translation>平滑文字和图片</translation>
    </message>
    <message>
        <source>Time before a move or resize starts:</source>
        <translation>开始移动或调整大小之前的时间：</translation>
    </message>
    <message>
        <source>Select item by hovering the mouse</source>
        <translation>鼠标悬停则选定</translation>
    </message>
    <message>
        <source>Built-in</source>
        <translation>内置</translation>
    </message>
    <message>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>程序重启后修改生效。</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabic</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgarian</translation>
    </message>
    <message>
        <source>Catalan</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <source>Chinese-Simplified</source>
        <translation>简体中文</translation>
    </message>
    <message>
        <source>Chinese-Traditional</source>
        <translation>Chinese-Traditional</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Czech</translation>
    </message>
    <message>
        <source>Danish</source>
        <translation>Danish</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Dutch</translation>
    </message>
    <message>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <source>Estonian</source>
        <translation>Estonian</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Finnish</translation>
    </message>
    <message>
        <source>French</source>
        <translation>French</translation>
    </message>
    <message>
        <source>Galician</source>
        <translation>Galician</translation>
    </message>
    <message>
        <source>German</source>
        <translation>German</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Greek</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation>Hebrew</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Hungarian</translation>
    </message>
    <message>
        <source>Irish</source>
        <translation>Irish</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italian</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation></translation>
    </message>
    <message>
        <source>Korean</source>
        <translation>Korean</translation>
    </message>
    <message>
        <source>Latvian</source>
        <translation>Latvian</translation>
    </message>
    <message>
        <source>Lithuanian</source>
        <translation>Lithuanian</translation>
    </message>
    <message>
        <source>Norwegian</source>
        <translation>Norwegian</translation>
    </message>
    <message>
        <source>Norwegian-Nynorsk</source>
        <translation>Norwegian-Nynorsk</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polish</translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation>Portuguese</translation>
    </message>
    <message>
        <source>Portuguese-Brazilian</source>
        <translation>Portuguese-Brazilian</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romanian</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russian</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbian</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovak</translation>
    </message>
    <message>
        <source>Slovenian</source>
        <translation>Slovenian</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Spanish</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Swedish</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation>Thai</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainian</translation>
    </message>
    <message>
        <source>Valencian</source>
        <translation>Valencian</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation>Vietnamese</translation>
    </message>
    <message>
        <source>Saving Documents</source>
        <translation>保存文档</translation>
    </message>
    <message>
        <source>Create backup file</source>
        <translation>创建备份文件</translation>
    </message>
    <message>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>为文档另存选择位置</translation>
    </message>
    <message>
        <source>Last used folder</source>
        <translation>上次使用的文件夹</translation>
    </message>
    <message>
        <source>Original documents folder</source>
        <translation>原所在文件夹</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">浏览</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation>默认字体</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation>Armenian</translation>
    </message>
    <message>
        <source>History</source>
        <translation>历史记录</translation>
    </message>
    <message>
        <source>Restore last session when application start</source>
        <translation>启动后打开上次的文档</translation>
    </message>
    <message>
        <source>Restore last view settings when reopening</source>
        <translation>重新打开时载入上次的视图</translation>
    </message>
    <message>
        <source>Enable JavaScript</source>
        <translation>启用JavaScript</translation>
    </message>
    <message>
        <source> Always hide document message bar </source>
        <translation> 总是隐藏文档信息栏 </translation>
    </message>
    <message>
        <source>Default Layout and Zoom</source>
        <translation>默认布局和缩放</translation>
    </message>
    <message>
        <source>Default page layout</source>
        <translation>默认页面布局</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation>单页</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation>对开</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>实际大小</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>适合页面</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>适合宽度</translation>
    </message>
    <message>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>Bitmap Images</source>
        <translation>位图</translation>
    </message>
    <message>
        <source>Vector Images</source>
        <translation>矢量图</translation>
    </message>
    <message>
        <source>Replace Document Colors</source>
        <translation>替换文档色</translation>
    </message>
    <message>
        <source>Page Background</source>
        <translation>页面背景</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>显示</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <source>Select directory</source>
        <translation>选择目录</translation>
    </message>
    <message>
        <source>Automatically change font when editing text</source>
        <translation>编辑文字时自动修改字体</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>分辨率</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <source>System PPI</source>
        <translation>系统PPI</translation>
    </message>
    <message>
        <source>Icons in menus</source>
        <translation>菜单图标</translation>
    </message>
    <message>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation>在同一窗口的新标签中打开文档（需要重启）</translation>
    </message>
    <message>
        <source>Enable scroll wheel zooming</source>
        <translation>启用鼠标滚轮缩放</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <source>Pop-up Opacity</source>
        <translation>弹窗不透明度</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation>便签备注</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>高亮</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>删除线</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>下划线</translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation>线宽</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>批注</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>外观</translation>
    </message>
    <message>
        <source>Check Mark</source>
        <translation>复选标记</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>圆圈</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>批注</translation>
    </message>
    <message>
        <source>Cross</source>
        <translation>十字</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">插入文字</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>键</translation>
    </message>
    <message>
        <source>New Paragraph</source>
        <translation>新建段落</translation>
    </message>
    <message>
        <source>Text Note</source>
        <translation>文字备注</translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation>段落</translation>
    </message>
    <message>
        <source>Right Arrow</source>
        <translation>向右箭头</translation>
    </message>
    <message>
        <source>Right Pointer</source>
        <translation>向右指针</translation>
    </message>
    <message>
        <source>Star</source>
        <translation>星形</translation>
    </message>
    <message>
        <source>Up Arrow</source>
        <translation>向上箭头</translation>
    </message>
    <message>
        <source>Up Left Arrow</source>
        <translation>左上箭头</translation>
    </message>
    <message>
        <source>Graph</source>
        <translation>图表</translation>
    </message>
    <message>
        <source>Paper Clip</source>
        <translation>回形针</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>附件</translation>
    </message>
    <message>
        <source>Tag</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <source>Show errors and  messages in console</source>
        <translation>在控制台显示错误和信息</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>链接</translation>
    </message>
    <message>
        <source>Edit Box</source>
        <translation>编辑框</translation>
    </message>
    <message>
        <source>Check box</source>
        <translation>复选框</translation>
    </message>
    <message>
        <source>Radio button</source>
        <translation>单选按钮</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation>组合框</translation>
    </message>
    <message>
        <source>List box</source>
        <translation>列表框</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>按钮</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>签名</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation>边框和颜色</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation>细</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>中</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation>粗</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation>边框色</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation>填充色</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation>实线</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation>虚线</translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation>斜角</translation>
    </message>
    <message>
        <source>Inset</source>
        <translation>插图</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation>下划线</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation>线型</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation>线条粗细</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation>高亮</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation>反转</translation>
    </message>
    <message>
        <source>OutLine</source>
        <translation>大纲</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>风格</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>选择</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation>钻石</translation>
    </message>
    <message>
        <source>Square</source>
        <translation>正方形</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>网格</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>单位</translation>
    </message>
    <message>
        <source>Width between lines</source>
        <translation>线间宽度</translation>
    </message>
    <message>
        <source>Height between lines</source>
        <translation>线间高度</translation>
    </message>
    <message>
        <source>Left offset</source>
        <translation>左偏移</translation>
    </message>
    <message>
        <source>Top offset</source>
        <translation>上偏移</translation>
    </message>
    <message>
        <source>Subdivision</source>
        <translation>细分</translation>
    </message>
    <message>
        <source>Measurements</source>
        <translation>测量</translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation>绘制</translation>
    </message>
    <message>
        <source>Selected text color</source>
        <translation>选定的文字颜色</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <source>Application Style</source>
        <translation>应用风格</translation>
    </message>
    <message>
        <source>Use default program</source>
        <translation>使用默认程序</translation>
    </message>
    <message>
        <source>evolution</source>
        <translation>Evolution</translation>
    </message>
    <message>
        <source>kmail</source>
        <translation>Kmail</translation>
    </message>
    <message>
        <source>thunderbird</source>
        <translation>Thunderbird</translation>
    </message>
    <message>
        <source>Use SMTP</source>
        <translation>使用SMTP</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Email address</source>
        <translation>电子邮件地址</translation>
    </message>
    <message>
        <source>Secure connections</source>
        <translation>安全连接</translation>
    </message>
    <message>
        <source>NONE</source>
        <translation>无</translation>
    </message>
    <message>
        <source>SSL</source>
        <translation>SSL</translation>
    </message>
    <message>
        <source>STARTTLS</source>
        <translation>STARTTLS</translation>
    </message>
    <message>
        <source>SMTP server</source>
        <translation>SMTP服务器</translation>
    </message>
    <message>
        <source>User</source>
        <translation>用户</translation>
    </message>
    <message>
        <source>SMTP port</source>
        <translation>SMTP端口</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <source>Default path to tesseract ocr data files</source>
        <translation>Tesseract OCR数据文件的默认路径</translation>
    </message>
    <message>
        <source>Additional tesseract ocr config file</source>
        <translation>添加Tesseract OCR配置文件</translation>
    </message>
    <message>
        <source>Install languages</source>
        <translation>安装语言</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
    <message>
        <source>pt</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>网络</translation>
    </message>
    <message>
        <source>Enable safe reading mode</source>
        <translation>启用安全阅读模式</translation>
    </message>
    <message>
        <source>Direct internet connection</source>
        <translation>直接连接互联网</translation>
    </message>
    <message>
        <source>Manual proxy configuration</source>
        <translation>手动代理配置</translation>
    </message>
    <message>
        <source>HTTP Proxy</source>
        <translation>HTTP代理</translation>
    </message>
    <message>
        <source>SOCKS 5 Proxy</source>
        <translation>SOCKS 5代理</translation>
    </message>
    <message>
        <source>Host</source>
        <translation>主机</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>身份验证</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>用户名</translation>
    </message>
    <message>
        <source>Icon set</source>
        <translation>图标集</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation>键盘</translation>
    </message>
    <message>
        <source>Show Start page</source>
        <translation>显示启动画面</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source>Load all objects separately</source>
        <translation>分别加载所有对象</translation>
    </message>
    <message>
        <source>Always show Object Inspector</source>
        <translation>始终显示对象检查器</translation>
    </message>
    <message>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation>禁止以全屏模式打开文件</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation>文本框</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>亮色</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>暗色</translation>
    </message>
    <message>
        <source>Exact match only</source>
        <translation>仅完全匹配</translation>
    </message>
    <message>
        <source>Certificates</source>
        <translation>证书</translation>
    </message>
    <message>
        <source>Save last editing Tool</source>
        <translation>保存之前的编辑工具</translation>
    </message>
    <message>
        <source>Default paths for system certificates</source>
        <translation>系统证书和默认路径</translation>
    </message>
    <message>
        <source>Certificate Manager</source>
        <translation>证书管理器</translation>
    </message>
    <message>
        <source>In Windows, all certificates are located in system storage.</source>
        <translation>在Windows中，所有证书位于系统存储中。</translation>
    </message>
    <message>
        <source>General</source>
        <translation>常规</translation>
    </message>
    <message>
        <source>Alternative method for PDF render</source>
        <translation>PDF渲染替代方法</translation>
    </message>
    <message>
        <source>Memory/Speed</source>
        <translation>内存/速度</translation>
    </message>
    <message>
        <source>Minimize memory usage</source>
        <translation>使用内存最少</translation>
    </message>
    <message>
        <source>Maximal render speed</source>
        <translation>渲染速度最快</translation>
    </message>
    <message>
        <source>System Theme</source>
        <translation>系统主题</translation>
    </message>
    <message>
        <source>Database for Certificate Manager</source>
        <translation>证书管理器数据库</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>密码:</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Path for DB:</source>
        <translation>数据库路径：</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation>修订</translation>
    </message>
    <message>
        <source>In macOS, all certificates are located in system storage.</source>
        <translation>在macOS中，所有证书位于系统存储中。</translation>
    </message>
    <message>
        <source>Farsi</source>
        <translation>Farsi</translation>
    </message>
    <message>
        <source>Allow opening same document in multiple tabs</source>
        <translation>允许在多个标签中打开同一文档</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <source>Add full path to filename in export file</source>
        <translation>导出文件时将完整路径添加到文件名</translation>
    </message>
    <message>
        <source>Recreate pdf forms when opening</source>
        <translation>打开时重建PDF表单</translation>
    </message>
    <message>
        <source>Light Theme</source>
        <translation>亮色主题</translation>
    </message>
    <message>
        <source>Dark Theme</source>
        <translation>暗色主题</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation>工具栏</translation>
    </message>
    <message>
        <source>Edit Text Elements as Blocks</source>
        <translation>以块对象编辑文本对象</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <source>Office Pro</source>
        <translation>Office Pro</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tooltip Display Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Quick actions on text selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDlg</name>
    <message>
        <source>System</source>
        <translation type="obsolete">系统</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">表单</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">语言</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation type="obsolete">高亮颜色</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation type="obsolete">高亮必填字段</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation type="obsolete">请选择界面语言</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation type="obsolete">自动检查更新</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="obsolete">每周</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="obsolete">每月</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">从不</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">设置</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">浏览</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">线型</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">删除</translation>
    </message>
    <message>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <source>New</source>
        <translation>新建PDF</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>另存为...</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>打印</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation>最近打开的文件</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>全选</translation>
    </message>
    <message>
        <source>First Page</source>
        <translation>首页</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <source>Last Page</source>
        <translation>末页</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>放大</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>缩小</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>实际大小</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation>工具栏</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>显示状态栏</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation>手形工具</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation>注册…</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="vanished">检查更新</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation type="vanished">导出</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation>放大页面预览</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation>缩小页面预览</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">插入页面...</translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">提取页面...</translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation>高亮所有区域</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>属性</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">页面范围</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全部页面</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">当前页面</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation type="obsolete">规则</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">斜体</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">加粗</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation type="obsolete">粗斜体</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="vanished">书签</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="vanished">插入</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>高亮</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>下划线</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>删除线</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="vanished">附件</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>Check box</source>
        <translation>复选框</translation>
    </message>
    <message>
        <source>Radio button</source>
        <translation>单选按钮</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>按钮</translation>
    </message>
    <message>
        <source>List box</source>
        <translation>列表框</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation>组合框</translation>
    </message>
    <message>
        <source>Edit Box</source>
        <translation>编辑框</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>文档</translation>
    </message>
    <message>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>退出前是否保存对 %s 的修改?</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">帮助...</translation>
    </message>
    <message>
        <source>Cannot open file :
</source>
        <translation>不能打开文件：
</translation>
    </message>
    <message>
        <source>View</source>
        <translation>视图</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation type="vanished">暂无可用更新.</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation>编辑文档</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>线条</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>批注</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation>添加便签备注</translation>
    </message>
    <message>
        <source>Add Sticky Notes</source>
        <translation type="obsolete">添加便签备注</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>图片</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation>打开文档时出错！</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation>页面格式</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">插入页面</translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">插入页面</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">删除页面</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">页面</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>撤消</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <source>Create a new blank PDF</source>
        <translation>新建空白PDF</translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <source>Send to Back</source>
        <translation>下移一层</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;下移一层&lt;/span&gt;&lt;/p&gt;&lt;p&gt;将选定对象下移一层。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <source>Alt+Del</source>
        <translation>Alt+Del</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>图像</translation>
    </message>
    <message>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <source>Home page</source>
        <translation>主页</translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation>选择文字</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>Open failed</source>
        <translation>打开失败</translation>
    </message>
    <message>
        <source>Empty recent files list</source>
        <translation>清空近期文件列表</translation>
    </message>
    <message>
        <source>Export completed</source>
        <translation>导出完成的文档</translation>
    </message>
    <message>
        <source>Save failed</source>
        <translation>保存失败</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>不能保存到文件：</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
此文件可能只读，或者正被其他应用程序使用。</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation type="obsolete">文档属性</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation>内容</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>查找</translation>
    </message>
    <message>
        <source>Find Next</source>
        <translation>查找下一处</translation>
    </message>
    <message>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>有新版本！
现在下载吗？</translation>
    </message>
    <message>
        <source>Close Without Saving</source>
        <translation>关闭而不保存</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation>旋转页面</translation>
    </message>
    <message>
        <source>Move Pages</source>
        <translation>移动页面</translation>
    </message>
    <message>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>编辑文本</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation type="obsolete">文档信息</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>对象检查器</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>未命名</translation>
    </message>
    <message>
        <source>Align Objects</source>
        <translation>对齐对象</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>线条</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation>左对齐</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation>右对齐</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation>上对齐</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation>下对齐</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>签名</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation>适合页面</translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation>签名验证期间发生错误！</translation>
    </message>
    <message>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>表单</translation>
    </message>
    <message>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <source>End</source>
        <translation>End</translation>
    </message>
    <message>
        <source>Reset Forms</source>
        <translation>重置表单</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>适合页面</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>适合宽度</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation>对开</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation>删除页面</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation>编辑表单</translation>
    </message>
    <message>
        <source>Bring to Front</source>
        <translation>上移一层</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;上移一层&lt;/span&gt;&lt;/p&gt;&lt;p&gt;将选定对象上移一层。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation>提取页面...</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation>插入页面...</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation>铅笔</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF 文件 (*.pdf)</translation>
    </message>
    <message>
        <source>Open a PDF file</source>
        <translation>打开PDF文件</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>PageUp</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>PageDown</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Delete键</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation>打开对象检查器</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation>裁剪页面</translation>
    </message>
    <message>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation type="vanished">上一个/下一个</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation type="vanished">编辑工具</translation>
    </message>
    <message>
        <source>Page :</source>
        <translation type="vanished">页面：</translation>
    </message>
    <message>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation>插入空白页面</translation>
    </message>
    <message>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Shift+L</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>顺时针旋转90度</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>逆时针旋转90度</translation>
    </message>
    <message>
        <source>FDF Files (*.fdf)</source>
        <translation>FDF 文件 (*.fdf)</translation>
    </message>
    <message>
        <source>Export Form Data...</source>
        <translation>导出表单数据...</translation>
    </message>
    <message>
        <source>Import Form Data...</source>
        <translation>导入表单数据...</translation>
    </message>
    <message>
        <source>Export Comments Data...</source>
        <translation>导出批注数据...</translation>
    </message>
    <message>
        <source>Import Comments Data...</source>
        <translation>导入批注数据...</translation>
    </message>
    <message>
        <source>Select text for copying and pasting</source>
        <translation>选定要复制和粘贴的文字</translation>
    </message>
    <message>
        <source>Save the document</source>
        <translation>保存文档</translation>
    </message>
    <message>
        <source>Save the document with a new name</source>
        <translation>以新名称保存文档</translation>
    </message>
    <message>
        <source>Print the document</source>
        <translation>打印文档</translation>
    </message>
    <message>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>选定、编辑文字、图片、批注、表单域...</translation>
    </message>
    <message>
        <source>Select text for editing</source>
        <translation>选定要编辑的文字</translation>
    </message>
    <message>
        <source>Delete the currently selected object(s)</source>
        <translation>删除当前选定对象</translation>
    </message>
    <message>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>剪切当前选定对象</translation>
    </message>
    <message>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>复制当前选定对象</translation>
    </message>
    <message>
        <source>Paste from the Clipboard</source>
        <translation>从剪切板粘贴</translation>
    </message>
    <message>
        <source>Undo the last action</source>
        <translation>撤销刚才的动作</translation>
    </message>
    <message>
        <source>Redo the previously undone action.</source>
        <translation>重做刚才取消的动作。</translation>
    </message>
    <message>
        <source>Send to Back selected object.</source>
        <translation>将选定对象下移一层。</translation>
    </message>
    <message>
        <source>Bring to Front selected object.</source>
        <translation>将选定对象上移一层。</translation>
    </message>
    <message>
        <source>Open window with document properties</source>
        <translation>打开带有文档属性的窗口</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;便签备注&lt;/span&gt;&lt;/p&gt;&lt;p&gt;点击此页面可在此处添加一个备注&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Click the page to add a note at that position</source>
        <translation>点击页面在此处添加备注</translation>
    </message>
    <message>
        <source>Insert new text to current page</source>
        <translation>在当前页面添加新的文本</translation>
    </message>
    <message>
        <source>Insert new image to current page</source>
        <translation>在当前页面添加新的图片</translation>
    </message>
    <message>
        <source>Insert new link to current page</source>
        <translation>在当前页面添加新的链接</translation>
    </message>
    <message>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Shift+N</translation>
    </message>
    <message>
        <source>Ctrl+Shift+E</source>
        <translation>Ctrl+Shift+E</translation>
    </message>
    <message>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Shift+I</translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation>优化并为存为...</translation>
    </message>
    <message>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <source>Font type</source>
        <translation>字体类型</translation>
    </message>
    <message>
        <source>Font Embedded</source>
        <translation>嵌入字体</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>宽度</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>高度</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>过滤器</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <source>Shading</source>
        <translation>阴影</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation>对象</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation>已选定</translation>
    </message>
    <message>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <source>Can&apos;t find :</source>
        <translation>不能找到：</translation>
    </message>
    <message>
        <source>Font Not Embedded</source>
        <translation>字体未嵌入</translation>
    </message>
    <message>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <source>Document JavaScript</source>
        <translation>文档JavaScript</translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation>文档动作</translation>
    </message>
    <message>
        <source>Replace Document Colors</source>
        <translation>替换文档色彩</translation>
    </message>
    <message>
        <source>Paste to Multiple Pages</source>
        <translation>粘贴到多个页面</translation>
    </message>
    <message>
        <source>Ctrl+Shift+V</source>
        <translation>Ctrl+Shift+V</translation>
    </message>
    <message>
        <source>Your installed version of Qt</source>
        <translation>已安装的Qt版本</translation>
    </message>
    <message>
        <source>JavaScript Console</source>
        <translation>JavaScript控制台</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation>页面属性</translation>
    </message>
    <message>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Ctrl+Shift+H</source>
        <translation>Ctrl+Shift+H</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation>Master PDF Editor在文档中不能找到任何页眉和页脚。</translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation>想要从文档中删除页眉和页脚吗？</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>水印</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <source>Measurements</source>
        <translation>测量</translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation>绘制</translation>
    </message>
    <message>
        <source>Menu Bar</source>
        <translation>菜单栏</translation>
    </message>
    <message>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <source>Show Cover Page During Facing</source>
        <translation>对开时显示封面</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation>全屏</translation>
    </message>
    <message>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <source>Ctrl+Shift+W</source>
        <translation>Ctrl+Shift+W</translation>
    </message>
    <message>
        <source>Ctrl+Shift+B</source>
        <translation>Ctrl+Shift+B</translation>
    </message>
    <message>
        <source>Align Center Horizontal</source>
        <translation>水平居中对齐</translation>
    </message>
    <message>
        <source>Align Center Vertical</source>
        <translation>垂直居中对齐</translation>
    </message>
    <message>
        <source>Find Previous</source>
        <translation>查找上一处</translation>
    </message>
    <message>
        <source>Shift+F3</source>
        <translation>Shift+F3</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;电子邮件传送&lt;/span&gt;&lt;/p&gt;&lt;p&gt;通过电子邮件发送文件&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>网格</translation>
    </message>
    <message>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <source>Snap to Grid</source>
        <translation>对齐到网格</translation>
    </message>
    <message>
        <source>Ctrl+Shift+U</source>
        <translation>Ctrl+Shift+U</translation>
    </message>
    <message>
        <source>Distance Tool</source>
        <translation>距离工具</translation>
    </message>
    <message>
        <source>Perimeter Tool</source>
        <translation>周长工具</translation>
    </message>
    <message>
        <source>Area Tool</source>
        <translation>面积工具</translation>
    </message>
    <message>
        <source>Arrow</source>
        <translation>箭头</translation>
    </message>
    <message>
        <source>Attach a File as a Comment</source>
        <translation>附加一个文件作为批注</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation>Master PDF Editor在文档中未找到任何水印。</translation>
    </message>
    <message>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation>想要从文档中删除水印吗？</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation>Master PDF Editor在文档中未找到任何背景。</translation>
    </message>
    <message>
        <source>Do you want to delete the Background from the document?</source>
        <translation>想要从文档中删除背景吗？</translation>
    </message>
    <message>
        <source>Blank PDF</source>
        <translation>空白PDF</translation>
    </message>
    <message>
        <source>From Scanner</source>
        <translation>来自扫描仪</translation>
    </message>
    <message>
        <source>Create a new document from scanner</source>
        <translation>从扫描仪创建新文档</translation>
    </message>
    <message>
        <source>From Files</source>
        <translation>从文件</translation>
    </message>
    <message>
        <source>Create a new document from files</source>
        <translation>从此文件创建新文档</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="vanished">戳记</translation>
    </message>
    <message>
        <source>Brush</source>
        <translation>笔刷</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation>页眉和页脚</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation>复选框</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation>单选按钮</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation>组合框</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation>列表框</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation>文本框</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>菜单</translation>
    </message>
    <message>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <source>Characters</source>
        <translation>字符</translation>
    </message>
    <message>
        <source>Ctrl+F12</source>
        <translation>Ctrl+F12</translation>
    </message>
    <message>
        <source>Page Display</source>
        <translation>页面显示</translation>
    </message>
    <message>
        <source>Go To</source>
        <translation>转到</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>程序重启后修改生效。</translation>
    </message>
    <message>
        <source>Send file via email</source>
        <translation>通过电子邮件发送文件</translation>
    </message>
    <message>
        <source>Callout</source>
        <translation>标注</translation>
    </message>
    <message>
        <source>Formatted Text</source>
        <translation>格式化文本</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;插入格式化文本&lt;/span&gt;&lt;/p&gt;&lt;p&gt;在当前页面插入带有格式的文字&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation>文本框</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation>修订</translation>
    </message>
    <message>
        <source>Alt+6</source>
        <translation>Alt+6</translation>
    </message>
    <message>
        <source>Alt+7</source>
        <translation>Alt+7</translation>
    </message>
    <message>
        <source>Check for Updates</source>
        <translation>检查更新</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation>标记为修订</translation>
    </message>
    <message>
        <source>Apply Redactions</source>
        <translation>应用修订</translation>
    </message>
    <message>
        <source>Redaction Properties</source>
        <translation>修订属性</translation>
    </message>
    <message>
        <source>Show Redaction ToolBar</source>
        <translation>显示修订工具栏</translation>
    </message>
    <message>
        <source>Search and Redact</source>
        <translation>搜索与修订</translation>
    </message>
    <message>
        <source>Certificate Manager</source>
        <translation>证书管理器</translation>
    </message>
    <message>
        <source>Send Backward</source>
        <translation>下移一层</translation>
    </message>
    <message>
        <source>Bring Forward</source>
        <translation>上移一层</translation>
    </message>
    <message>
        <source>Edit Vector Images</source>
        <translation>编辑矢量图</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation>下一视图</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation>上一视图</translation>
    </message>
    <message>
        <source>Edit Images</source>
        <translation>编辑图片</translation>
    </message>
    <message>
        <source>Show Comments List</source>
        <translation>显示批注列表</translation>
    </message>
    <message>
        <source>You do not have access right to this encrypted document.</source>
        <translation>你无权访问此加密文档。</translation>
    </message>
    <message>
        <source>It is encrypted with certificate absent from your system.</source>
        <translation>它由您系统中没有的证书加密。</translation>
    </message>
    <message>
        <source>All Reviewers</source>
        <translation>所有审阅者</translation>
    </message>
    <message>
        <source>Hide All Comments</source>
        <translation>隐藏所有批注</translation>
    </message>
    <message>
        <source>Show All Comments</source>
        <translation>显示所有批注</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Redaction in the document!</source>
        <translation>Master PDF Editor在文档中未找到任何修订！</translation>
    </message>
    <message>
        <source>Comment View</source>
        <translation>批注视图</translation>
    </message>
    <message>
        <source>Show by Type</source>
        <translation>按类型显示</translation>
    </message>
    <message>
        <source>All Types</source>
        <translation>所有类型</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation>笔记</translation>
    </message>
    <message>
        <source>Text Editing Markups</source>
        <translation>文本编辑标记</translation>
    </message>
    <message>
        <source>Stamps</source>
        <translation>戳记</translation>
    </message>
    <message>
        <source>Attachments</source>
        <translation>附件</translation>
    </message>
    <message>
        <source>Show by Reviewer</source>
        <translation>按审阅者显示</translation>
    </message>
    <message>
        <source>Show by Status</source>
        <translation>按状态显示</translation>
    </message>
    <message>
        <source>All Status</source>
        <translation>所有状态</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="vanished">显示</translation>
    </message>
    <message>
        <source>You already have the latest version!</source>
        <translation>当前使用的即为最新版本！</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF Files (*.pdf *.PDF);;FDF Files (*.fdf *.FDF);;XPS Files (*.xps *.XPS);;TIFF Files (*.tif *.tiff);;All Files (*)</source>
        <translation>所有支持的文件 (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF文件 (*.pdf *.PDF);;FDF文件 (*.fdf *.FDF);;XPS文件 (*.xps *.XPS);;TIFF文件 (*.tif *.tiff);;所有文件 (*)</translation>
    </message>
    <message>
        <source>Hide Comments List</source>
        <translation>隐藏批注列表</translation>
    </message>
    <message>
        <source>pt</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Place Initials</source>
        <translation>位置缩写</translation>
    </message>
    <message>
        <source>Create New Initials</source>
        <translation>创建新缩写</translation>
    </message>
    <message>
        <source>Open Containing Folder</source>
        <translation>打开包含的文件夹</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;打开文件&lt;/span&gt;&lt;/p&gt;&lt;p&gt;打开 PDF或 XPS 文件&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;手开工具&lt;/span&gt;&lt;/p&gt;&lt;p&gt;使用手形工具可以移动页面、打开连接或选定文本。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;选择文本&lt;/span&gt;&lt;/p&gt;&lt;p&gt;选择要复制和粘贴的文本&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;保存&lt;/span&gt;&lt;/p&gt;&lt;p&gt;保存文档&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;另存为...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;以新名字保存文档&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>System Print...</source>
        <translation>系统打印...</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;System Print Dialog&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print using system dialog...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;系统打印对话框&lt;/span&gt;&lt;/p&gt;&lt;p&gt;使用系统对话框打印...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;编辑文档&lt;/span&gt;&lt;/p&gt;&lt;p&gt;选择和编辑文字、图片、批注和表单域...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Objects&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;编辑文字对象&lt;/span&gt;&lt;/p&gt;&lt;p&gt;选择文字并编辑&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;删除对象&lt;/span&gt;&lt;/p&gt;&lt;p&gt;删除当前选定的对象&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Forms&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;编辑表单&lt;/span&gt;&lt;/p&gt;&lt;p&gt;选定表单并编辑&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;新建&lt;/span&gt;&lt;/p&gt;&lt;p&gt;创建新的空白PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;打印&lt;/span&gt;&lt;/p&gt;&lt;p&gt;打印文档&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;剪切&lt;/span&gt;&lt;/p&gt;&lt;p&gt;剪切选定的对象到剪切板中&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;复制&lt;/span&gt;&lt;/p&gt;&lt;p&gt;复制选定的对象到剪切板中&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;粘贴&lt;/span&gt;&lt;/p&gt;&lt;p&gt;从剪切板中粘贴&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;撤销&lt;/span&gt;&lt;/p&gt;&lt;p&gt;撤销上次的动作&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;重做&lt;/span&gt;&lt;/p&gt;&lt;p&gt;重做刚才撤销的动作。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;属性&lt;/span&gt;&lt;/p&gt;&lt;p&gt;打开带有文档属性的窗口&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;插入文本&lt;/span&gt;&lt;/p&gt;&lt;p&gt;在当前页面插入新的文字&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;插入图片&lt;/span&gt;&lt;/p&gt;&lt;p&gt;在当前页面插入新的图片&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;插入连接&lt;/span&gt;&lt;/p&gt;&lt;p&gt;在当前页面插入新的连接&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Vector Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select vector Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;编辑矢量图&lt;/span&gt;&lt;/p&gt;&lt;p&gt;选定矢量图并编辑&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select bitmap Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;编辑图片&lt;/span&gt;&lt;/p&gt;&lt;p&gt;选定位图并编辑&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <source>Pages to Images</source>
        <translation>页面到图片</translation>
    </message>
    <message>
        <source>Pages to Text</source>
        <translation>页面到文本</translation>
    </message>
    <message>
        <source>Extract all Images</source>
        <translation>提取所有图片</translation>
    </message>
    <message>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>PNG 图片 (*.png);;BMP 图片 (*.bmp)</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>重新载入</translation>
    </message>
    <message>
        <source>Take a Snapshot</source>
        <translation>屏幕截图</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>红色</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>蓝色</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>黄色</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>绿色</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <source>What&apos;s new</source>
        <translation>新特性</translation>
    </message>
    <message>
        <source>The file you are attempting to open contains comments or form data that are supposed to be placed on</source>
        <translation>您尝试打开的文件包含批注或表单数据</translation>
    </message>
    <message>
        <source>This document cannot be found.</source>
        <translation>此文档不能被发现。</translation>
    </message>
    <message>
        <source>Would you like to browse and attempt to locate this document?</source>
        <translation>想要浏览并查找此文档吗？</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>已保存设置</translation>
    </message>
    <message>
        <source>Cannot connect! Please verify that you are connected to the Internet and check for updates again.</source>
        <translation>不能连接！请确认已经联网，再重新检查更新。</translation>
    </message>
    <message>
        <source>Toolbar Settings</source>
        <translation>工具栏设置</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation>单页</translation>
    </message>
    <message>
        <source>Continuous</source>
        <translation>连续</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation>文本块</translation>
    </message>
    <message>
        <source>Insert Initials</source>
        <translation>插入首字母</translation>
    </message>
    <message>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>确定要将所有的工具栏设置恢复为默认设置吗？</translation>
    </message>
    <message>
        <source>Reset toolbars</source>
        <translation>重置工具栏</translation>
    </message>
    <message>
        <source>Minimum tools</source>
        <translation type="unfinished">最小化工具</translation>
    </message>
    <message>
        <source>Maximum tools</source>
        <translation type="unfinished">最大化工具</translation>
    </message>
    <message>
        <source>Show All Comments with text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <source>Recognized text</source>
        <translation>已识别</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>原始</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>Not Text</source>
        <translation>非文字</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <source>Move Pages</source>
        <translation>移动页面</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>示例：1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>当前页面</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>选择页面，从</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>到：</translation>
    </message>
    <message>
        <source>Destination</source>
        <translation>目的地</translation>
    </message>
    <message>
        <source>To:</source>
        <translation>到：</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>First</source>
        <translation>首页</translation>
    </message>
    <message>
        <source>Last</source>
        <translation>末面</translation>
    </message>
</context>
<context>
    <name>MovePagesDlg</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">页面范围</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">当前页面</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">到：</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">选择页面，从</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <source>Page Size</source>
        <translation>页面尺寸</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>宽度</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>等高</translation>
    </message>
    <message>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation>当前页面尺寸</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>竖向</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>横向</translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation>内容尺寸</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>左边距</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>上边距</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>右边距</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>下边距</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation>当前页之前</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation>当前页之后</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>末页之后</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>首页之前</translation>
    </message>
    <message>
        <source>Number of pages</source>
        <translation>页数</translation>
    </message>
    <message>
        <source>Page(s)</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>创建</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation>信件</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation>小报</translation>
    </message>
    <message>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation>声明</translation>
    </message>
    <message>
        <source>Executive</source>
        <translation>执行</translation>
    </message>
    <message>
        <source>Folio</source>
        <translation>Folio</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation>Quarto</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>笔记</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <source>ANSI F</source>
        <translation>ANSI F</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>单位</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <source>OCR Engine</source>
        <translation>OCR引擎</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>示例：1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>当前页面</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>全部页面</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>语言</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation>已选</translation>
    </message>
    <message>
        <source>Install languages</source>
        <translation>安装语言</translation>
    </message>
    <message>
        <source>Searchable Text</source>
        <translation>可搜索文字</translation>
    </message>
    <message>
        <source>Editable Text</source>
        <translation>可编辑文字</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Manually edit all recognized text</source>
        <translation>手动编辑所有识别的文字</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>自动</translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Are you sure you want to stop document recognition?</source>
        <translation>确定要取消文档识别吗？</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <source>No Properties
There is no object selections.</source>
        <translation>无属性
未选定对象。</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>Property</source>
        <translation>属性</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>顶</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation>填充色</translation>
    </message>
    <message>
        <source>Stroke Color</source>
        <translation>描边色</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>图片</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>宽度</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>等高</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <source>Form Field</source>
        <translation>表单域</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">加粗</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">斜体</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;字体&lt;/span&gt;&lt;/p&gt;&lt;p&gt;修改字体&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>转到页面视图</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>打开文件/执行程序</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>打开网页链接</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>重置表单</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>显示/隐藏表单域</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>提交表单</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>运行JavaScript脚本</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>添加一个动作</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation>鼠标上移</translation>
    </message>
    <message>
        <source>Mouse Down</source>
        <translation>鼠标下移</translation>
    </message>
    <message>
        <source>Mouse Enter</source>
        <translation>鼠标进入</translation>
    </message>
    <message>
        <source>Mouse Exit</source>
        <translation>鼠标退出</translation>
    </message>
    <message>
        <source>On Receive Focus</source>
        <translation>收到焦点时</translation>
    </message>
    <message>
        <source>On Lose Focus</source>
        <translation>失去焦点时</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>行为</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Push</source>
        <translation>推送</translation>
    </message>
    <message>
        <source>Outline</source>
        <translation>大纲</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation>反转</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>项目</translation>
    </message>
    <message>
        <source>Export Value</source>
        <translation>导出值</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>向上</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>向下</translation>
    </message>
    <message>
        <source>Sort Items</source>
        <translation>项目分类</translation>
    </message>
    <message>
        <source>Commit selected value immediately</source>
        <translation>立即提交选定的值</translation>
    </message>
    <message>
        <source>Multiple selection</source>
        <translation>多选</translation>
    </message>
    <message>
        <source>Allow user to enter custom text</source>
        <translation>允许用户输入自定义文本</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <source>Scrollable</source>
        <translation>可滚动</translation>
    </message>
    <message>
        <source>Check spelling</source>
        <translation>拼写检查</translation>
    </message>
    <message>
        <source>Limit to</source>
        <translation>限制</translation>
    </message>
    <message>
        <source>chars</source>
        <translation>字符</translation>
    </message>
    <message>
        <source>Split into</source>
        <translation>分成</translation>
    </message>
    <message>
        <source>Allow Rich Text formatting</source>
        <translation>允许富文本格式</translation>
    </message>
    <message>
        <source>Multi-line</source>
        <translation>多行</translation>
    </message>
    <message>
        <source>cells</source>
        <translation>单元格</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>居中</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>居右</translation>
    </message>
    <message>
        <source>Default Value</source>
        <translation>默认值</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation>对齐</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>风格</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>选择</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>圆圈</translation>
    </message>
    <message>
        <source>Cross</source>
        <translation>十字</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation>钻石</translation>
    </message>
    <message>
        <source>Square</source>
        <translation>正方形</translation>
    </message>
    <message>
        <source>Star</source>
        <translation>星形</translation>
    </message>
    <message>
        <source>Checked by Default</source>
        <translation>默认选中</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation>线条粗细</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation>边框色</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation>线型</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation>实线</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation>虚线</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation>下划线</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation>高亮</translation>
    </message>
    <message>
        <source>OutLine</source>
        <translation>大纲</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;签名。&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;无可用选项&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <source>Format category</source>
        <translation>格式类别</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>数字</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Percentage</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <source>Special</source>
        <translation>特殊</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <source>Currency Symbol</source>
        <translation>当前符号</translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation>美元（$）</translation>
    </message>
    <message>
        <source>Euro (€)</source>
        <translation>欧元 (€)</translation>
    </message>
    <message>
        <source>Pound (£)</source>
        <translation>英镑 (£)</translation>
    </message>
    <message>
        <source>Yen (¥)</source>
        <translation>日元 (¥)</translation>
    </message>
    <message>
        <source>Show parentheses</source>
        <translation>显示圆括号</translation>
    </message>
    <message>
        <source>Decimal Places</source>
        <translation>小数位</translation>
    </message>
    <message>
        <source>Separation Style</source>
        <translation>分隔样式</translation>
    </message>
    <message>
        <source>Use red text</source>
        <translation>使用红色文字</translation>
    </message>
    <message>
        <source>Date Options</source>
        <translation>日期选项</translation>
    </message>
    <message>
        <source>Time Options</source>
        <translation>时间选项</translation>
    </message>
    <message>
        <source>Special Options</source>
        <translation>特殊选项</translation>
    </message>
    <message>
        <source>Format Script</source>
        <translation>格式脚本</translation>
    </message>
    <message>
        <source>KeyStroke Script</source>
        <translation>击键脚本</translation>
    </message>
    <message>
        <source>Validate</source>
        <translation>已验证</translation>
    </message>
    <message>
        <source>Validation Script</source>
        <translation>已验证脚本</translation>
    </message>
    <message>
        <source>Calculate</source>
        <translation>计算</translation>
    </message>
    <message>
        <source>Calculation Script</source>
        <translation>计算脚本</translation>
    </message>
    <message>
        <source>Fill text</source>
        <translation>填充文本</translation>
    </message>
    <message>
        <source>Stroke Text</source>
        <translation>文字描边</translation>
    </message>
    <message>
        <source>Fill and Stroke</source>
        <translation>填充并描边</translation>
    </message>
    <message>
        <source>Invisible</source>
        <translation>不可见</translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation>线宽</translation>
    </message>
    <message>
        <source>Character spacing</source>
        <translation>字符空格</translation>
    </message>
    <message>
        <source>Word spacing</source>
        <translation>单词空格</translation>
    </message>
    <message>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <source>Coordinates</source>
        <translation>协调</translation>
    </message>
    <message>
        <source>Absolute</source>
        <translation>绝对</translation>
    </message>
    <message>
        <source>Relative</source>
        <translation>相对</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>几何</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Matrix</source>
        <translation>矩阵</translation>
    </message>
    <message>
        <source>General</source>
        <translation>常规</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>外观</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>Stroke</source>
        <translation>描边</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation>边框和颜色</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation>细</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>中</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation>粗</translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation>分配</translation>
    </message>
    <message>
        <source>Inset</source>
        <translation>插图</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation>工具提示</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>方向</translation>
    </message>
    <message>
        <source>0 Degrees</source>
        <translation>0度</translation>
    </message>
    <message>
        <source>90 Degrees</source>
        <translation>90度</translation>
    </message>
    <message>
        <source>180 Degrees</source>
        <translation>180度</translation>
    </message>
    <message>
        <source>270 Degrees</source>
        <translation>270度</translation>
    </message>
    <message>
        <source>Read Only</source>
        <translation>只读</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>可见</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation>隐藏</translation>
    </message>
    <message>
        <source>Visible but doesn&apos;t print</source>
        <translation>可见但不打印</translation>
    </message>
    <message>
        <source>Hidden but printable</source>
        <translation>隐藏但可打印</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>必需</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation>锁定</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;字体颜色&lt;/span&gt;&lt;/p&gt;&lt;p&gt;修改填充色&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;字体描边颜色&lt;/span&gt;&lt;/p&gt;&lt;p&gt;修改描边色&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Shading</source>
        <translation>阴影</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>主题</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <source>Maintain aspect ratio</source>
        <translation>保持纵横比</translation>
    </message>
    <message>
        <source>Zip Code</source>
        <translation>邮编</translation>
    </message>
    <message>
        <source>Zip Code+4</source>
        <translation>邮编+4</translation>
    </message>
    <message>
        <source>Phone Number</source>
        <translation>电话号码</translation>
    </message>
    <message>
        <source>Social Security Number</source>
        <translation>社保号码</translation>
    </message>
    <message>
        <source>Check Mark</source>
        <translation>复选标记</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>批注</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">插入文字</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>键</translation>
    </message>
    <message>
        <source>New Paragraph</source>
        <translation>新建段落</translation>
    </message>
    <message>
        <source>Text Note</source>
        <translation>文字备注</translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation>段落</translation>
    </message>
    <message>
        <source>Right Arrow</source>
        <translation>向右箭头</translation>
    </message>
    <message>
        <source>Right Pointer</source>
        <translation>向右指针</translation>
    </message>
    <message>
        <source>Up Arrow</source>
        <translation>向上箭头</translation>
    </message>
    <message>
        <source>Up Left Arrow</source>
        <translation>左上箭头</translation>
    </message>
    <message>
        <source>Graph</source>
        <translation>图表</translation>
    </message>
    <message>
        <source>Paper Clip</source>
        <translation>回形针</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>附件</translation>
    </message>
    <message>
        <source>Tag</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>旋转</translation>
    </message>
    <message>
        <source>Fill</source>
        <translation>填充</translation>
    </message>
    <message>
        <source>Line height</source>
        <translation>线高</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>Selection change</source>
        <translation>选择更改</translation>
    </message>
    <message>
        <source>Do nothing</source>
        <translation>无操作</translation>
    </message>
    <message>
        <source>Execute this script</source>
        <translation>执行此脚本</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>单位</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="vanished">水印</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="vanished">背景</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="vanished">页眉和页脚</translation>
    </message>
    <message>
        <source>Clipping Path</source>
        <translation>剪辑路径</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>布局</translation>
    </message>
    <message>
        <source>Label only</source>
        <translation>仅文字</translation>
    </message>
    <message>
        <source>Icon only</source>
        <translation>仅图标</translation>
    </message>
    <message>
        <source>Icon top, label bottom</source>
        <translation>图标在上，文字在下</translation>
    </message>
    <message>
        <source>Label top, icon bottom</source>
        <translation>文字在上，图标在下</translation>
    </message>
    <message>
        <source>Icon left, label right</source>
        <translation>图标在左，文字在右</translation>
    </message>
    <message>
        <source>label left, icon right</source>
        <translation>文字在左，图标在右</translation>
    </message>
    <message>
        <source>Label over icon</source>
        <translation>文字在图标上</translation>
    </message>
    <message>
        <source>Icon and Label</source>
        <translation>图标和文字</translation>
    </message>
    <message>
        <source>Rollover</source>
        <translation>翻转</translation>
    </message>
    <message>
        <source>State</source>
        <translation>状态</translation>
    </message>
    <message>
        <source>Choose Icon...</source>
        <translation>选择图标...</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>文字标签</translation>
    </message>
    <message>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation>同时选定有相同名称和值的按钮</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">打开</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>所有文件 (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>高级</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <source>Ruble (₽)</source>
        <translation>卢布 (₽)</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>Always show Object Inspector</source>
        <translation>始终显示对象检查器</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation>文本块</translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <source>Object TreeView</source>
        <translation>对象树形视图</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全部页面</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">视图</translation>
    </message>
    <message>
        <source>Expand All</source>
        <translation>全部展开</translation>
    </message>
    <message>
        <source>Collapse All</source>
        <translation>全部折叠</translation>
    </message>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>图片</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>路径</translation>
    </message>
    <message>
        <source>Shadings</source>
        <translation>阴影</translation>
    </message>
    <message>
        <source>Containers</source>
        <translation>容器</translation>
    </message>
    <message>
        <source>Text Fields</source>
        <translation>文本框</translation>
    </message>
    <message>
        <source>List Boxes</source>
        <translation>列表框</translation>
    </message>
    <message>
        <source>Combo Boxes</source>
        <translation>组合框</translation>
    </message>
    <message>
        <source>Check Boxes</source>
        <translation>复选框</translation>
    </message>
    <message>
        <source>Radio Buttons</source>
        <translation>单选按钮</translation>
    </message>
    <message>
        <source>Buttons</source>
        <translation>按钮</translation>
    </message>
    <message>
        <source>Links</source>
        <translation>链接</translation>
    </message>
    <message>
        <source>Signatures</source>
        <translation>签名</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>显示</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>批注</translation>
    </message>
</context>
<context>
    <name>OptionToolBarForm</name>
    <message>
        <source>Tollbars</source>
        <translation>工具栏</translation>
    </message>
    <message>
        <source>All tools:</source>
        <translation>所有工具：</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>工具工具</translation>
    </message>
    <message>
        <source>Current toolbar tools:</source>
        <translation>当前工具栏工具：</translation>
    </message>
    <message>
        <source>Toolbars:</source>
        <translation>工具栏：</translation>
    </message>
    <message>
        <source>Add Toolbar</source>
        <translation>添加工具栏</translation>
    </message>
    <message>
        <source>Delete Toolbar</source>
        <translation>删除工具栏</translation>
    </message>
    <message>
        <source>Reset All</source>
        <translation>全部重置</translation>
    </message>
    <message>
        <source>Maximum tools</source>
        <translation>最大化工具</translation>
    </message>
    <message>
        <source>Minimum tools</source>
        <translation>最小化工具</translation>
    </message>
    <message>
        <source>Please, name new toolbar</source>
        <translation>请命名新工具栏</translation>
    </message>
    <message>
        <source>ToolBar with this name already exist.</source>
        <translation>同名的工具栏已存在。</translation>
    </message>
    <message>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>确定要将所有工具栏设置恢复为默认设置吗？</translation>
    </message>
</context>
<context>
    <name>PDFTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished">此字体缺少一些字符。
尝试选择其它字体。</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <source>Page Layout</source>
        <translation>页面格式</translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation>内容尺寸</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>左边距</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>上边距</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>右边距</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>下边距</translation>
    </message>
    <message>
        <source>Page Size</source>
        <translation>页面尺寸</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="obsolete">宽度</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="obsolete">等高</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">选择页面，从</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>当前页面</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>全部页面</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>到：</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>单位</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation>奇偶页</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation>偶数页</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation>奇数页</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>顶端</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>底部</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>左侧</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>右侧</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>From</source>
        <translation>从</translation>
    </message>
    <message>
        <source>of:</source>
        <translation>/：</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>方向</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>竖向</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>横向</translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <source>Page Properties</source>
        <translation>页面属性</translation>
    </message>
    <message>
        <source>Tab Order</source>
        <translation>标签顺序</translation>
    </message>
    <message>
        <source>Use Row Order</source>
        <translation>使用行顺序</translation>
    </message>
    <message>
        <source>Use Column Order</source>
        <translation>使用列顺序</translation>
    </message>
    <message>
        <source>Use Document Structure</source>
        <translation>使用文档结构</translation>
    </message>
    <message>
        <source>Unspecified</source>
        <translation>未指定</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>添加一个动作</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>转到页面视图</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>打开文件/执行程序</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>打开网页链接</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>重置表单</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>显示/隐藏表单域</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>提交表单</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>运行JavaScript脚本</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Open Page</source>
        <translation>打开页面</translation>
    </message>
    <message>
        <source>Close Page</source>
        <translation>关闭页面</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>当前页面</translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <source>Printer Settings</source>
        <translation>打印机设置</translation>
    </message>
    <message>
        <source>Paper</source>
        <translation>纸张</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>宽度：</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>高度：</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>页面尺寸：</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>页边距</translation>
    </message>
    <message>
        <source>bottom margin</source>
        <translation>下边距</translation>
    </message>
    <message>
        <source>top margin</source>
        <translation>上边距</translation>
    </message>
    <message>
        <source>left margin</source>
        <translation>左边距</translation>
    </message>
    <message>
        <source>right margin</source>
        <translation>右边距</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>分辨率</translation>
    </message>
    <message>
        <source>72</source>
        <translation>72</translation>
    </message>
    <message>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <source>1200</source>
        <translation>1200</translation>
    </message>
    <message>
        <source>Paper Source</source>
        <translation>纸张来源</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
    <message>
        <source>96</source>
        <translation type="unfinished">96</translation>
    </message>
    <message>
        <source>100</source>
        <translation type="unfinished">100</translation>
    </message>
    <message>
        <source>200</source>
        <translation type="unfinished">200</translation>
    </message>
    <message>
        <source>240</source>
        <translation type="unfinished">240</translation>
    </message>
    <message>
        <source>400</source>
        <translation type="unfinished">400</translation>
    </message>
    <message>
        <source>760</source>
        <translation type="unfinished">760</translation>
    </message>
    <message>
        <source>800</source>
        <translation type="unfinished">800</translation>
    </message>
    <message>
        <source>2400</source>
        <translation type="unfinished">2400</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <source>Password:</source>
        <translation>密码:</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>该文件有密码保护，请输入密码来打开此文档</translation>
    </message>
    <message>
        <source>Enter Password</source>
        <translation>输入密码</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <source>Paste to multiple pages</source>
        <translation>粘贴到多个页面</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>示例：1,6-8,12</translation>
    </message>
    <message>
        <source>All pages</source>
        <translation>所有页面</translation>
    </message>
    <message>
        <source>Except current one</source>
        <translation>除了当前页</translation>
    </message>
</context>
<context>
    <name>PlaceInitialsDlg</name>
    <message>
        <source>Place Initials</source>
        <translation>位置缩写</translation>
    </message>
    <message>
        <source>How would like to create your initials?</source>
        <translation>如何创建缩写？</translation>
    </message>
    <message>
        <source>Type my initials</source>
        <translation>输入缩写</translation>
    </message>
    <message>
        <source>Draw my initials</source>
        <translation>绘制缩写</translation>
    </message>
    <message>
        <source>Select signature image</source>
        <translation>选择签名图片</translation>
    </message>
    <message>
        <source>Enter your initials:</source>
        <translation>输入缩写：</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>风格</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="unfinished">字体</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Change Initials Style</source>
        <translation>修改缩写风格</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <source>Review Initials:</source>
        <translation>预览缩写：</translation>
    </message>
    <message>
        <source>Draw Initials:</source>
        <translation>绘制缩写：</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>宽度</translation>
    </message>
    <message>
        <source>Browse and select an image of your signature</source>
        <translation>浏览并选定签名图片</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>打开图像</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>图片文件 (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>of</source>
        <translation>/</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>此字体缺少一些字符。
尝试选择其它字体。</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>Printer</source>
        <translation>打印机</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>属性</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>居中</translation>
    </message>
    <message>
        <source>Print as Grayscale</source>
        <translation>灰度打印</translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation>纵横比</translation>
    </message>
    <message>
        <source>Ignore aspect ratio</source>
        <translation>忽略纵横比</translation>
    </message>
    <message>
        <source>Keep aspect ratio</source>
        <translation>保持纵横比</translation>
    </message>
    <message>
        <source>Keep aspect ratio by expanding</source>
        <translation>通过缩放保持纵横比</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>方向</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>竖向</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>横向</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全部页面</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">选择页面，从</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>当前页面</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">到：</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>打印</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>of:</source>
        <translation>/:</translation>
    </message>
    <message>
        <source>of </source>
        <translation>/ </translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>实际大小</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Duplex Printing</source>
        <translation>双面打印</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Long side</source>
        <translation>长边</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Short side</source>
        <translation>短边</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation>偶数页</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation>奇数页</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>文档</translation>
    </message>
    <message>
        <source>Document and Annotations</source>
        <translation>文档和笔记</translation>
    </message>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>Subset</source>
        <translation>子集</translation>
    </message>
    <message>
        <source>All pages in range</source>
        <translation>范围内的所有页面</translation>
    </message>
    <message>
        <source>Print:</source>
        <translation>打印：</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>份数</translation>
    </message>
    <message>
        <source>Collate</source>
        <translation>整理</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>高级</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>比例</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>适合页面</translation>
    </message>
    <message>
        <source>Shrink to printable area</source>
        <translation>缩小到可打印区域</translation>
    </message>
    <message>
        <source>Current view</source>
        <translation>当前视图</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>Poster</source>
        <translation>海报</translation>
    </message>
    <message>
        <source>Booklet</source>
        <translation type="vanished">小册子。</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>已保存设置</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation>保存设置</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation>将当前设置保存为：</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>此名称的文件已存在。确定要替换原有文件吗？</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation>确定删除此设置吗 </translation>
    </message>
    <message>
        <source> ?</source>
        <translation> ？</translation>
    </message>
    <message>
        <source>Multiple</source>
        <translation>多个</translation>
    </message>
    <message>
        <source>Overlay</source>
        <translation>覆盖</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source>Pages per sheet:</source>
        <translation>每面页数：</translation>
    </message>
    <message>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation>水平</translation>
    </message>
    <message>
        <source>Horizontal Reversed</source>
        <translation>水平翻转</translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation>垂直</translation>
    </message>
    <message>
        <source>Vertical Reversed</source>
        <translation>垂直翻转</translation>
    </message>
    <message>
        <source>Additional spacing:</source>
        <translation>附加间距：</translation>
    </message>
    <message>
        <source>pt</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Center pages in cells</source>
        <translation>单元格中页面居中</translation>
    </message>
    <message>
        <source>Page Setup</source>
        <translation>页面设置</translation>
    </message>
    <message>
        <source>System Properties</source>
        <translation>系统属性</translation>
    </message>
</context>
<context>
    <name>PrintingMode</name>
    <message>
        <source>There was an error printing the document</source>
        <translation>打印文档时出错</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">另存为...</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Attachment Tab</source>
        <translation>附件选项卡</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">打开</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>附件</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <source>Add Bookmark</source>
        <translation>添加书签</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation type="vanished">删除书签</translation>
    </message>
    <message>
        <source>Bookmark Properties</source>
        <translation>书签属性</translation>
    </message>
    <message>
        <source>Set Destination</source>
        <translation>设置目的地</translation>
    </message>
    <message>
        <source>Delete Bookmark(s)</source>
        <translation>删除书签</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <source>Close All</source>
        <translation>全部关闭</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">保存</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">另存为...</translation>
    </message>
    <message>
        <source>Move to New Window</source>
        <translation>移动到新窗口</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>未命名</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="vanished">剪切板中无数据</translation>
    </message>
    <message>
        <source>Close All Other Tabs</source>
        <translation>关闭其它所有标签</translation>
    </message>
    <message>
        <source>Close All Tabs to the Right</source>
        <translation>关闭右侧所有标签</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain any data</source>
        <translation>剪切板中无任何数据</translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <source>Email delivery</source>
        <translation>电子邮件传送</translation>
    </message>
    <message>
        <source>To</source>
        <translation>收信人</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>主题</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>发送</translation>
    </message>
</context>
<context>
    <name>QHTMLEditor</name>
    <message>
        <source>File</source>
        <translation type="obsolete">文件</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">编辑</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">撤消</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">重做</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">复制</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">粘贴</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">加粗</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">斜体</translation>
    </message>
</context>
<context>
    <name>QHtmlFormEditor</name>
    <message>
        <source>Undo</source>
        <translation type="obsolete">撤消</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">重做</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">复制</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">粘贴</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">加粗</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">斜体</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <source>Zoom In</source>
        <translation type="vanished">放大</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="vanished">缩小</translation>
    </message>
    <message>
        <source>Zoom to Selection</source>
        <translation>缩放到选定区域</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">适合页面</translation>
    </message>
    <message>
        <source>Clear Selections</source>
        <translation>清除选择</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>You are not allowed to use this function in the free version</source>
        <translation>免费版禁止使用此功能</translation>
    </message>
    <message>
        <source>The unregistered version will insert a watermark</source>
        <translation>未注册版本将插入水印</translation>
    </message>
    <message>
        <source>Build</source>
        <translation>构建于</translation>
    </message>
    <message>
        <source>32 bit</source>
        <translation>32位</translation>
    </message>
    <message>
        <source>64 bit</source>
        <translation>64位</translation>
    </message>
    <message>
        <source>Mouse Enter</source>
        <translation>鼠标进入</translation>
    </message>
    <message>
        <source>Mouse Exit</source>
        <translation>鼠标退出</translation>
    </message>
    <message>
        <source>Mouse Down</source>
        <translation>鼠标下移</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation>鼠标向上</translation>
    </message>
    <message>
        <source>On Receive Focus</source>
        <translation>收到焦点时</translation>
    </message>
    <message>
        <source>On Lose Focus</source>
        <translation>失去焦点时</translation>
    </message>
    <message>
        <source>Page Open</source>
        <translation>页面打开</translation>
    </message>
    <message>
        <source>Page Close</source>
        <translation>页面关闭</translation>
    </message>
    <message>
        <source>Page Visible</source>
        <translation>页面可见</translation>
    </message>
    <message>
        <source>Page Invisible</source>
        <translation>页面不可见</translation>
    </message>
    <message>
        <source>Open Page</source>
        <translation>打开页面</translation>
    </message>
    <message>
        <source>Close Page</source>
        <translation>关闭页面</translation>
    </message>
    <message>
        <source>KeyStroke</source>
        <translation>击键</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <source>Validate</source>
        <translation>已验证</translation>
    </message>
    <message>
        <source>Calculate</source>
        <translation>计算</translation>
    </message>
    <message>
        <source>Close Document</source>
        <translation>关闭文档</translation>
    </message>
    <message>
        <source>Save Document</source>
        <translation>保存文档</translation>
    </message>
    <message>
        <source>Document Saved</source>
        <translation>文档已保存</translation>
    </message>
    <message>
        <source>Print Document</source>
        <translation>打印文档</translation>
    </message>
    <message>
        <source>Document Printed</source>
        <translation>文档已经打印</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>转到页面视图</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>打开文件/执行程序</translation>
    </message>
    <message>
        <source>Thread</source>
        <translation>线</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>打开网页链接</translation>
    </message>
    <message>
        <source>Sound</source>
        <translation>声音</translation>
    </message>
    <message>
        <source>Movie</source>
        <translation>电影</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>显示/隐藏表单域</translation>
    </message>
    <message>
        <source>Submit Form</source>
        <translation>提交表单</translation>
    </message>
    <message>
        <source>Reset Form</source>
        <translation>重置表单</translation>
    </message>
    <message>
        <source>Import Data</source>
        <translation>插入数据</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>运行JavaScript脚本</translation>
    </message>
    <message>
        <source>Rendition</source>
        <translation>修订</translation>
    </message>
    <message>
        <source>Goto 3D View</source>
        <translation>转到3D视图</translation>
    </message>
    <message>
        <source>Open with</source>
        <translation>打开方式</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>亮度</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>对比度</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>伽玛值</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>已核准</translation>
    </message>
    <message>
        <source>Confidential</source>
        <translation>机密</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>已收到</translation>
    </message>
    <message>
        <source>Reviewed</source>
        <translation>已检验</translation>
    </message>
    <message>
        <source>Revised</source>
        <translation>已修订</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>已完成</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>草稿</translation>
    </message>
    <message>
        <source>Emergency</source>
        <translation>紧急</translation>
    </message>
    <message>
        <source>Expired</source>
        <translation>终止</translation>
    </message>
    <message>
        <source>Final</source>
        <translation>最终</translation>
    </message>
    <message>
        <source>Verified</source>
        <translation>已证实</translation>
    </message>
    <message>
        <source>Void</source>
        <translation>无效</translation>
    </message>
    <message>
        <source>Accepted</source>
        <translation>已认可</translation>
    </message>
    <message>
        <source>Initial</source>
        <translation>初始</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>已拒绝</translation>
    </message>
    <message>
        <source>SignHere</source>
        <translation>在此签名</translation>
    </message>
    <message>
        <source>Witness</source>
        <translation>证人</translation>
    </message>
    <message>
        <source>Dynamic</source>
        <translation>动态</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation></translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>图标</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>信息</translation>
    </message>
    <message>
        <source>Press Help button to get more info.</source>
        <translation>按帮助按钮可获取更多信息。</translation>
    </message>
    <message>
        <source>Error.</source>
        <translation>错误。</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>对象</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>图片</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <source>Shading</source>
        <translation>阴影</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation>对象</translation>
    </message>
    <message>
        <source>All Objects</source>
        <translation>全部对象</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>表单</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>批注</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>容器</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation>便签备注</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation>高亮</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation>下划线</translation>
    </message>
    <message>
        <source>StrikeOut</source>
        <translation>删除线</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>答复</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>FDF Files (*.fdf)</source>
        <translation>FDF 文件 (*.fdf)</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation>文本框</translation>
    </message>
    <message>
        <source>Text Box</source>
        <translation>文本框</translation>
    </message>
    <message>
        <source>Formatted Text</source>
        <translation>格式化文本</translation>
    </message>
    <message>
        <source>Issued by:</source>
        <translation>签发人：</translation>
    </message>
    <message>
        <source>Expires</source>
        <translation>到期</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Cancelled</source>
        <translation>已取消</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>已确认</translation>
    </message>
    <message>
        <source>Not Confirmed</source>
        <translation>未确认</translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation>打开对象检查器</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Review History</source>
        <translation>回顾历史</translation>
    </message>
    <message>
        <source>Make Current Properties Default</source>
        <translation>将当前属性设为默认</translation>
    </message>
    <message>
        <source>Error Loading Image!</source>
        <translation>载入图片时出错！</translation>
    </message>
    <message>
        <source>Incorrect date/time format. Please, insert date/time to match format: </source>
        <translation>日期/时间格式不正确。请以匹配的格式插入日期/时间： </translation>
    </message>
    <message>
        <source>You have exceeded the number of available activations.</source>
        <translation>您已超过可用的激活次数。</translation>
    </message>
    <message>
        <source>Please, deactivate your license on another PC.</source>
        <translation>请在其它电脑上停用您的许可证。</translation>
    </message>
    <message>
        <source>Your license is expired. Please, renew your license.</source>
        <translation>你的许可证已过期。请给许可证续期。</translation>
    </message>
    <message>
        <source>Impossible to verify your license! Check your internet connection and press Verify Now</source>
        <translation>无法验证您的许可证！检查您的internet连接并按“立即验证”</translation>
    </message>
    <message>
        <source>Your license doesn&apos;t allow to use this version. Please, renew your license.</source>
        <translation>您的许可证不允许使用此版本。请给您的许可证续期。</translation>
    </message>
    <message>
        <source>Print using Windows API</source>
        <translation>使用Windows API打印</translation>
    </message>
    <message>
        <source>Do not show this message again</source>
        <translation>不再显示此消息</translation>
    </message>
    <message>
        <source>If OpenSSL is not installed, encryption and signature functionality will be unavailable.</source>
        <translation>如果OpenSSL未被安装，加密和签名功能将不可用。</translation>
    </message>
    <message>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>Separator</source>
        <translation>分隔符</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>另存为...</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation>工具栏</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation>电子邮件传送</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>打印</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <source>Delete Object(s)</source>
        <translation>删除对象</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>撤消</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation>左对齐</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation>右对齐</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation>上对齐</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation>下对齐</translation>
    </message>
    <message>
        <source>Align Center Horizontal</source>
        <translation>水平居中对齐</translation>
    </message>
    <message>
        <source>Align Center Vertical</source>
        <translation>垂直居中对齐</translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation>下移一层</translation>
    </message>
    <message>
        <source>Send Backward</source>
        <translation>下移一层</translation>
    </message>
    <message>
        <source>Bring Forward</source>
        <translation>上移一层</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation>上移一层</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>网格</translation>
    </message>
    <message>
        <source>Snap To Grid</source>
        <translation>对齐到网格</translation>
    </message>
    <message>
        <source>View</source>
        <translation>视图</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation>上一视图</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation>下一视图</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>缩小</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>实际大小</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>放大</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>适合页面</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>适合宽度</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation>对开</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>逆时针旋转90度</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>顺时针旋转90度</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation>编辑文档</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>编辑文本</translation>
    </message>
    <message>
        <source>Edit Images</source>
        <translation>编辑图片</translation>
    </message>
    <message>
        <source>Edit Vector Images</source>
        <translation>编辑矢量图</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation>编辑表单</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation>编辑工具</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation>手形工具</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation>选择文字</translation>
    </message>
    <message>
        <source>Take Snapshot</source>
        <translation>屏幕截图</translation>
    </message>
    <message>
        <source>Insert Link</source>
        <translation>插入链接</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>按钮</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation>复选框</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation>组合框</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation>文本框</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation>列表框</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation>单选按钮</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>签名</translation>
    </message>
    <message>
        <source>Insert Formatted Text</source>
        <translation>插入带格式文本</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation>插入文字</translation>
    </message>
    <message>
        <source>Insert Image</source>
        <translation>插入图片</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>线条</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation>铅笔</translation>
    </message>
    <message>
        <source>Attach a File as a Comment</source>
        <translation>附加一个文件作为批注</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation>修订</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation>标记为修订</translation>
    </message>
    <message>
        <source>Search And Redact</source>
        <translation>搜索并修订</translation>
    </message>
    <message>
        <source>Apply Redaction</source>
        <translation>应用修订</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>文档</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation>插入空白页面</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation>删除页面</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation>裁剪页面</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation>页面布局</translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation>旋转页面</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation>提取页面...</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation>插入页面...</translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation>文档动作</translation>
    </message>
    <message>
        <source>Document JavaScript</source>
        <translation>文档JavaScript</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation>页面属性</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation>页眉和页脚</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>水印</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
    <message>
        <source>Page Counter</source>
        <translation>页数</translation>
    </message>
    <message>
        <source>New</source>
        <translation>新建PDF</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>查找</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>高亮文本</translation>
    </message>
    <message>
        <source>Draw Comment Tools</source>
        <translation>绘图批注工具</translation>
    </message>
    <message>
        <source>Measurement Tools</source>
        <translation>测量工具</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation>戳记</translation>
    </message>
    <message>
        <source>Comment View</source>
        <translation>批注视图</translation>
    </message>
    <message>
        <source>Place Initials</source>
        <translation>位置缩写</translation>
    </message>
    <message>
        <source>Continuous Page</source>
        <translation>连续页面</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation>单页</translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <source>Error!</source>
        <translation>错误！</translation>
    </message>
    <message>
        <source>There was a problem with your form submission.</source>
        <translation>表单提交有问题。</translation>
    </message>
    <message>
        <source>Your form was successfully submitted!</source>
        <translation>表单提交成功！</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>of</source>
        <translation>/</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
    <message>
        <source>PDF document action attempts to submit form data to another location. Proceed?</source>
        <translation>PDF文档动作企图将表单数据提交到其他位置。继续吗？</translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <source>Open Document</source>
        <translation>打开文档</translation>
    </message>
    <message>
        <source>Blank PDF</source>
        <translation>空白PDF</translation>
    </message>
    <message>
        <source>From Files</source>
        <translation>来自文件</translation>
    </message>
    <message>
        <source>From Scanner</source>
        <translation>来自扫描仪</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>User Guide</source>
        <translation>用户向导</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation>注册...</translation>
    </message>
    <message>
        <source>Buy Online</source>
        <translation>在线购买</translation>
    </message>
    <message>
        <source>Create New Document</source>
        <translation>创建新文档</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation>近期文件</translation>
    </message>
    <message>
        <source>Empty recent files list</source>
        <translation>清空近期文件列表</translation>
    </message>
    <message>
        <source>Pinned Files</source>
        <translation>固定文件</translation>
    </message>
    <message>
        <source>You have reached the limit of 10 pinned files.</source>
        <translation>最多固定10个文件。已达到上限。</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation>放大页面缩略图</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation>缩小页面缩略图</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>书签</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>附件</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>对象检查器</translation>
    </message>
    <message>
        <source>This document contains interactive form fields</source>
        <translation>此文档包含交互式表单域</translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation>高亮表单域</translation>
    </message>
    <message>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation>文档被保护。您无权编辑</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>修改</translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation>打印文档时出错</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="obsolete">插入页面</translation>
    </message>
    <message>
        <source>Do you want to open?</source>
        <translation>想要打开吗？</translation>
    </message>
    <message>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>想要将选定书签的目的地设置为当前位置吗？</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>未命名</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="vanished">删除页面</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="vanished">插入空白页面</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="vanished">页面属性</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">顺时针旋转90度</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">逆时针旋转90度</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation>错误！</translation>
    </message>
    <message>
        <source>Error loading font: </source>
        <translation>载入字体出错： </translation>
    </message>
    <message>
        <source>Object TreeView</source>
        <translation>对象树形视图</translation>
    </message>
    <message>
        <source>Layers</source>
        <translation>图层</translation>
    </message>
    <message>
        <source>Registration</source>
        <translation>注册</translation>
    </message>
    <message>
        <source>Signatures</source>
        <translation>签名</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>Set current zoom</source>
        <translation>设置当前缩放</translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <source>Millimeters (mm)</source>
        <translation>毫米（mm）</translation>
    </message>
    <message>
        <source>Inches (in)</source>
        <translation>英寸（in）</translation>
    </message>
    <message>
        <source>Points (pt)</source>
        <translation>点（pt）</translation>
    </message>
    <message>
        <source>Pica (P̸)</source>
        <translation>派卡（P）</translation>
    </message>
    <message>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation>mm</translation>
    </message>
    <message>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation>pt</translation>
    </message>
    <message>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation>in</translation>
    </message>
    <message>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation>P</translation>
    </message>
    <message>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation>DD</translation>
    </message>
    <message>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation>CC</translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <source>More...</source>
        <translation>更多...</translation>
    </message>
    <message>
        <source>User Color 99</source>
        <translation>使用99色</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>黑色</translation>
    </message>
    <message>
        <source>White</source>
        <translation>白色</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>红色</translation>
    </message>
    <message>
        <source>Dark red</source>
        <translation>深红</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>绿色</translation>
    </message>
    <message>
        <source>Dark green</source>
        <translation>深绿</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>蓝色</translation>
    </message>
    <message>
        <source>Dark blue</source>
        <translation>深蓝</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation>青色</translation>
    </message>
    <message>
        <source>Dark cyan</source>
        <translation>深青</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation>洋红</translation>
    </message>
    <message>
        <source>Dark magenta</source>
        <translation>深洋红</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>黄色</translation>
    </message>
    <message>
        <source>Dark yellow</source>
        <translation>深黄</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>灰色</translation>
    </message>
    <message>
        <source>Dark gray</source>
        <translation>深灰</translation>
    </message>
    <message>
        <source>Light gray</source>
        <translation>浅灰</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>透明</translation>
    </message>
</context>
<context>
    <name>RedactionCodesDlg</name>
    <message>
        <source>Redaction Code Editor</source>
        <translation>修订代码编辑器</translation>
    </message>
    <message>
        <source>Code Sets</source>
        <translation>代码集</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>导入</translation>
    </message>
    <message>
        <source>Code Entries</source>
        <translation>代码条目</translation>
    </message>
</context>
<context>
    <name>RedactionDlg</name>
    <message>
        <source>Redacted Area Fill Color</source>
        <translation>修订区域填充色</translation>
    </message>
    <message>
        <source>Use Overlay Text</source>
        <translation>使用浮层文本</translation>
    </message>
    <message>
        <source>Code Sets</source>
        <translation>代码集</translation>
    </message>
    <message>
        <source>Code Entries:</source>
        <translation>代码条目:</translation>
    </message>
    <message>
        <source>Edit Codes</source>
        <translation>编辑代码</translation>
    </message>
    <message>
        <source>Redaction Code</source>
        <translation>修订代码</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>Repeat Overlay Text</source>
        <translation>重复浮层文本</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Auto-size text</source>
        <translation>自动设置文字大小</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <source>Registration Info</source>
        <translation>注册信息</translation>
    </message>
    <message>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>购买完成后，您将通过电子邮件自动收到注册码。</translation>
    </message>
    <message>
        <source>Buy Online</source>
        <translation>在线购买</translation>
    </message>
    <message>
        <source>Registration Code</source>
        <translation>注册码</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation>激活</translation>
    </message>
    <message>
        <source>Offline Activation</source>
        <translation>离线激活</translation>
    </message>
    <message>
        <source>Registered version</source>
        <translation>已注册版本</translation>
    </message>
    <message>
        <source>Deactivate</source>
        <translation>停用</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>后退</translation>
    </message>
    <message>
        <source>Activation Code</source>
        <translation>激活码</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">关闭</translation>
    </message>
    <message>
        <source>Thanks for registration.</source>
        <translation>感谢您注册。</translation>
    </message>
    <message>
        <source>License is deactivated.</source>
        <translation>许可证未激活。</translation>
    </message>
    <message>
        <source>Too many activations!</source>
        <translation>激活次数太多！</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;请将ID值和瀩码发送到： &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;一旦收到注册码，请将其输入到 &amp;quot;激活码&amp;quot; 区&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Purchased On:</source>
        <translation>已在此购买：</translation>
    </message>
    <message>
        <source>Maintenance Plan Expires:</source>
        <translation>维护计划到期：</translation>
    </message>
    <message>
        <source>License is expired!</source>
        <translation>许可证期满！</translation>
    </message>
    <message>
        <source>Please, renew your license</source>
        <translation>请为许可证续期</translation>
    </message>
    <message>
        <source>Renew</source>
        <translation>续期</translation>
    </message>
    <message>
        <source>If you want to register that license on another PC click the &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>如需在其它电脑上注册此许可证，请点击“停用”按钮。
然后在需要的地方再注册。</translation>
    </message>
    <message>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact support@code-industry.net</source>
        <translation>停用失败！
请检查网络连接。
如果错误重复，请联系support@code-industry.net</translation>
    </message>
    <message>
        <source>Activation failed! Check internet connection.</source>
        <translation>激活失败！请检查网络连接。</translation>
    </message>
    <message>
        <source>Incorrect registration code.</source>
        <translation>注册码不正确。</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <source>Rotate</source>
        <translation>旋转</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>示例：1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>当前页面</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">选择页面，从</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">到：</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>方向</translation>
    </message>
    <message>
        <source>Clockwise 90 degrees</source>
        <translation>顺时针90度</translation>
    </message>
    <message>
        <source>180 degrees</source>
        <translation>180度</translation>
    </message>
    <message>
        <source>Counterclockwise 90 degrees</source>
        <translation>逆时针90度</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation>奇偶页</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation>偶数页</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation>奇数页</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>全部页面</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>宽度</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>等高</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>选择页面，从</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>到：</translation>
    </message>
    <message>
        <source>Export to Image</source>
        <translation>导出到图片</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>页面范围</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>全部页面</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <source>BMP</source>
        <translation>BMP</translation>
    </message>
    <message>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <source>TIFF</source>
        <translation>TIFF</translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation>高质量JPEG</translation>
    </message>
    <message>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <source>CCITT FAX 3</source>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <source>CCITT FAX 4</source>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <source>TIFF Compression</source>
        <translation>压缩TIFF</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>不能保存到文件：</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
该文件可能只读，或者正被其他应用程序使用。</translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation>另存为图片</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>所有文件(*)</translation>
    </message>
    <message>
        <source>MultiPage</source>
        <translation>多页</translation>
    </message>
    <message>
        <source>Save As TIFF Image</source>
        <translation>另存为TIFF图片</translation>
    </message>
    <message>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>TIFF文件 (*.tif *.tiff)</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>透明</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation>抗锯齿</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <source>Export:</source>
        <translation>导出：</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>文档</translation>
    </message>
    <message>
        <source>Document and Annotations</source>
        <translation>文档和笔记</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <source>Remove unused elements</source>
        <translation>删除未使用的元素</translation>
    </message>
    <message>
        <source>Flatten form fields</source>
        <translation>平铺表单域</translation>
    </message>
    <message>
        <source>Color and Grayscale Images</source>
        <translation>彩色和灰度图片</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>Compression</source>
        <translation>压缩</translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <source>Lossless</source>
        <translation>无损</translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation>高质量JPEG</translation>
    </message>
    <message>
        <source>Black and White Images</source>
        <translation>黑白图片</translation>
    </message>
    <message>
        <source>CCITT Group 4</source>
        <translation>CCITT Group 4</translation>
    </message>
    <message>
        <source>JBIG2</source>
        <translation>JBIG2</translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation>将优化保存为...</translation>
    </message>
    <message>
        <source>Merge all layers</source>
        <translation>合并所有层</translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <source>Scanning...</source>
        <translation>正在扫描...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <source>Scan</source>
        <translation>扫描</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>Output</source>
        <translation>输出</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation>当前页之前</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>末页之后</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation>当前页之后</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>首页之前</translation>
    </message>
    <message>
        <source>Append to Current Document </source>
        <translation>附加到当前文档 </translation>
    </message>
    <message>
        <source>Create New Document</source>
        <translation>创建新文档</translation>
    </message>
    <message>
        <source>Input</source>
        <translation>输入</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>Scanner</source>
        <translation>扫描仪</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>Looking for devices. Please wait.</source>
        <translation>正在查找设备。请稍等。</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>重新载入</translation>
    </message>
    <message>
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>分辨率</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Flatbed</source>
        <translation>平铺</translation>
    </message>
    <message>
        <source>Negative Transparency</source>
        <translation>负片</translation>
    </message>
    <message>
        <source>Document Feeder</source>
        <translation>文件送纸器</translation>
    </message>
    <message>
        <source>Positive Transparency</source>
        <translation>正片</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>未命名</translation>
    </message>
    <message>
        <source>Save As PDF</source>
        <translation>另存为PDF</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF 文件 (*.pdf)</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation>单页</translation>
    </message>
    <message>
        <source>All Pages From Feeder</source>
        <translation>来自送纸器的所有页面</translation>
    </message>
    <message>
        <source>Scan:</source>
        <translation>扫描：</translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <source>Scan more pages</source>
        <translation>扫描更多页</translation>
    </message>
    <message>
        <source>Scanning complete</source>
        <translation>扫描完成</translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>顺时针旋转90度</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>逆时针旋转90度</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <source>0 result</source>
        <translation>0结果</translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation>区分大小写</translation>
    </message>
    <message>
        <source> result</source>
        <translation> 结果</translation>
    </message>
    <message>
        <source> results</source>
        <translation> 结果</translation>
    </message>
    <message>
        <source> result(s)</source>
        <translation> 结果</translation>
    </message>
    <message>
        <source>Include Comments</source>
        <translation>包含批注</translation>
    </message>
    <message>
        <source>Whole Words Only</source>
        <translation>全词匹配</translation>
    </message>
    <message>
        <source>Check All</source>
        <translation>全部选中</translation>
    </message>
    <message>
        <source>Mark Checked Results for Redaction</source>
        <translation>将选中的结果标记为修订</translation>
    </message>
    <message>
        <source>Search and Redact</source>
        <translation type="vanished">搜索与修订</translation>
    </message>
    <message>
        <source>Uncheck All</source>
        <translation>全部不选</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <source>Case Sensitive</source>
        <translation>区分大小写</translation>
    </message>
    <message>
        <source>Include Comments</source>
        <translation>包含批注</translation>
    </message>
    <message>
        <source>Whole Words Only</source>
        <translation>全词匹配</translation>
    </message>
</context>
<context>
    <name>SecurityCertificateDialog</name>
    <message>
        <source>Certificate Security</source>
        <translation>证书安全性</translation>
    </message>
    <message>
        <source>Recipient</source>
        <translation>收件人</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation>许可</translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation>复制文档内容</translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation>修改文档</translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation>批注</translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation>打印文档</translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation>管理页面与书签</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation>填写已有的表单或签名区域</translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation>以高分辨率打印</translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation>提取文档内容</translation>
    </message>
    <message>
        <source>Encryption</source>
        <translation>加密</translation>
    </message>
    <message>
        <source>128 bit AES</source>
        <translation>128 位 AES</translation>
    </message>
    <message>
        <source>256 bit AES</source>
        <translation>256 位 AES</translation>
    </message>
    <message>
        <source>Recipients</source>
        <translation>收件人</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Required a password to open the document</source>
        <translation>打开文档需要密码</translation>
    </message>
    <message>
        <source>Document Open Password</source>
        <translation>文档打开密码</translation>
    </message>
    <message>
        <source>Password Confirm</source>
        <translation>确认密码</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation>许可</translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation>批注</translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation>修改文档</translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation>复制文档内容</translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation>打印文档</translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation>提取文档内容</translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation>以高分辨率打印</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation>填写已有的表单或签名区域</translation>
    </message>
    <message>
        <source>Permissions Password</source>
        <translation>权限密码</translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation>管理页面与书签</translation>
    </message>
    <message>
        <source>Document Open password does not match.</source>
        <translation>文档打开密码不匹配。</translation>
    </message>
    <message>
        <source>Document Permission password does not match.</source>
        <translation>文档权限密码不匹配。</translation>
    </message>
    <message>
        <source>Encryption</source>
        <translation>加密</translation>
    </message>
    <message>
        <source>256 bit AES</source>
        <translation>256 位 AES</translation>
    </message>
    <message>
        <source>128 bit RC4</source>
        <translation>128 位 AES</translation>
    </message>
    <message>
        <source>Password Security</source>
        <translation>密码安全</translation>
    </message>
    <message>
        <source>40 bit RC4</source>
        <translation>40 位 RC4</translation>
    </message>
    <message>
        <source>128 bit AES</source>
        <translation>128 位 AES</translation>
    </message>
</context>
<context>
    <name>SetLinkDlg</name>
    <message>
        <source>Set Destination</source>
        <translation>设置目的地</translation>
    </message>
    <message>
        <source>Use the scrollbars, mouse and zoom tools to select the target view, then press Set Link to create the Link destination</source>
        <translation>使用滚动条、鼠标和缩放工具选择目标视图，然后按“设置链接”创建链接目标</translation>
    </message>
    <message>
        <source>Set Link</source>
        <translation>设置链接</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Set current zoom</source>
        <translation>设置当前缩放</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <source>Signature Properties</source>
        <translation>签名属性</translation>
    </message>
    <message>
        <source>Signature is VALID</source>
        <translation>签名有效</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>详情</translation>
    </message>
    <message>
        <source>Signed by:</source>
        <translation>签名者：</translation>
    </message>
    <message>
        <source>Reason:</source>
        <translation>原因：</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>日期：</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>位置：</translation>
    </message>
    <message>
        <source>Validation Summary</source>
        <translation>验证摘要</translation>
    </message>
    <message>
        <source>Signer&apos;s Contact Information:</source>
        <translation>签字人联系方式：</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>信息</translation>
    </message>
    <message>
        <source>Text For Signing</source>
        <translation>签名文字</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>原因</translation>
    </message>
    <message>
        <source>Lock document after signing</source>
        <translation>签名后锁定文档</translation>
    </message>
    <message>
        <source>Signature Preview</source>
        <translation>签名预览</translation>
    </message>
    <message>
        <source>I have reviewed this document</source>
        <translation>我已审阅此文档</translation>
    </message>
    <message>
        <source>I am approving this document</source>
        <translation>我正在批准此文档</translation>
    </message>
    <message>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>我保证此文档的准确性和完整性</translation>
    </message>
    <message>
        <source>I agree to specified parts of this document</source>
        <translation>我同意本文件的特定部分</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Sign</source>
        <translation>签名</translation>
    </message>
    <message>
        <source>Show Image</source>
        <translation>显示图片</translation>
    </message>
    <message>
        <source>Stretch Image</source>
        <translation>拉伸图像</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Show Text</source>
        <translation>显示文字</translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation>签名验证期间出错！</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>打开图像</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>图片文件 (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>自签名以来，文档已被更改或损坏。</translation>
    </message>
    <message>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>自签名以来，文档未被修改。</translation>
    </message>
    <message>
        <source>Signature is INVALID</source>
        <translation>签名无效</translation>
    </message>
    <message>
        <source>Signature validity is UNKNOWN</source>
        <translation>签名验证未知</translation>
    </message>
    <message>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>签名者身份未知，因为它尚未包含在您的受信任身份列表中，并且其父证书都不是信任身份。</translation>
    </message>
    <message>
        <source>Error during signature verification.</source>
        <translation>签名验证期间发生错误。</translation>
    </message>
    <message>
        <source>Details: The signature byte range is invalid</source>
        <translation>详细信息：签名字节范围无效</translation>
    </message>
    <message>
        <source>I am the author of this document</source>
        <translation>我是此文件作者</translation>
    </message>
    <message>
        <source>This certificate is not trusted</source>
        <translation>此证书不可信</translation>
    </message>
    <message>
        <source>Sign As</source>
        <translation>签名为</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <source>Digitally signed by </source>
        <translation>数字签名者 </translation>
    </message>
    <message>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>保存的设置</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation>保存设置</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation>将当前设置保存为：</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>此名称的文件已存在。确定要替换原有文件吗？</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation>确定删除此设置吗 </translation>
    </message>
    <message>
        <source> ?</source>
        <translation> ？</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Certificate Manager</source>
        <translation>证书管理器</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>All Supported Files (*.p12 *.pfx);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>所有支持的文件(*.p12 *.pfx);; p12 文件 (*.p12);; pfx 文件 (*.pfx);; 所有文件 (*)</translation>
    </message>
    <message>
        <source>A password is required to open certificate:</source>
        <translation>打开证书需要密码：</translation>
    </message>
    <message>
        <source>Digitally signed by</source>
        <translation>数字签名者</translation>
    </message>
</context>
<context>
    <name>SignatureFormTab</name>
    <message>
        <source>Signatures</source>
        <translation>签名</translation>
    </message>
    <message>
        <source>Unsigned Signature</source>
        <translation>无标记的签名</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <source>Signed Signature</source>
        <translation>已标记的签名</translation>
    </message>
    <message>
        <source>Signed by:</source>
        <translation>签名者：</translation>
    </message>
    <message>
        <source>Reason:</source>
        <translation>原因：</translation>
    </message>
    <message>
        <source>Click to view this version</source>
        <translation>点击可查看此版本</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <source>Info</source>
        <translation>信息</translation>
    </message>
    <message>
        <source>Issuer</source>
        <translation>发行人</translation>
    </message>
    <message>
        <source>Common Name (CN)</source>
        <translation>批注名称(CN)</translation>
    </message>
    <message>
        <source>Organization (O)</source>
        <translation>组织(O)</translation>
    </message>
    <message>
        <source>Organizational Unit (OU)</source>
        <translation>组织单位 (OU)</translation>
    </message>
    <message>
        <source>Serial Number</source>
        <translation>序列号</translation>
    </message>
    <message>
        <source>Algorithm</source>
        <translation>算法</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>主题</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>电子邮件</translation>
    </message>
    <message>
        <source>Validity</source>
        <translation>验证</translation>
    </message>
    <message>
        <source>Not Before</source>
        <translation>不早于</translation>
    </message>
    <message>
        <source>Not After</source>
        <translation>不晚于</translation>
    </message>
    <message>
        <source>Add to Trusted Identities</source>
        <translation>添加到受信任标识</translation>
    </message>
    <message>
        <source>Data</source>
        <translation>数据</translation>
    </message>
    <message>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>文件名</translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <source>Settings</source>
        <translation type="obsolete">设置</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <source>Manage Stamps</source>
        <translation>管理戳记</translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <source>Custom Stamps</source>
        <translation>自定义戳记</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>Stamps</source>
        <translation>戳记</translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <source>Edit Stamp</source>
        <translation>编辑戳记</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>模板</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>答复</translation>
    </message>
</context>
<context>
    <name>TextDialog</name>
    <message>
        <source>Font:</source>
        <translation type="obsolete">字体：</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="obsolete">字体大小</translation>
    </message>
    <message>
        <source>Font color:</source>
        <translation type="obsolete">文本颜色</translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <source>Text Editor</source>
        <translation>文本编辑器</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;字体&lt;/span&gt;&lt;/p&gt;&lt;p&gt;修改字体&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;字体颜色&lt;/span&gt;&lt;/p&gt;&lt;p&gt;修改字体颜色&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;字体背景色&lt;/span&gt;&lt;/p&gt;&lt;p&gt;修改字体背景色&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>ToolBarCommentsForm</name>
    <message>
        <source>Highlight</source>
        <translation type="unfinished">高亮</translation>
    </message>
    <message>
        <source>StrikeOut</source>
        <translation type="unfinished">删除线</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished">下划线</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished">复制</translation>
    </message>
</context>
<context>
    <name>ToolBarSettings</name>
    <message>
        <source>Open a PDF file</source>
        <translation>打开PDF文件</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <source>Watermark</source>
        <translation>水印</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">设置</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>源</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>比例</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation>页数：</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>页码</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>外观</translation>
    </message>
    <message>
        <source>Rotation</source>
        <translation>旋转</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <source>Scale relative to target page</source>
        <translation>相对于目标页面缩放</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Vertical distance</source>
        <translation>垂直距离</translation>
    </message>
    <message>
        <source>from</source>
        <translation>从</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>顶端</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>中间</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>底部</translation>
    </message>
    <message>
        <source>Horizontal distance</source>
        <translation>水平距离</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>左侧</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>右侧</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>单位</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation>页面范围选项...</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation>保存设置</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation>将当前设置保存为：</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>此名称的文件已存在。确定要替换原有文件吗？</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation>确定删除此设置吗 </translation>
    </message>
    <message>
        <source> ?</source>
        <translation> ？</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> 点</translation>
    </message>
    <message>
        <source> in</source>
        <translation> 英寸</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> 毫米</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation>打开文档时出错！</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>保存的设置</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>所有支持的文件 (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
</context>
<context>
    <name>layerForm</name>
    <message>
        <source>Layers</source>
        <translation>图层</translation>
    </message>
</context>
</TS>
